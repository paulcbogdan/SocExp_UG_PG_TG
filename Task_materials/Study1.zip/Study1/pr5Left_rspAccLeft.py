#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (vlatest),
    on September 07, 2018, at 10:07
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division

import psychopy
psychopy.useVersion('latest')

from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'proposer'  # from the Builder filename that created this script
expInfo = {'block#': '', 'rejectSide': 'left', 'session': '001', 'participant': '', 'rolesScaleDirection': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='X:\\UIUC\\Experiments\\RoleChange\\Stimuli\\MAIN___StudyStimuliProtocol\\RolesChangedNew\\pr5Left_rspAccLeft.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1280, 1024], fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "fixation"
fixationClock = core.Clock()

fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.3, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "init"
initClock = core.Clock()
import random

role_type = visual.TextStim(win=win, name='role_type',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='blue', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "initial_prop"
initial_propClock = core.Clock()
import random
from psychopy import parallel
from psychopy import event
port = parallel.ParallelPort(address=0x0378)
port.setData(0)

resp_answer = ""
resp_color = "white"
split_offer = ''
subjectTake = 0
playerTake = 0
subjectPart = 0
playerPart = 0
split_proposal = visual.TextStim(win=win, name='split_proposal',
    text='$5 : $5    ||   $6 : $4    ||    $7 : $3    ||    $8 : $2    ||    $9 : $1\n\n     1                  2                space              9                  0   \n',
    font='Arial',
    units='norm', pos=(0, 0), height=0.09, wrapWidth=10, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "show_split_prop"
show_split_propClock = core.Clock()

split_text_prop = visual.TextStim(win=win, name='split_text_prop',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "resp_to_offer"
resp_to_offerClock = core.Clock()

response_5_5 = visual.TextStim(win=win, name='response_5_5',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "show_split_resp"
show_split_respClock = core.Clock()

split_text_resp = visual.TextStim(win=win, name='split_text_resp',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "initial_resp"
initial_respClock = core.Clock()

accept_scale = visual.TextStim(win=win, name='accept_scale',
    text='strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n accept                                                          reject\n\n      1                2            space          9              0\n',
    font='Arial',
    units='norm', pos=(0, 0), height=0.09, wrapWidth=10, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "resp_result"
resp_resultClock = core.Clock()

resp_res = visual.TextStim(win=win, name='resp_res',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# set up handler to look after randomisation of conditions etc
main_loop = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('LoopConditionsShort\\Pract.xlsx'),
    seed=None, name='main_loop')
thisExp.addLoop(main_loop)  # add the loop to the experiment
thisMain_loop = main_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
if thisMain_loop != None:
    for paramName in thisMain_loop:
        exec('{} = thisMain_loop[paramName]'.format(paramName))

for thisMain_loop in main_loop:
    currentLoop = main_loop
    # abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
    if thisMain_loop != None:
        for paramName in thisMain_loop:
            exec('{} = thisMain_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "fixation"-------
    t = 0
    fixationClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    port.setData(51)
    
    #initializing default data for each trial
    resp_res_color="white"
    subjectPart = 0
    playerPart = 0
    subjectTake = 0
    playerTake = 0
    resp_answer = "You Missed"
    
    #initializing random time interval
    jitter=(25-random.randrange(0,50))/100
    # keep track of which components have finished
    fixationComponents = [fix]
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "fixation"-------
    while continueRoutine:
        # get current time
        t = fixationClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *fix* updates
        if t >= 0.0 and fix.status == NOT_STARTED:
            # keep track of start time/frame for later
            fix.tStart = t
            fix.frameNStart = frameN  # exact frame index
            fix.setAutoDraw(True)
        frameRemains = 0.0 + 2.0+jitter- win.monitorFramePeriod * 0.75  # most of one frame period left
        if fix.status == STARTED and t >= frameRemains:
            fix.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "fixation"-------
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    port.setData(0)
    # the Routine "fixation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "init"-------
    t = 0
    initClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if roleChange=="pp":
        port.setData(52)
    elif roleChange=="rp":
        port.setData(53)
    elif roleChange=="rr":
        port.setData(54)
    elif roleChange=="pr":
        port.setData(55)
    else:
        port.setData(10)
    
    role_type.setText(roleType)
    # keep track of which components have finished
    initComponents = [role_type]
    for thisComponent in initComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "init"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = initClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *role_type* updates
        if t >= 0.0 and role_type.status == NOT_STARTED:
            # keep track of start time/frame for later
            role_type.tStart = t
            role_type.frameNStart = frameN  # exact frame index
            role_type.setAutoDraw(True)
        frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
        if role_type.status == STARTED and t >= frameRemains:
            role_type.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in initComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "init"-------
    for thisComponent in initComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    port.setData(0)
    
    # set up handler to look after randomisation of conditions etc
    prop_loop = data.TrialHandler(nReps=loop_proposer, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='prop_loop')
    thisExp.addLoop(prop_loop)  # add the loop to the experiment
    thisProp_loop = prop_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisProp_loop.rgb)
    if thisProp_loop != None:
        for paramName in thisProp_loop:
            exec('{} = thisProp_loop[paramName]'.format(paramName))
    
    for thisProp_loop in prop_loop:
        currentLoop = prop_loop
        # abbreviate parameter names if possible (e.g. rgb = thisProp_loop.rgb)
        if thisProp_loop != None:
            for paramName in thisProp_loop:
                exec('{} = thisProp_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "initial_prop"-------
        t = 0
        initial_propClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        acc_chance=random.randrange(1,100)
        core.wait(0.001)
        port.setData(56)
        core.wait(0.001)
        port.setData(0)
        kbd_offer = event.BuilderKeyResponse()
        # keep track of which components have finished
        initial_propComponents = [split_proposal, kbd_offer]
        for thisComponent in initial_propComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "initial_prop"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = initial_propClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            #keys = kbd_offer.keys
            #if keys != None:
            #    if '1' in keys:
            #        port.setData(11)
            #    elif '2' in keys:
            #        port.setData(12)
            #    elif 'space' in keys:
            #        port.setData(13)
            #    elif '9' in keys:
            #        port.setData(14)
            #    elif '0' in keys:
            #        port.setData(15)
            split_offer = kbd_offer.keys
            
            if split_offer != None:
            
                if '1' in split_offer:
                    subjectTake = 5
                    playerTake = 5
                    port.setData(57)
                    if acc_chance<99:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=5
                        playerPart=5
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '2' in split_offer:
                    subjectTake = 6
                    playerTake = 4
                    port.setData(58)
                    if acc_chance<89:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=6
                        playerPart=4
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif 'space' in split_offer:
                    subjectTake = 7
                    playerTake = 3
                    port.setData(59)
                    if acc_chance<55:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=7
                        playerPart=3
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '9' in split_offer:
                    subjectTake = 8
                    playerTake = 2
                    port.setData(60)
                    if acc_chance<30:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=8
                        playerPart=2
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '0' in split_offer:
                    subjectTake = 9
                    playerTake = 1
                    port.setData(61)
                    if acc_chance<24:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=9
                        playerPart=1
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
            #    else:
            #        resp_answer="You missed"
            else:
                resp_answer="You Missed"
                subjectTake = 0
                playerTake = 0
                subjectPart=0
                playerPart=0
                port.setData(62)
            
            # *split_proposal* updates
            if t >= 0.0 and split_proposal.status == NOT_STARTED:
                # keep track of start time/frame for later
                split_proposal.tStart = t
                split_proposal.frameNStart = frameN  # exact frame index
                split_proposal.setAutoDraw(True)
            frameRemains = 0.0 + 3.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if split_proposal.status == STARTED and t >= frameRemains:
                split_proposal.setAutoDraw(False)
            
            # *kbd_offer* updates
            if t >= 0.0 and kbd_offer.status == NOT_STARTED:
                # keep track of start time/frame for later
                kbd_offer.tStart = t
                kbd_offer.frameNStart = frameN  # exact frame index
                kbd_offer.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(kbd_offer.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            frameRemains = 0.0 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if kbd_offer.status == STARTED and t >= frameRemains:
                kbd_offer.status = STOPPED
            if kbd_offer.status == STARTED:
                theseKeys = event.getKeys(keyList=['1', '2', 'space', '9', '0'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    kbd_offer.keys = theseKeys[-1]  # just the last key pressed
                    kbd_offer.rt = kbd_offer.clock.getTime()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in initial_propComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "initial_prop"-------
        for thisComponent in initial_propComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        prop_loop.addData('response',resp_answer)
        prop_loop.addData('spl_offr',split_offer)
        prop_loop.addData('subjectTake',subjectTake)
        port.setData(0)
        # check responses
        if kbd_offer.keys in ['', [], None]:  # No response was made
            kbd_offer.keys=None
        prop_loop.addData('kbd_offer.keys',kbd_offer.keys)
        if kbd_offer.keys != None:  # we had a response
            prop_loop.addData('kbd_offer.rt', kbd_offer.rt)
        
        # ------Prepare to start Routine "show_split_prop"-------
        t = 0
        show_split_propClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        if subjectTake == 5:
            port.setData(63)
        elif subjectTake == 6:
            port.setData(64)
        elif subjectTake == 7:
            port.setData(65)
        elif subjectTake == 8:
            port.setData(66)
        elif subjectTake == 9:
            port.setData(67)
        else:
            port.setData(68)
        split_text_prop.setText("You offer: \n \n You:      $"+str(subjectTake)+"\n Player:   $"+str(playerTake))
        # keep track of which components have finished
        show_split_propComponents = [split_text_prop]
        for thisComponent in show_split_propComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "show_split_prop"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = show_split_propClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *split_text_prop* updates
            if t >= 0.0 and split_text_prop.status == NOT_STARTED:
                # keep track of start time/frame for later
                split_text_prop.tStart = t
                split_text_prop.frameNStart = frameN  # exact frame index
                split_text_prop.setAutoDraw(True)
            frameRemains = 0.0 + 3.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if split_text_prop.status == STARTED and t >= frameRemains:
                split_text_prop.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in show_split_propComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "show_split_prop"-------
        for thisComponent in show_split_propComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        
        # ------Prepare to start Routine "resp_to_offer"-------
        t = 0
        resp_to_offerClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(1.500000)
        # update component parameters for each repeat
        if resp_answer=="Player Accepted":
            if subjectTake==5:
                port.setData(69)
            elif subjectTake==6:
                port.setData(70)
            elif subjectTake==7:
                port.setData(71)
            elif subjectTake==8:
                port.setData(72)
            elif subjectTake==9:
                port.setData(73)
        
        elif resp_answer=="Player Rejected":
            if subjectTake==5:
                port.setData(74)
            elif subjectTake==6:
                port.setData(75)
            elif subjectTake==7:
                port.setData(76)
            elif subjectTake==8:
                port.setData(77)
            elif subjectTake==9:
                port.setData(78)
        else:
            port.setData(10)
        response_5_5.setColor(resp_color, colorSpace='rgb')
        response_5_5.setText(resp_answer+'\n \n'+"You get:      $"+str(subjectPart)+"\nPlayer gets:   $"+str(playerPart))
        # keep track of which components have finished
        resp_to_offerComponents = [response_5_5]
        for thisComponent in resp_to_offerComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "resp_to_offer"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = resp_to_offerClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *response_5_5* updates
            if t >= 0.0 and response_5_5.status == NOT_STARTED:
                # keep track of start time/frame for later
                response_5_5.tStart = t
                response_5_5.frameNStart = frameN  # exact frame index
                response_5_5.setAutoDraw(True)
            frameRemains = 0.0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if response_5_5.status == STARTED and t >= frameRemains:
                response_5_5.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in resp_to_offerComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "resp_to_offer"-------
        for thisComponent in resp_to_offerComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        thisExp.nextEntry()
        
    # completed loop_proposer repeats of 'prop_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    resp_loop = data.TrialHandler(nReps=loop_responder, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='resp_loop')
    thisExp.addLoop(resp_loop)  # add the loop to the experiment
    thisResp_loop = resp_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisResp_loop.rgb)
    if thisResp_loop != None:
        for paramName in thisResp_loop:
            exec('{} = thisResp_loop[paramName]'.format(paramName))
    
    for thisResp_loop in resp_loop:
        currentLoop = resp_loop
        # abbreviate parameter names if possible (e.g. rgb = thisResp_loop.rgb)
        if thisResp_loop != None:
            for paramName in thisResp_loop:
                exec('{} = thisResp_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "show_split_resp"-------
        t = 0
        show_split_respClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(2.000000)
        # update component parameters for each repeat
        if proposerTake == 5:
            port.setData(80)
        elif proposerTake == 6:
            port.setData(81)
        elif proposerTake == 7:
            port.setData(82)
        elif proposerTake == 8:
            port.setData(83)
        elif proposerTake == 9:
            port.setData(84)
        split_text_resp.setText("Player offers: \n \n Player:   $"+str(proposerTake)+"\n You:      $"+str(10-proposerTake))
        # keep track of which components have finished
        show_split_respComponents = [split_text_resp]
        for thisComponent in show_split_respComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "show_split_resp"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = show_split_respClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *split_text_resp* updates
            if t >= 0.0 and split_text_resp.status == NOT_STARTED:
                # keep track of start time/frame for later
                split_text_resp.tStart = t
                split_text_resp.frameNStart = frameN  # exact frame index
                split_text_resp.setAutoDraw(True)
            frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if split_text_resp.status == STARTED and t >= frameRemains:
                split_text_resp.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in show_split_respComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "show_split_resp"-------
        for thisComponent in show_split_respComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        
        # ------Prepare to start Routine "initial_resp"-------
        t = 0
        initial_respClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        port.setData(85)
        core.wait(0.001)
        port.setData(0)
        offer_rating = event.BuilderKeyResponse()
        # keep track of which components have finished
        initial_respComponents = [accept_scale, offer_rating]
        for thisComponent in initial_respComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "initial_resp"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = initial_respClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            keys=offer_rating.keys
            if keys != None:
                if proposerTake==5:
                    if '1' in keys:
                        port.setData(86)
                        subjectPart=5
                        playerPart=5
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(87)
                        subjectPart=5
                        playerPart=5
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(88)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(89)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(90)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==6:
                    if '1' in keys:
                        port.setData(91)
                        subjectPart=4
                        playerPart=6
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(92)
                        subjectPart=4
                        playerPart=6
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(93)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(94)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(95)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==7:
                    if '1' in keys:
                        port.setData(96)
                        subjectPart=3
                        playerPart=7
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(97)
                        subjectPart=3
                        playerPart=7
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(98)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(99)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(100)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==8:
                    if '1' in keys:
                        port.setData(101)
                        subjectPart=2
                        playerPart=8
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(102)
                        subjectPart=2
                        playerPart=8
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(103)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(104)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(104)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==9:
                    if '1' in keys:
                        port.setData(106)
                        subjectPart=1
                        playerPart=9
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(107)
                        subjectPart=1
                        playerPart=9
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(108)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(109)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(110)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
            else:
                resp_answer="You Missed"
                subjectPart=0
                playerPart=0
                port.setData(111)
            
            # *accept_scale* updates
            if t >= 0.0 and accept_scale.status == NOT_STARTED:
                # keep track of start time/frame for later
                accept_scale.tStart = t
                accept_scale.frameNStart = frameN  # exact frame index
                accept_scale.setAutoDraw(True)
            frameRemains = 0.0 + 3.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if accept_scale.status == STARTED and t >= frameRemains:
                accept_scale.setAutoDraw(False)
            
            # *offer_rating* updates
            if t >= 0.0 and offer_rating.status == NOT_STARTED:
                # keep track of start time/frame for later
                offer_rating.tStart = t
                offer_rating.frameNStart = frameN  # exact frame index
                offer_rating.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(offer_rating.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            frameRemains = 0.0 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if offer_rating.status == STARTED and t >= frameRemains:
                offer_rating.status = STOPPED
            if offer_rating.status == STARTED:
                theseKeys = event.getKeys(keyList=['1', '2', 'space', '9', '0'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    offer_rating.keys = theseKeys[-1]  # just the last key pressed
                    offer_rating.rt = offer_rating.clock.getTime()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in initial_respComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "initial_resp"-------
        for thisComponent in initial_respComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        offer_response=offer_rating.keys
        resp_loop.addData('offer_response',offer_response)
        resp_loop.addData('proposerTake',proposerTake)
        port.setData(0)
        # check responses
        if offer_rating.keys in ['', [], None]:  # No response was made
            offer_rating.keys=None
        resp_loop.addData('offer_rating.keys',offer_rating.keys)
        if offer_rating.keys != None:  # we had a response
            resp_loop.addData('offer_rating.rt', offer_rating.rt)
        
        # ------Prepare to start Routine "resp_result"-------
        t = 0
        resp_resultClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(1.500000)
        # update component parameters for each repeat
        if resp_answer=="You Accepted":
            resp_res_color="green"
            if proposerTake == 5:
                port.setData(112)
            elif proposerTake == 6:
                port.setData(113)
            elif proposerTake == 7:
                port.setData(114)
            elif proposerTake == 8:
                port.setData(115)
            elif proposerTake == 9:
                port.setData(116)
        elif resp_answer=="You Rejected":
            resp_res_color="red"
            if proposerTake == 5:
                port.setData(117)
            elif proposerTake == 6:
                port.setData(118)
            elif proposerTake == 7:
                port.setData(119)
            elif proposerTake == 8:
                port.setData(120)
            elif proposerTake == 9:
                port.setData(121)
        else:
            resp_res_color="white"
            port.setData(122)
        resp_res.setColor(resp_res_color, colorSpace='rgb')
        resp_res.setText(resp_answer+'\n \n'+"Player gets:   $"+str(playerPart)+"\nYou get:      $"+str(subjectPart))
        # keep track of which components have finished
        resp_resultComponents = [resp_res]
        for thisComponent in resp_resultComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "resp_result"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = resp_resultClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *resp_res* updates
            if t >= 0.0 and resp_res.status == NOT_STARTED:
                # keep track of start time/frame for later
                resp_res.tStart = t
                resp_res.frameNStart = frameN  # exact frame index
                resp_res.setAutoDraw(True)
            frameRemains = 0.0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if resp_res.status == STARTED and t >= frameRemains:
                resp_res.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in resp_resultComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "resp_result"-------
        for thisComponent in resp_resultComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        thisExp.nextEntry()
        
    # completed loop_responder repeats of 'resp_loop'
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'main_loop'









# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()

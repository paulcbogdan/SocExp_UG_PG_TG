﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.2.4),
    on October 26, 2022, at 14:08
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

import psychopy
psychopy.useVersion('latest')


from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.2.4'
expName = 'proposer'  # from the Builder filename that created this script
expInfo = {'block#': '', 'rejectSide': 'left', 'session': '001', 'participant': '', 'rolesScaleDirection': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\paulc\\Desktop\\RolesChanged_PsychoPy\\pr5Left_rspAccLeft_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1280, 1024], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "fixation"
fixationClock = core.Clock()
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.3, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "init"
initClock = core.Clock()
import random

role_type = visual.TextStim(win=win, name='role_type',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='blue', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "initial_prop"
initial_propClock = core.Clock()
import random
from psychopy import parallel
from psychopy import event
port = parallel.ParallelPort(address=0x0378)
port.setData(0)

resp_answer = ""
resp_color = "white"
split_offer = ''
subjectTake = 0
playerTake = 0
subjectPart = 0
playerPart = 0
split_proposal = visual.TextStim(win=win, name='split_proposal',
    text='$5 : $5    ||   $6 : $4    ||    $7 : $3    ||    $8 : $2    ||    $9 : $1\n\n     1                  2                space              9                  0   \n',
    font='Arial',
    units='norm', pos=(0, 0), height=0.09, wrapWidth=10, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
kbd_offer = keyboard.Keyboard()

# Initialize components for Routine "show_split_prop"
show_split_propClock = core.Clock()
split_text_prop = visual.TextStim(win=win, name='split_text_prop',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "resp_to_offer"
resp_to_offerClock = core.Clock()
response_5_5 = visual.TextStim(win=win, name='response_5_5',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "show_split_resp"
show_split_respClock = core.Clock()
split_text_resp = visual.TextStim(win=win, name='split_text_resp',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "initial_resp"
initial_respClock = core.Clock()
accept_scale = visual.TextStim(win=win, name='accept_scale',
    text='strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n accept                                                          reject\n\n      1                2            space          9              0\n',
    font='Arial',
    units='norm', pos=(0, 0), height=0.09, wrapWidth=10, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
offer_rating = keyboard.Keyboard()

# Initialize components for Routine "resp_result"
resp_resultClock = core.Clock()
resp_res = visual.TextStim(win=win, name='resp_res',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# set up handler to look after randomisation of conditions etc
main_loop = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('LoopConditionsShort\\Pract.xlsx'),
    seed=None, name='main_loop')
thisExp.addLoop(main_loop)  # add the loop to the experiment
thisMain_loop = main_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
if thisMain_loop != None:
    for paramName in thisMain_loop:
        exec('{} = thisMain_loop[paramName]'.format(paramName))

for thisMain_loop in main_loop:
    currentLoop = main_loop
    # abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
    if thisMain_loop != None:
        for paramName in thisMain_loop:
            exec('{} = thisMain_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "fixation"-------
    # update component parameters for each repeat
    port.setData(51)
    
    #initializing default data for each trial
    resp_res_color="white"
    subjectPart = 0
    playerPart = 0
    subjectTake = 0
    playerTake = 0
    resp_answer = "You Missed"
    
    #initializing random time interval
    jitter=(25-random.randrange(0,50))/100
    # keep track of which components have finished
    fixationComponents = [fix]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    fixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "fixation"-------
    while continueRoutine:
        # get current time
        t = fixationClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=fixationClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *fix* updates
        if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            fix.frameNStart = frameN  # exact frame index
            fix.tStart = t  # local t and not account for scr refresh
            fix.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
            fix.setAutoDraw(True)
        if fix.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > fix.tStartRefresh + 2.0+jitter-frameTolerance:
                # keep track of stop time/frame for later
                fix.tStop = t  # not accounting for scr refresh
                fix.frameNStop = frameN  # exact frame index
                win.timeOnFlip(fix, 'tStopRefresh')  # time at next scr refresh
                fix.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "fixation"-------
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    port.setData(0)
    main_loop.addData('fix.started', fix.tStartRefresh)
    main_loop.addData('fix.stopped', fix.tStopRefresh)
    # the Routine "fixation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "init"-------
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if roleChange=="pp":
        port.setData(52)
    elif roleChange=="rp":
        port.setData(53)
    elif roleChange=="rr":
        port.setData(54)
    elif roleChange=="pr":
        port.setData(55)
    else:
        port.setData(10)
    
    role_type.setText(roleType)
    # keep track of which components have finished
    initComponents = [role_type]
    for thisComponent in initComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    initClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "init"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = initClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=initClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *role_type* updates
        if role_type.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            role_type.frameNStart = frameN  # exact frame index
            role_type.tStart = t  # local t and not account for scr refresh
            role_type.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(role_type, 'tStartRefresh')  # time at next scr refresh
            role_type.setAutoDraw(True)
        if role_type.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > role_type.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                role_type.tStop = t  # not accounting for scr refresh
                role_type.frameNStop = frameN  # exact frame index
                win.timeOnFlip(role_type, 'tStopRefresh')  # time at next scr refresh
                role_type.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in initComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "init"-------
    for thisComponent in initComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    port.setData(0)
    main_loop.addData('role_type.started', role_type.tStartRefresh)
    main_loop.addData('role_type.stopped', role_type.tStopRefresh)
    
    # set up handler to look after randomisation of conditions etc
    prop_loop = data.TrialHandler(nReps=loop_proposer, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='prop_loop')
    thisExp.addLoop(prop_loop)  # add the loop to the experiment
    thisProp_loop = prop_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisProp_loop.rgb)
    if thisProp_loop != None:
        for paramName in thisProp_loop:
            exec('{} = thisProp_loop[paramName]'.format(paramName))
    
    for thisProp_loop in prop_loop:
        currentLoop = prop_loop
        # abbreviate parameter names if possible (e.g. rgb = thisProp_loop.rgb)
        if thisProp_loop != None:
            for paramName in thisProp_loop:
                exec('{} = thisProp_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "initial_prop"-------
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        acc_chance=random.randrange(1,100)
        core.wait(0.001)
        port.setData(56)
        core.wait(0.001)
        port.setData(0)
        kbd_offer.keys = []
        kbd_offer.rt = []
        # keep track of which components have finished
        initial_propComponents = [split_proposal, kbd_offer]
        for thisComponent in initial_propComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        initial_propClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "initial_prop"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = initial_propClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=initial_propClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            #keys = kbd_offer.keys
            #if keys != None:
            #    if '1' in keys:
            #        port.setData(11)
            #    elif '2' in keys:
            #        port.setData(12)
            #    elif 'space' in keys:
            #        port.setData(13)
            #    elif '9' in keys:
            #        port.setData(14)
            #    elif '0' in keys:
            #        port.setData(15)
            split_offer = kbd_offer.keys
            
            if split_offer != None:
            
                if '1' in split_offer:
                    subjectTake = 5
                    playerTake = 5
                    port.setData(57)
                    if acc_chance<99:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=5
                        playerPart=5
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '2' in split_offer:
                    subjectTake = 6
                    playerTake = 4
                    port.setData(58)
                    if acc_chance<89:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=6
                        playerPart=4
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif 'space' in split_offer:
                    subjectTake = 7
                    playerTake = 3
                    port.setData(59)
                    if acc_chance<55:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=7
                        playerPart=3
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '9' in split_offer:
                    subjectTake = 8
                    playerTake = 2
                    port.setData(60)
                    if acc_chance<30:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=8
                        playerPart=2
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
                elif '0' in split_offer:
                    subjectTake = 9
                    playerTake = 1
                    port.setData(61)
                    if acc_chance<24:
                        resp_answer="Player Accepted"
                        resp_color="green"
                        subjectPart=9
                        playerPart=1
                    else:
                        resp_answer="Player Rejected"
                        resp_color="red"
                        subjectPart=0
                        playerPart=0
            
            #    else:
            #        resp_answer="You missed"
            else:
                resp_answer="You Missed"
                subjectTake = 0
                playerTake = 0
                subjectPart=0
                playerPart=0
                port.setData(62)
            
            # *split_proposal* updates
            if split_proposal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                split_proposal.frameNStart = frameN  # exact frame index
                split_proposal.tStart = t  # local t and not account for scr refresh
                split_proposal.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(split_proposal, 'tStartRefresh')  # time at next scr refresh
                split_proposal.setAutoDraw(True)
            if split_proposal.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > split_proposal.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    split_proposal.tStop = t  # not accounting for scr refresh
                    split_proposal.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(split_proposal, 'tStopRefresh')  # time at next scr refresh
                    split_proposal.setAutoDraw(False)
            
            # *kbd_offer* updates
            waitOnFlip = False
            if kbd_offer.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kbd_offer.frameNStart = frameN  # exact frame index
                kbd_offer.tStart = t  # local t and not account for scr refresh
                kbd_offer.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kbd_offer, 'tStartRefresh')  # time at next scr refresh
                kbd_offer.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(kbd_offer.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(kbd_offer.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if kbd_offer.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > kbd_offer.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    kbd_offer.tStop = t  # not accounting for scr refresh
                    kbd_offer.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(kbd_offer, 'tStopRefresh')  # time at next scr refresh
                    kbd_offer.status = FINISHED
            if kbd_offer.status == STARTED and not waitOnFlip:
                theseKeys = kbd_offer.getKeys(keyList=['1', '2', 'space', '9', '0'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    kbd_offer.keys = theseKeys.name  # just the last key pressed
                    kbd_offer.rt = theseKeys.rt
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in initial_propComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "initial_prop"-------
        for thisComponent in initial_propComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        prop_loop.addData('response',resp_answer)
        prop_loop.addData('spl_offr',split_offer)
        prop_loop.addData('subjectTake',subjectTake)
        port.setData(0)
        prop_loop.addData('split_proposal.started', split_proposal.tStartRefresh)
        prop_loop.addData('split_proposal.stopped', split_proposal.tStopRefresh)
        # check responses
        if kbd_offer.keys in ['', [], None]:  # No response was made
            kbd_offer.keys = None
        prop_loop.addData('kbd_offer.keys',kbd_offer.keys)
        if kbd_offer.keys != None:  # we had a response
            prop_loop.addData('kbd_offer.rt', kbd_offer.rt)
        prop_loop.addData('kbd_offer.started', kbd_offer.tStartRefresh)
        prop_loop.addData('kbd_offer.stopped', kbd_offer.tStopRefresh)
        
        # ------Prepare to start Routine "show_split_prop"-------
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        if subjectTake == 5:
            port.setData(63)
        elif subjectTake == 6:
            port.setData(64)
        elif subjectTake == 7:
            port.setData(65)
        elif subjectTake == 8:
            port.setData(66)
        elif subjectTake == 9:
            port.setData(67)
        else:
            port.setData(68)
        split_text_prop.setText("You offer: \n \n You:      $"+str(subjectTake)+"\n Player:   $"+str(playerTake))
        # keep track of which components have finished
        show_split_propComponents = [split_text_prop]
        for thisComponent in show_split_propComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        show_split_propClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "show_split_prop"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = show_split_propClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=show_split_propClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *split_text_prop* updates
            if split_text_prop.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                split_text_prop.frameNStart = frameN  # exact frame index
                split_text_prop.tStart = t  # local t and not account for scr refresh
                split_text_prop.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(split_text_prop, 'tStartRefresh')  # time at next scr refresh
                split_text_prop.setAutoDraw(True)
            if split_text_prop.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > split_text_prop.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    split_text_prop.tStop = t  # not accounting for scr refresh
                    split_text_prop.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(split_text_prop, 'tStopRefresh')  # time at next scr refresh
                    split_text_prop.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in show_split_propComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "show_split_prop"-------
        for thisComponent in show_split_propComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        prop_loop.addData('split_text_prop.started', split_text_prop.tStartRefresh)
        prop_loop.addData('split_text_prop.stopped', split_text_prop.tStopRefresh)
        
        # ------Prepare to start Routine "resp_to_offer"-------
        routineTimer.add(1.500000)
        # update component parameters for each repeat
        if resp_answer=="Player Accepted":
            if subjectTake==5:
                port.setData(69)
            elif subjectTake==6:
                port.setData(70)
            elif subjectTake==7:
                port.setData(71)
            elif subjectTake==8:
                port.setData(72)
            elif subjectTake==9:
                port.setData(73)
        
        elif resp_answer=="Player Rejected":
            if subjectTake==5:
                port.setData(74)
            elif subjectTake==6:
                port.setData(75)
            elif subjectTake==7:
                port.setData(76)
            elif subjectTake==8:
                port.setData(77)
            elif subjectTake==9:
                port.setData(78)
        else:
            port.setData(10)
        response_5_5.setColor(resp_color, colorSpace='rgb')
        response_5_5.setText(resp_answer+'\n \n'+"You get:      $"+str(subjectPart)+"\nPlayer gets:   $"+str(playerPart))
        # keep track of which components have finished
        resp_to_offerComponents = [response_5_5]
        for thisComponent in resp_to_offerComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        resp_to_offerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "resp_to_offer"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = resp_to_offerClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=resp_to_offerClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *response_5_5* updates
            if response_5_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                response_5_5.frameNStart = frameN  # exact frame index
                response_5_5.tStart = t  # local t and not account for scr refresh
                response_5_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(response_5_5, 'tStartRefresh')  # time at next scr refresh
                response_5_5.setAutoDraw(True)
            if response_5_5.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > response_5_5.tStartRefresh + 1.5-frameTolerance:
                    # keep track of stop time/frame for later
                    response_5_5.tStop = t  # not accounting for scr refresh
                    response_5_5.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(response_5_5, 'tStopRefresh')  # time at next scr refresh
                    response_5_5.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in resp_to_offerComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "resp_to_offer"-------
        for thisComponent in resp_to_offerComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        prop_loop.addData('response_5_5.started', response_5_5.tStartRefresh)
        prop_loop.addData('response_5_5.stopped', response_5_5.tStopRefresh)
        thisExp.nextEntry()
        
    # completed loop_proposer repeats of 'prop_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    resp_loop = data.TrialHandler(nReps=loop_responder, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='resp_loop')
    thisExp.addLoop(resp_loop)  # add the loop to the experiment
    thisResp_loop = resp_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisResp_loop.rgb)
    if thisResp_loop != None:
        for paramName in thisResp_loop:
            exec('{} = thisResp_loop[paramName]'.format(paramName))
    
    for thisResp_loop in resp_loop:
        currentLoop = resp_loop
        # abbreviate parameter names if possible (e.g. rgb = thisResp_loop.rgb)
        if thisResp_loop != None:
            for paramName in thisResp_loop:
                exec('{} = thisResp_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "show_split_resp"-------
        routineTimer.add(2.000000)
        # update component parameters for each repeat
        if proposerTake == 5:
            port.setData(80)
        elif proposerTake == 6:
            port.setData(81)
        elif proposerTake == 7:
            port.setData(82)
        elif proposerTake == 8:
            port.setData(83)
        elif proposerTake == 9:
            port.setData(84)
        split_text_resp.setText("Player offers: \n \n Player:   $"+str(proposerTake)+"\n You:      $"+str(10-proposerTake))
        # keep track of which components have finished
        show_split_respComponents = [split_text_resp]
        for thisComponent in show_split_respComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        show_split_respClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "show_split_resp"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = show_split_respClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=show_split_respClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *split_text_resp* updates
            if split_text_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                split_text_resp.frameNStart = frameN  # exact frame index
                split_text_resp.tStart = t  # local t and not account for scr refresh
                split_text_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(split_text_resp, 'tStartRefresh')  # time at next scr refresh
                split_text_resp.setAutoDraw(True)
            if split_text_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > split_text_resp.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    split_text_resp.tStop = t  # not accounting for scr refresh
                    split_text_resp.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(split_text_resp, 'tStopRefresh')  # time at next scr refresh
                    split_text_resp.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in show_split_respComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "show_split_resp"-------
        for thisComponent in show_split_respComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        resp_loop.addData('split_text_resp.started', split_text_resp.tStartRefresh)
        resp_loop.addData('split_text_resp.stopped', split_text_resp.tStopRefresh)
        
        # ------Prepare to start Routine "initial_resp"-------
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        port.setData(85)
        core.wait(0.001)
        port.setData(0)
        offer_rating.keys = []
        offer_rating.rt = []
        # keep track of which components have finished
        initial_respComponents = [accept_scale, offer_rating]
        for thisComponent in initial_respComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        initial_respClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "initial_resp"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = initial_respClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=initial_respClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            keys=offer_rating.keys
            if keys != None:
                if proposerTake==5:
                    if '1' in keys:
                        port.setData(86)
                        subjectPart=5
                        playerPart=5
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(87)
                        subjectPart=5
                        playerPart=5
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(88)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(89)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(90)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==6:
                    if '1' in keys:
                        port.setData(91)
                        subjectPart=4
                        playerPart=6
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(92)
                        subjectPart=4
                        playerPart=6
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(93)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(94)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(95)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==7:
                    if '1' in keys:
                        port.setData(96)
                        subjectPart=3
                        playerPart=7
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(97)
                        subjectPart=3
                        playerPart=7
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(98)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(99)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(100)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==8:
                    if '1' in keys:
                        port.setData(101)
                        subjectPart=2
                        playerPart=8
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(102)
                        subjectPart=2
                        playerPart=8
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(103)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(104)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(104)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                elif proposerTake==9:
                    if '1' in keys:
                        port.setData(106)
                        subjectPart=1
                        playerPart=9
                        resp_answer="You Accepted"
                    elif '2' in keys:
                        port.setData(107)
                        subjectPart=1
                        playerPart=9
                        resp_answer="You Accepted"
                    elif 'space' in keys:
                        port.setData(108)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Passed"
                    elif '9' in keys:
                        port.setData(109)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
                    elif '0' in keys:
                        port.setData(110)
                        subjectPart=0
                        playerPart=0
                        resp_answer="You Rejected"
            else:
                resp_answer="You Missed"
                subjectPart=0
                playerPart=0
                port.setData(111)
            
            # *accept_scale* updates
            if accept_scale.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                accept_scale.frameNStart = frameN  # exact frame index
                accept_scale.tStart = t  # local t and not account for scr refresh
                accept_scale.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(accept_scale, 'tStartRefresh')  # time at next scr refresh
                accept_scale.setAutoDraw(True)
            if accept_scale.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > accept_scale.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    accept_scale.tStop = t  # not accounting for scr refresh
                    accept_scale.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(accept_scale, 'tStopRefresh')  # time at next scr refresh
                    accept_scale.setAutoDraw(False)
            
            # *offer_rating* updates
            waitOnFlip = False
            if offer_rating.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                offer_rating.frameNStart = frameN  # exact frame index
                offer_rating.tStart = t  # local t and not account for scr refresh
                offer_rating.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(offer_rating, 'tStartRefresh')  # time at next scr refresh
                offer_rating.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(offer_rating.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(offer_rating.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if offer_rating.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > offer_rating.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    offer_rating.tStop = t  # not accounting for scr refresh
                    offer_rating.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(offer_rating, 'tStopRefresh')  # time at next scr refresh
                    offer_rating.status = FINISHED
            if offer_rating.status == STARTED and not waitOnFlip:
                theseKeys = offer_rating.getKeys(keyList=['1', '2', 'space', '9', '0'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    offer_rating.keys = theseKeys.name  # just the last key pressed
                    offer_rating.rt = theseKeys.rt
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in initial_respComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "initial_resp"-------
        for thisComponent in initial_respComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        offer_response=offer_rating.keys
        resp_loop.addData('offer_response',offer_response)
        resp_loop.addData('proposerTake',proposerTake)
        port.setData(0)
        resp_loop.addData('accept_scale.started', accept_scale.tStartRefresh)
        resp_loop.addData('accept_scale.stopped', accept_scale.tStopRefresh)
        # check responses
        if offer_rating.keys in ['', [], None]:  # No response was made
            offer_rating.keys = None
        resp_loop.addData('offer_rating.keys',offer_rating.keys)
        if offer_rating.keys != None:  # we had a response
            resp_loop.addData('offer_rating.rt', offer_rating.rt)
        resp_loop.addData('offer_rating.started', offer_rating.tStartRefresh)
        resp_loop.addData('offer_rating.stopped', offer_rating.tStopRefresh)
        
        # ------Prepare to start Routine "resp_result"-------
        routineTimer.add(1.500000)
        # update component parameters for each repeat
        if resp_answer=="You Accepted":
            resp_res_color="green"
            if proposerTake == 5:
                port.setData(112)
            elif proposerTake == 6:
                port.setData(113)
            elif proposerTake == 7:
                port.setData(114)
            elif proposerTake == 8:
                port.setData(115)
            elif proposerTake == 9:
                port.setData(116)
        elif resp_answer=="You Rejected":
            resp_res_color="red"
            if proposerTake == 5:
                port.setData(117)
            elif proposerTake == 6:
                port.setData(118)
            elif proposerTake == 7:
                port.setData(119)
            elif proposerTake == 8:
                port.setData(120)
            elif proposerTake == 9:
                port.setData(121)
        else:
            resp_res_color="white"
            port.setData(122)
        resp_res.setColor(resp_res_color, colorSpace='rgb')
        resp_res.setText(resp_answer+'\n \n'+"Player gets:   $"+str(playerPart)+"\nYou get:      $"+str(subjectPart))
        # keep track of which components have finished
        resp_resultComponents = [resp_res]
        for thisComponent in resp_resultComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        resp_resultClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        continueRoutine = True
        
        # -------Run Routine "resp_result"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = resp_resultClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=resp_resultClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *resp_res* updates
            if resp_res.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                resp_res.frameNStart = frameN  # exact frame index
                resp_res.tStart = t  # local t and not account for scr refresh
                resp_res.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(resp_res, 'tStartRefresh')  # time at next scr refresh
                resp_res.setAutoDraw(True)
            if resp_res.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > resp_res.tStartRefresh + 1.5-frameTolerance:
                    # keep track of stop time/frame for later
                    resp_res.tStop = t  # not accounting for scr refresh
                    resp_res.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(resp_res, 'tStopRefresh')  # time at next scr refresh
                    resp_res.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in resp_resultComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "resp_result"-------
        for thisComponent in resp_resultComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        port.setData(0)
        resp_loop.addData('resp_res.started', resp_res.tStartRefresh)
        resp_loop.addData('resp_res.stopped', resp_res.tStopRefresh)
        thisExp.nextEntry()
        
    # completed loop_responder repeats of 'resp_loop'
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'main_loop'


# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()

/*************************
 * Rc_Pavlovia_Test Test *
 *************************/

import { PsychoJS } from 'https://pavlovia.org/lib/core.js';
import * as core from 'https://pavlovia.org/lib/core.js';
import { TrialHandler } from 'https://pavlovia.org/lib/data.js';
import { Scheduler } from 'https://pavlovia.org/lib/util.js';
import * as util from 'https://pavlovia.org/lib/util.js';
import * as visual from 'https://pavlovia.org/lib/visual.js';
import { Sound } from 'https://pavlovia.org/lib/sound.js';

// init psychoJS:
var psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: false,
  color: new util.Color([0, 0, 0]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'INSTRUCTIONS: Press OK when download bar finishes';  // from the Builder filename that created this script
let expInfo = {'id': ''}; // 'participant': '',
// id=%SURVEY_CODE%

// https://run.pavlovia.org/pbog/rolechange_test/html?id=%SURVEY_CODE%

//let expInfo = {}
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

var random_key = Math.floor(Math.random() * 8)

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);


// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);



flowScheduler.add(experiment_startingRoutineBegin);
flowScheduler.add(experiment_startingRoutineEachFrame);
flowScheduler.add(experiment_startingRoutineEnd);

const main_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(main_loopLoopBegin, main_loopLoopScheduler);
flowScheduler.add(main_loopLoopScheduler);
flowScheduler.add(main_loopLoopEnd);

const slider_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(slider_loopLoopBegin, slider_loopLoopScheduler);
flowScheduler.add(slider_loopLoopScheduler);
flowScheduler.add(slider_loopLoopEnd);

flowScheduler.add(Experiment_closingRoutineBegin);
flowScheduler.add(Experiment_closingRoutineEachFrame);
flowScheduler.add(Experiment_closingRoutineEnd);
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
// dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({expName, expInfo});

var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '3.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0/Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0/60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://uiuc.sona-systems.com/webstudy_credit.aspx?experiment_id=xxx&credit_token=xxx', '');

  return Scheduler.Event.NEXT;
}

var experiment_startingClock, Experiment_starting_text, Experiment_starting_keypress;

var initClock;
var role_type;
var Proposer_proposeClock;
var Proposer_propose_text;

var kbd_offer, offer_rating;

var Experiment_closingClock, Experiment_closing_text, Experiment_closing_keypress;

var Proposer_confirm_offerClock;
var Proposer_confirm_offer_text;
var Proposer_waitingClock;
var Proposer_waiting_text;
var Proposer_view_outcomeClock;
var Proposer_view_outcome_text;
var Responder_waitingClock;
var Responder_waiting_text;
var Responder_view_offerClock;
var Responder_view_offer_text;
var Responder_respondClock;
var Responder_respond_text;
var Responder_view_outcomeClock;
var Responder_view_outcome_text;

var globalClock;
var routineTimer;
var roleType = "Responder Role";

var Investor_investClock, Investor_invest_text, Investor_key_input;
var Investor_confirm_amountClock, Investor_confirm_amount_text;
var Investor_waitingClock, Investor_waiting_text;
var Investor_view_outcomeClock, Investor_view_outcome_text;

var Trustee_waitingClock, Trustee_waiting_text;
var Trustee_view_amountClock, Trustee_view_amount_text;
var Trustee_trustClock, Trustee_trust_text, trustee_key_input;
var Trustee_view_outcomeClock, Trustee_view_outcome_text;

var no_roleClock;
var text_4;

var Investor_investComponents, Investor_confirm_amountComponents, Investor_waitingComponents, Investor_view_outcomeComponents;
var Trustee_waitingComponents, Trustee_view_amountComponents, Trustee_trustComponents, Trustee_view_outcomeComponents;

var Subject_pairing_screenClock, Subject_pairing_screen_text, Subject_pairing_screenComponents;

var computer;

var trust_options = {
  option1: {amount: 0,
    responses: [0, 0, 0, 0, 0],
    response1: 0,
    response2: 0,
    response3: 0,
    response4: 0,
    response5: 0},
  option2: {amount: 5,
    responses: [0, 5, 8, 10, 15],
    response1: 0,
    response2: 5,
    response3: 8,
    response4: 10,
    response5: 15},
  option3: {amount: 10,
    responses: [0, 10, 15, 20, 30],
    response1: 0,
    response2: 10,
    response3: 15,
    response4: 20,
    response5: 30},
  option4: {amount: 15,
    responses: [0, 15, 22, 30, 45],
    response1: 0,
    response2: 15,
    response3: 22,
    response4: 30,
    response5: 45},
  option5: {amount: 20,
    responses: [0, 20, 30, 40, 60],
    response1: 0,
    response2: 20,
    response3: 30,
    response4: 40,
    response5: 60}
}
var invest_starting_amount = 20;

var option1_keep_str = (invest_starting_amount - trust_options.option1.amount).toString(); // if I was better at js, I
var option2_keep_str = (invest_starting_amount - trust_options.option2.amount).toString(); // would iterate here
var option3_keep_str = (invest_starting_amount - trust_options.option3.amount).toString();
var option4_keep_str = (invest_starting_amount - trust_options.option4.amount).toString();
var option5_keep_str = (invest_starting_amount - trust_options.option5.amount).toString();


var invest_text = '    How much to invest? ($keep : $invest)\nNone                                                                      All\n$' + option1_keep_str + ':$' + trust_options.option1.amount.toString() +
    '   ||   $' + option2_keep_str + ':$' + trust_options.option2.amount.toString() +
    '   ||   $' + option3_keep_str + ':$' + trust_options.option3.amount.toString() +
    '   ||   $' + option4_keep_str + ':$' + trust_options.option4.amount.toString() +
    '   ||   $' + option5_keep_str + ':$' + trust_options.option5.amount.toString() +'\n\n  1                 2              space              9                0   \n';

var propose_text = '$9 : $1   ||   $8 : $2   ||   $7 : $3   ||   $6 : $4   ||   $5 : $5\n\n  1                 2             space             9                 0  \n';
var respond_text = 'strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n' + 'accept                                                          reject\n\n' + '      1                2            space          9              0';


// implement a 10-30 second break??

var opening_text = [
    ' Before we can begin the experiment, you must accept a consent form.\n\n' +
    ' Please press the [right] arrow key, and a consent form will begin to download onto your computer. ' +
' Please accept any pop-ups asking for permission to download the consent form PDF File' +
' If you are having any technical difficulties during the experiment, please email: pbogda2@illinois.edu.',

    'A consent form should be downloading now. Please read it.\n\n' + //  If you would like to withdraw from this experiment, ' +
//' you need to send an email to pbogda2@illinois.edu, stating your name and that you would like to withdraw. You will not receive SONA credit' +
//' if you withdraw, but emailing that address allows us to mark you as an excused absence. After you send that email ' +
//' you can just press the "x" in the top right of your web browser to end the experiment.\n\n' +
'If you would like to give consent, please press the [right] arrow key.', //  +
//' It will advance you to the next screen. you are free to withdraw at any time, but if you do, please email that address.' +
// ' We encourage you to write it down on a piece of paper now now.',

      'Press the [space] bar to confirm that you are giving consent.',

      'We will now begin to describe this experiment in more detail. \n\nIn this study, you will be playing a live game and interacting' +
' with other participants (including many from other univeristies)! Specifically, you will be playing two-player games, where your overall rewards depend on both' +
' your own behavior and the behavior of the people you play with. The reward we have planned for you is to leave the experiment early!' +
' Specifically, we have a boring task planned for the end of the experiment. The more \"money\" you earn during the' +
' two-player games, the less of the boring task you will have to do.\n\n' +
        'Press the [right] arrowkey to advance to the next screen. At any time, you can press the [left] arrow key to' +
' return to an earlier screen.',

    'The experiment is organized into ~4 minute rounds and involves two types of games.' +
'\n\nEach round begins by pairing you with a random player.' +
' Then, you will play the \"Pot Splitting Game\" for 12 to 24 times with that player. After that, you will play the' +
' \"Investment Game\" once with that same player.\n\n' +
' We will first go over the instructions for the first game. To download the instructions (PDF file), please press the ' +
' [right] arrow key which wil also move you to the next screen. Please accept any pop-ups regarding the download.',

    ' The Pot Splitting Game instructions should be downloading now. Please read them.\n\n' +
' After you have done this, we will move onto a practice trial, please press the [right] arrow key when you are done reading, but feel free to refer back' +
' to the instructions at any time during this experiment.',

    ' Okay, for this first practice trial, you will be placed in the PROPOSER ROLE, where you are proposing how to split a $10 pot.\n\n' +
' When you see the offer screens, please press the key for proposing a $6:$4 split, where you take $6,' +
' and the other player would receive $4. You MUST press the $6:$4 key to advance in the experiment. ' +
' If you are confused, you can always press the [left] arrow key to move to an earlier tutorial screen.',

    propose_text,

  'Good job! We have one more screen where you will be again placed in the Proposer role. However, this time, please press the key corresponding' +
' to proposing a $8:$2 split, where you take $8 and the other player would receive $2.\n\n Okay? Please press the [right] arrow key to try.',

    propose_text,

    ' Superb! Keep in mind that in the actual experiment you will need to make these choices within 3 seconds.' +
' If you make an unintended choice, you can press another key. The last key you press will be your choice.' +
' \n\nNow, keep in mind, there are more screens than just these that you will see in the Proposer role,' +
' such as a screen where you get a confirmation about what offer you proposed and another screen where you find out whether your' +
' offer was accepted or rejected. Please see the instructions PDF for full details. \n\nNow, lets try demoing the' +
' RESPONDER ROLE. For the next screen that pops up when you press [right], please try responding Strongly Accept',

    respond_text,

    'Well done, responding with Strongly Accept has the same effects on the payouts as responding with just Accept,' +
' and Strongly Reject has the same outcomes as Reject. However, please try to use Strongly Accept and Strongly Reject,' +
' when you feel very strongly about your response, so that us researcher can better understand what is going on in your' +
' mind, okay?\n\nNow, we have one more practice trial, please move to the next screen with [right] and respond to the next screen with Reject.',

    respond_text,

    'Nice, okay. We are done with the Pot Splitting Game demo. Again, in the actual experiment, you need to make these' +
' choices within 3 seconds, and there will be more screens shown than just the' +
' one you saw, such as the screen informing you of what offer you just received! If you miss a choice in the Proposer' +
' or in the Responder role both you and the other player will get zero money! \n\n We will now start going over the' +
' Investment Game procedure. When you press the [right] arrow key and move to the next slide, an instructions PDF for' +
' that game will begin to download.',

    'Please read the instructions for the Investment Game.\n\n' +
' After you have completed 12-24 roudns of the Pot Splitting Game, you will play the Investment Game once with the same other player.' +
' Right when the experiment began, you were randomly assigned to always play in the INVESTOR ROLE for the Investment game. ' +
' In other words, you will always be playing in the investor role and this will hold true for each person you play with.' +
' Clear? Okay, let\'s try a practice trial where you are in the investor role, please press the [right] arrow key.',

    'For this investor role practice trial, please try keeping $15 and investing $5 (out of your initial $20).' +
' This choice will appear as \"$15:$5\", meaning that you kept $15 and invested $5.' +
' Press the [right] arrow to see the screen.',

    invest_text,

    'Good, you won\'t be playing the Investment Game as many times and you are dealing with a larger amount of money,' +
' so we tried to implement additional instructions for that screen. Also, during the experiment, we will also give you 6' +
' seconds to choose your amount to invest. Now, when you press the [right] arrow, you will see the last' +
' tutorial screen. On it, try investing $15 and keeping $5.',

    invest_text,

    ' You are ready to go. This is now the last slide of the instructions. Last reminder: You will not receive actual' +
' money for playing this game. Instead, the more money you earn, the faster you will be able to leave and the more of' +
' the boring task you will be able to skip. If ever feel uncomfortable, you can withdraw from the experiment by closing' +
' your web browser and emailing pbogda2@illinois.edu, stating that you withdrew. Again, you will not receive partial credit' +
' as this experiment is under an hour long, but if you withdraw and email that address, you will receive an excused absense.\n\n' +
' If you press the [space] bar, you will be taken to the first screen of the experiment, where you' +
' will be able to start the system\'s search for another participants.'];


//console.log(opening_text);

// opening_text = ['test', 'test'];

// We expect the instructions to require up to 10 minutes to go through everything

// do you want to withdraw now?
// ask: are you colorblind, maybe they respond differently to the red vs. green? could explain some male vs. female sex differences?

var opening_key_required_to_advance = ['right', 'right', 'space', 'right', 'right', 'right', 'right', 9, 'right', 2, 'right', 1, 'right', 9, 'right', 'right', 'right', 2, 'right', 9, 'right', 'right', 'space'];
//var opening_key_required_to_advance = ['right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right','right', 'right', 'right', 'right', 'right', 'right','right', 'right', 'right', 'right', 'right', 'right'];

//var opening_key_required_to_advance = ['right', 'right'];


var current_text_focus_element = 0;
var pot_splitting_instructions_download_element = 5;
var investment_game_instructions_download_element = 15;
var consent_form_number_key = 1;

var closing_text = ['The experiment is now done.\n\n While we mentioned in the introduction, that you would be doing a' +
' boirng task at the end of the experiment depending on your performance during the task, this was not true. Due to' +
' contraints related to this being an online experiment, there will be no boring task.\n\nWe also told you that you' +
' were playing with other human players. This was also not true. All of your games were played using a computer.\n\n' +
' Please press the [right] arrow key to move onto the next \"debriefing\" slide. Doing this will download a PDF' +
' describing more details related to the experiment. The next slide also provides further description of the task that' +
' you just performed.',

' The games that you played, which we called the Pot \"Splitting Game\" and the \"Investment Game\", are more commonly ' +
' referred to as the \"Ultimatum Game\" and the \"Trust Game\" respectively. Wikipedia has nice content on the two if' +
' you would like to read more (to read about the Trust Game, see the Dictator Game page).\n\n' +
' We used these games to study how people learn to trust others over the course of multiple social interactions.' +
' Repeatedly playing the first game for 12-24 rounds served as simulated \"social interactions\" and the second game was' +
' was intended to measure the extentt that you trusted the other player. Please press the [right] arrow key to to move onto' +
' the last screen.',

    'We hope that you enjoyed participating in our study. Please press the [right] arrow key to end the study and receive' +
' credit. (You should receive the SONA credit instantly, but please wait up to 24 hours). ' +
'\n\nShould you have any questions, concerns, or suggestions for' +
' how you believe it can be improved, please send us an email at pbogda2@illinois.edu. No matter how small of a thing' +
' you have to say, we would be very happy to hear it. We would particularly appreciate any feedback related to whether' +
' you experienced technical difficulties. \n\n' +
'Regardless, you are free to exit the experiment now. We hope you have a nice rest of the day! (Go wash your hands!)'];

var current_closing_focus_element = 0;
var closing_key_required_to_advance = ['right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right']

var debriefing_form_number_key = 3;

/* Welcome to the experiment. In this experimet you will...' +
          'A consent form should currently be downloading onto your computer. ' +
          'Please open this document, read it, and if you would like to consent to this experiment, ' +
          'please press your keyboard\'s space bar to continue to the next screen.',*/
var slider_testClock;
var slider_text;
var move_it_around;
var slider_keypress;
function experimentInit() {
  // Initialize components for Routine "experiment_starting"
  experiment_startingClock = new util.Clock();
  Experiment_starting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Experiment_starting_text',
    text: opening_text[0], //
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });
  Experiment_starting_keypress = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});

  Experiment_closingClock = new util.Clock();
  Experiment_closing_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Experiment_closing_text',
    text: closing_text[0],
    font: 'Arial',
    units: undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  Experiment_closing_keypress = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "init"
  initClock = new util.Clock();
  role_type = new visual.TextStim({
    win: psychoJS.window,
    name: 'role_type',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('blue'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Proposer_propose"
  Proposer_proposeClock = new util.Clock();
  Proposer_propose_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_propose_text',
    text: propose_text,
    font: 'Arial',
    units : 'norm',
    pos: [0, 0], height: 0.065,  wrapWidth: 10, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  kbd_offer = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Proposer_confirm_offer"
  Proposer_confirm_offerClock = new util.Clock();
  Proposer_confirm_offer_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_confirm_offer_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Proposer_waiting"
  Proposer_waitingClock = new util.Clock();
  Proposer_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_waiting_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Proposer_view_outcome"
  Proposer_view_outcomeClock = new util.Clock();
  Proposer_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_view_outcome_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Responder_waiting"
  Responder_waitingClock = new util.Clock();
  Responder_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_waiting_text',
    text: 'Waiting for the Proposer to propose',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Responder_view_offer"
  Responder_view_offerClock = new util.Clock();
  Responder_view_offer_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_view_offer_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Responder_respond"
  Responder_respondClock = new util.Clock();
  Responder_respond_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_respond_text',
    text: 'default text',
    font: 'Arial',
    units : 'norm',
    pos: [0, 0], height: 0.065,  wrapWidth: 10, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  offer_rating = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Responder_view_outcome"
  Responder_view_outcomeClock = new util.Clock();
  Responder_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_view_outcome_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

   // Initialize components for Routine "Investor_invest"
  Investor_investClock = new util.Clock();
  Investor_invest_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_invest_text',
    text: invest_text,
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  Investor_key_input = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Investor_confirm_amount"
  Investor_confirm_amountClock = new util.Clock();
  Investor_confirm_amount_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_confirm_amount_text',
    text: ' ',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Investor_waiting"
  Investor_waitingClock = new util.Clock();
  Investor_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_waiting_text',
    text: 'Waiting to hear back from the trustee',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Investor_view_outcome"
  Investor_view_outcomeClock = new util.Clock();
  Investor_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_view_outcome_text',
    text: ' ',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Trustee_waiting"
  Trustee_waitingClock = new util.Clock();
  Trustee_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Trustee_waiting_text',
    text: 'Please wait for the investor to select an amount',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Trustee_view_amount"
  Trustee_view_amountClock = new util.Clock();
  Trustee_view_amount_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Trustee_view_amount_text',
    text: 'Trusts you w',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Trustee_trust"
  Trustee_trustClock = new util.Clock();
  trustee_key_input = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  Trustee_trust_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Trustee_trust_text',
    text: 'How much do you give back?',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Trustee_view_outcome"
  Trustee_view_outcomeClock = new util.Clock();
  Trustee_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Trustee_view_outcome_text',
    text: 'Outcome:\nYou have: 12\nPlayer kept: 6',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });


  // Initialize components for Routine "no_role"
  no_roleClock = new util.Clock();
  text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_4',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

    // Initialize components for Routine "Subject_pairing_screen"
  Subject_pairing_screenClock = new util.Clock();
  Subject_pairing_screen_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Subject_pairing_screen_text',
    text: 'You are free to take a short' +
        ' break right now if you want (e.g., you can go to the bathroom). When you are ready to start playing with a new' +
        ' person, please press the space bar and the system will begin looking for a suitable co-player.', // We are searching to find you a new subject. Please wait.
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.045,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  slider_testClock = new util.Clock();
  slider_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'slider_text',
    text: 'default text',
    font: 'Arial',
    units: undefined,
    pos: [0, 0.15], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  move_it_around = new visual.Slider({
    win: psychoJS.window, name: 'move_it_around',
    size: [1.0, 0.065], pos: [0, (- 0.1)], units: 'height',
    labels: ['a', 'b', 'c'], ticks: [1, 2, 3],
    granularity: 1, style: [visual.Slider.Style.RATING],
    color: new util.Color('LightGray'), // fontFamily: 'HelveticaBold',
     bold: true, italic: false,
    flip: false, fontSize: 0.2
  });
  slider_keypress = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});


  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine

  return Scheduler.Event.NEXT;
}

var t;
var frameN;
var _Experiment_starting_keypress_allKeys;
var experiment_startingComponents;
function experiment_startingRoutineBegin() {
  //------Prepare to start Routine 'experiment_starting'-------
  t = 0;
  experiment_startingClock.reset(); // clock
  frameN = -1;
  cooldown = 0
  // update component parameters for each repeat
  // keep track of which components have finished
  Experiment_starting_keypress.keys = undefined;
  Experiment_starting_keypress.rt = undefined;
  _Experiment_starting_keypress_allKeys = [];

  experiment_startingComponents = [];
  experiment_startingComponents.push(Experiment_starting_text);
  experiment_startingComponents.push(Experiment_starting_keypress);

  for (const thisComponent of experiment_startingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

var frameRemains;
var continueRoutine;
var opening_screen_bool;
var change;

var closing_screen_bool;

function process_keys_pages(keypress_manager) {

  if (typeof keypress_manager.keys != 'undefined' && typeof keypress_manager.keys != null) {
    let key = keypress_manager.keys;//.slice(-1)[0];
    //console.log('key slice:')
    //console.log(key)

    let key_required_to_advance;
    if (keypress_manager == Experiment_starting_keypress) {
      key_required_to_advance = opening_key_required_to_advance;
      console.log('COMPARUSON WORKSSSSSSSS');
    } else if (keypress_manager == Experiment_closing_keypress) {
      key_required_to_advance = closing_key_required_to_advance;
      console.log('CLOSE IT DOWN');
    }
    console.log('needed:')
    console.log(key_required_to_advance[current_text_focus_element])
    if (key == key_required_to_advance[current_text_focus_element]) {
      if (current_text_focus_element >= closing_text.length-1) {
        closing_screen_bool = true;
      }
      if (current_text_focus_element >= opening_text.length-1) {
        opening_screen_bool = true; // will break if you want two Experiment_starting routines...
      } else {
        console.log('fail')
        current_text_focus_element = current_text_focus_element + 1;
        change = true;
      }

    } else if (key == 'left') {
      if (current_text_focus_element > 0) {
        current_text_focus_element = current_text_focus_element - 1;
        change = true;
      }
    } //else {
      //var snd = new Audio("data:audio/wav;base64,//uQRAAAAWMSLwUIYAAsYkXgoQwAEaYLWfkWgAI0wWs/ItAAAGDgYtAgAyN+QWaAAihwMWm4G8QQRDiMcCBcH3Cc+CDv/7xA4Tvh9Rz/y8QADBwMWgQAZG/ILNAARQ4GLTcDeIIIhxGOBAuD7hOfBB3/94gcJ3w+o5/5eIAIAAAVwWgQAVQ2ORaIQwEMAJiDg95G4nQL7mQVWI6GwRcfsZAcsKkJvxgxEjzFUgfHoSQ9Qq7KNwqHwuB13MA4a1q/DmBrHgPcmjiGoh//EwC5nGPEmS4RcfkVKOhJf+WOgoxJclFz3kgn//dBA+ya1GhurNn8zb//9NNutNuhz31f////9vt///z+IdAEAAAK4LQIAKobHItEIYCGAExBwe8jcToF9zIKrEdDYIuP2MgOWFSE34wYiR5iqQPj0JIeoVdlG4VD4XA67mAcNa1fhzA1jwHuTRxDUQ//iYBczjHiTJcIuPyKlHQkv/LHQUYkuSi57yQT//uggfZNajQ3Vmz+Zt//+mm3Wm3Q576v////+32///5/EOgAAADVghQAAAAA//uQZAUAB1WI0PZugAAAAAoQwAAAEk3nRd2qAAAAACiDgAAAAAAABCqEEQRLCgwpBGMlJkIz8jKhGvj4k6jzRnqasNKIeoh5gI7BJaC1A1AoNBjJgbyApVS4IDlZgDU5WUAxEKDNmmALHzZp0Fkz1FMTmGFl1FMEyodIavcCAUHDWrKAIA4aa2oCgILEBupZgHvAhEBcZ6joQBxS76AgccrFlczBvKLC0QI2cBoCFvfTDAo7eoOQInqDPBtvrDEZBNYN5xwNwxQRfw8ZQ5wQVLvO8OYU+mHvFLlDh05Mdg7BT6YrRPpCBznMB2r//xKJjyyOh+cImr2/4doscwD6neZjuZR4AgAABYAAAABy1xcdQtxYBYYZdifkUDgzzXaXn98Z0oi9ILU5mBjFANmRwlVJ3/6jYDAmxaiDG3/6xjQQCCKkRb/6kg/wW+kSJ5//rLobkLSiKmqP/0ikJuDaSaSf/6JiLYLEYnW/+kXg1WRVJL/9EmQ1YZIsv/6Qzwy5qk7/+tEU0nkls3/zIUMPKNX/6yZLf+kFgAfgGyLFAUwY//uQZAUABcd5UiNPVXAAAApAAAAAE0VZQKw9ISAAACgAAAAAVQIygIElVrFkBS+Jhi+EAuu+lKAkYUEIsmEAEoMeDmCETMvfSHTGkF5RWH7kz/ESHWPAq/kcCRhqBtMdokPdM7vil7RG98A2sc7zO6ZvTdM7pmOUAZTnJW+NXxqmd41dqJ6mLTXxrPpnV8avaIf5SvL7pndPvPpndJR9Kuu8fePvuiuhorgWjp7Mf/PRjxcFCPDkW31srioCExivv9lcwKEaHsf/7ow2Fl1T/9RkXgEhYElAoCLFtMArxwivDJJ+bR1HTKJdlEoTELCIqgEwVGSQ+hIm0NbK8WXcTEI0UPoa2NbG4y2K00JEWbZavJXkYaqo9CRHS55FcZTjKEk3NKoCYUnSQ0rWxrZbFKbKIhOKPZe1cJKzZSaQrIyULHDZmV5K4xySsDRKWOruanGtjLJXFEmwaIbDLX0hIPBUQPVFVkQkDoUNfSoDgQGKPekoxeGzA4DUvnn4bxzcZrtJyipKfPNy5w+9lnXwgqsiyHNeSVpemw4bWb9psYeq//uQZBoABQt4yMVxYAIAAAkQoAAAHvYpL5m6AAgAACXDAAAAD59jblTirQe9upFsmZbpMudy7Lz1X1DYsxOOSWpfPqNX2WqktK0DMvuGwlbNj44TleLPQ+Gsfb+GOWOKJoIrWb3cIMeeON6lz2umTqMXV8Mj30yWPpjoSa9ujK8SyeJP5y5mOW1D6hvLepeveEAEDo0mgCRClOEgANv3B9a6fikgUSu/DmAMATrGx7nng5p5iimPNZsfQLYB2sDLIkzRKZOHGAaUyDcpFBSLG9MCQALgAIgQs2YunOszLSAyQYPVC2YdGGeHD2dTdJk1pAHGAWDjnkcLKFymS3RQZTInzySoBwMG0QueC3gMsCEYxUqlrcxK6k1LQQcsmyYeQPdC2YfuGPASCBkcVMQQqpVJshui1tkXQJQV0OXGAZMXSOEEBRirXbVRQW7ugq7IM7rPWSZyDlM3IuNEkxzCOJ0ny2ThNkyRai1b6ev//3dzNGzNb//4uAvHT5sURcZCFcuKLhOFs8mLAAEAt4UWAAIABAAAAAB4qbHo0tIjVkUU//uQZAwABfSFz3ZqQAAAAAngwAAAE1HjMp2qAAAAACZDgAAAD5UkTE1UgZEUExqYynN1qZvqIOREEFmBcJQkwdxiFtw0qEOkGYfRDifBui9MQg4QAHAqWtAWHoCxu1Yf4VfWLPIM2mHDFsbQEVGwyqQoQcwnfHeIkNt9YnkiaS1oizycqJrx4KOQjahZxWbcZgztj2c49nKmkId44S71j0c8eV9yDK6uPRzx5X18eDvjvQ6yKo9ZSS6l//8elePK/Lf//IInrOF/FvDoADYAGBMGb7FtErm5MXMlmPAJQVgWta7Zx2go+8xJ0UiCb8LHHdftWyLJE0QIAIsI+UbXu67dZMjmgDGCGl1H+vpF4NSDckSIkk7Vd+sxEhBQMRU8j/12UIRhzSaUdQ+rQU5kGeFxm+hb1oh6pWWmv3uvmReDl0UnvtapVaIzo1jZbf/pD6ElLqSX+rUmOQNpJFa/r+sa4e/pBlAABoAAAAA3CUgShLdGIxsY7AUABPRrgCABdDuQ5GC7DqPQCgbbJUAoRSUj+NIEig0YfyWUho1VBBBA//uQZB4ABZx5zfMakeAAAAmwAAAAF5F3P0w9GtAAACfAAAAAwLhMDmAYWMgVEG1U0FIGCBgXBXAtfMH10000EEEEEECUBYln03TTTdNBDZopopYvrTTdNa325mImNg3TTPV9q3pmY0xoO6bv3r00y+IDGid/9aaaZTGMuj9mpu9Mpio1dXrr5HERTZSmqU36A3CumzN/9Robv/Xx4v9ijkSRSNLQhAWumap82WRSBUqXStV/YcS+XVLnSS+WLDroqArFkMEsAS+eWmrUzrO0oEmE40RlMZ5+ODIkAyKAGUwZ3mVKmcamcJnMW26MRPgUw6j+LkhyHGVGYjSUUKNpuJUQoOIAyDvEyG8S5yfK6dhZc0Tx1KI/gviKL6qvvFs1+bWtaz58uUNnryq6kt5RzOCkPWlVqVX2a/EEBUdU1KrXLf40GoiiFXK///qpoiDXrOgqDR38JB0bw7SoL+ZB9o1RCkQjQ2CBYZKd/+VJxZRRZlqSkKiws0WFxUyCwsKiMy7hUVFhIaCrNQsKkTIsLivwKKigsj8XYlwt/WKi2N4d//uQRCSAAjURNIHpMZBGYiaQPSYyAAABLAAAAAAAACWAAAAApUF/Mg+0aohSIRobBAsMlO//Kk4soosy1JSFRYWaLC4qZBYWFRGZdwqKiwkNBVmoWFSJkWFxX4FFRQWR+LsS4W/rFRb/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////VEFHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU291bmRib3kuZGUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjAwNGh0dHA6Ly93d3cuc291bmRib3kuZGUAAAAAAAAAACU=");
      //snd.play();
    //}

    //if (key == key_required_to_advance[current_text_focus_element] || key == 'left') {
    keypress_manager.keys = undefined;
    key = undefined;
    keypress_manager.clearEvents();
    Experiment_starting_keypress.keys = undefined;
    _Experiment_starting_keypress_allKeys = [];
    cooldown = 0;
    console.log('screen bool:', opening_screen_bool)
    console.log('current focus:', current_text_focus_element)
    console.log(key_required_to_advance.length)
    //}
  }
}

var cooldown = 0;
function experiment_startingRoutineEachFrame() {
  //------Loop for each frame of Routine 'experiment_starting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = experiment_startingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  cooldown = cooldown + 1;
  // update/draw components on each frame

  // *Experiment_starting_text* updates
  if (t >= 0.0 && Experiment_starting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_starting_text.tStart = t;  // (not accounting for frame time here)
    Experiment_starting_text.frameNStart = frameN;  // exact frame index
    Experiment_starting_text.setAutoDraw(true);
  }

  opening_screen_bool = false;
  if (Experiment_starting_text.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
    Experiment_starting_text.setAutoDraw(false);
  }

  //console.log('final screen text end:')
  //console.log(Experiment_starting_keypress.keys)
  //console.log(opening_screen_bool)


  if (t >= 0.0 && Experiment_starting_keypress.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Experiment_starting_keypress.tStart = t;  // (not accounting for frame time here)
      Experiment_starting_keypress.frameNStart = frameN;  // exact frame index

      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.clearEvents(); });
  }
  opening_screen_bool = false;
  const prev_current_text_focus_element = current_text_focus_element;

  if (cooldown > 15) {
    process_keys_pages(Experiment_starting_keypress)
    Experiment_starting_keypress.start()
  }

  if (Experiment_starting_text.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
    Experiment_starting_text.setAutoDraw(false);
  }
  if (Experiment_starting_keypress.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
      Experiment_starting_keypress.status = PsychoJS.Status.FINISHED;
  }

  if (Experiment_starting_keypress.status === PsychoJS.Status.STARTED) {
    let theseKeys = Experiment_starting_keypress.getKeys({keyList: ['1', '0', '9' , '2', 'left', 'right', 'space'], waitRelease: false, clear: true});
    _Experiment_starting_keypress_allKeys = _Experiment_starting_keypress_allKeys.concat(theseKeys);
    if (_Experiment_starting_keypress_allKeys.length > 0) {
      Experiment_starting_keypress.keys = _Experiment_starting_keypress_allKeys[_Experiment_starting_keypress_allKeys.length - 1].name;  // just the last key pressed
      Experiment_starting_keypress.rt = _Experiment_starting_keypress_allKeys[_Experiment_starting_keypress_allKeys.length - 1].rt;
    }
  }

  if (change) {
    Experiment_starting_text.setText(opening_text[current_text_focus_element])
    console.log('Moving!!!')

    if (current_text_focus_element == consent_form_number_key){
        download_form( 'resources/sheet_lookup/IRB_13903_Online_Consent_Form_1hr_final.pdf'); // filePath = 'resources/sheet_lookup/Debriefing_temp.pdf'
    }
    console.log('compar:', pot_splitting_instructions_download_element, consent_form_number_key)


    if (pot_splitting_instructions_download_element == current_text_focus_element) {
      console.log('TEST TEST TEST TEST')
      download_form('resources/Pot_splitting_game_instructions.pdf')
    }

    if (investment_game_instructions_download_element == current_text_focus_element) {
      download_form('resources/Investing_game_INVESTOR_instructions.pdf')
    }

    change = false;
  }

 // console.log('prev current text focus:')
 // console.log(prev_current_text_focus_element)
 // console.log(current_text_focus_element)

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  if (opening_screen_bool)
    continueRoutine = false;
  console.log('continue routine:', continueRoutine)

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of experiment_startingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function experiment_startingRoutineEnd() {
  //------Ending Routine 'experiment_starting'-------
  for (const thisComponent of experiment_startingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('random_key_condition_order', random_key);
  psychoJS.experiment.addData('Experiment_starting_keypress.keys', Experiment_starting_keypress.keys);
  if (typeof Experiment_starting_keypress.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('Experiment_starting_keypress.rt', Experiment_starting_keypress.rt);
      }
  current_text_focus_element = 0; // reset it for the closing
  Experiment_starting_keypress.stop();
  // the Routine "Experiment_starting" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();

  opening_screen_bool = false;
  closing_screen_bool = false;

  return Scheduler.Event.NEXT;
}

var main_loop;
var currentLoop;
function main_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  main_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'sheet_lookup/post_FD/online_lookup_abridged.xlsx',
    //trialList: 'sheet_lookup/online_lookup_final' + random_key.toString() + '.xlsx', // + random_key.toString() +
    //trialList: 'sheet_lookup/' + 'online_lookup.xlsx',
    seed: undefined, name: 'main_loop'});
  psychoJS.experiment.addLoop(main_loop); // add the loop to the experiment
  currentLoop = main_loop;  // we're now the current loop

  console.log('current loop:', currentLoop)

  for (const thisMain_loop of main_loop) {
    console.log('this:', thisMain_loop)
    thisScheduler.add(importConditions(main_loop));
    thisScheduler.add(initRoutineBegin);
    thisScheduler.add(initRoutineEachFrame);
    thisScheduler.add(initRoutineEnd);
    const pairing_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(pairing_loopLoopBegin, pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopEnd);
    const prop_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(prop_loopLoopBegin, prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopEnd);
    const resp_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(resp_loopLoopBegin, resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopEnd);
    const investor_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(investor_loopLoopBegin, investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopEnd);
    const trustee_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(trustee_loopLoopBegin, trustee_loopLoopScheduler);
    thisScheduler.add(trustee_loopLoopScheduler);
    thisScheduler.add(trustee_loopLoopEnd);

    const trialsLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(trialsLoopBegin, trialsLoopScheduler);
    thisScheduler.add(trialsLoopScheduler);
    thisScheduler.add(trialsLoopEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }


 /* // Schedule all the trials in the trialList:
  for (const thisMain_loop of main_loop) {
    console.log('this main loop:', thisMain_loop)
    thisScheduler.add(importConditions(main_loop));
    thisScheduler.add(initRoutineBegin);
    thisScheduler.add(initRoutineEachFrame);
    thisScheduler.add(initRoutineEnd);
    const pairing_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(pairing_loopLoopBegin, pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopEnd);
    const prop_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(prop_loopLoopBegin, prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopEnd);
    const resp_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(resp_loopLoopBegin, resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopEnd);
    const investor_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(investor_loopLoopBegin, investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopEnd);
    const trustee_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(trustee_loopLoopBegin, trustee_loopLoopScheduler);
    thisScheduler.add(trustee_loopLoopScheduler);
    thisScheduler.add(trustee_loopLoopEnd);

    const trialsLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(trialsLoopBegin, trialsLoopScheduler);
    thisScheduler.add(trialsLoopScheduler);
    thisScheduler.add(trialsLoopEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }*/
  console.log('loop first done')
  return Scheduler.Event.NEXT;
}

var pairing_loop;
function pairing_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  pairing_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_pairing, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'pairing_loop'});
  psychoJS.experiment.addLoop(pairing_loop); // add the loop to the experiment
  currentLoop = pairing_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisPairing_loop of pairing_loop) {
    thisScheduler.add(importConditions(pairing_loop));
    thisScheduler.add(Subject_pairing_screenRoutineBegin);
    thisScheduler.add(Subject_pairing_screenRoutineEachFrame);
    thisScheduler.add(Subject_pairing_screenRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function pairing_loopLoopEnd() {
  psychoJS.experiment.removeLoop(pairing_loop);

  return Scheduler.Event.NEXT;
}

var prop_loop;
function prop_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  prop_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_proposer, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'prop_loop'});
  psychoJS.experiment.addLoop(prop_loop); // add the loop to the experiment
  currentLoop = prop_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisProp_loop of prop_loop) {
    thisScheduler.add(importConditions(prop_loop));
    thisScheduler.add(Proposer_proposeRoutineBegin);
    thisScheduler.add(Proposer_proposeRoutineEachFrame);
    thisScheduler.add(Proposer_proposeRoutineEnd);
    thisScheduler.add(Proposer_confirm_offerRoutineBegin);
    thisScheduler.add(Proposer_confirm_offerRoutineEachFrame);
    thisScheduler.add(Proposer_confirm_offerRoutineEnd);
    thisScheduler.add(Proposer_waitingRoutineBegin);
    thisScheduler.add(Proposer_waitingRoutineEachFrame);
    thisScheduler.add(Proposer_waitingRoutineEnd);
    thisScheduler.add(Proposer_view_outcomeRoutineBegin);
    thisScheduler.add(Proposer_view_outcomeRoutineEachFrame);
    thisScheduler.add(Proposer_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }
  console.log('PROP LOOP DONE')
  return Scheduler.Event.NEXT;
}


function prop_loopLoopEnd() {
  psychoJS.experiment.removeLoop(prop_loop);

  return Scheduler.Event.NEXT;
}

var resp_loop;
function resp_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  resp_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_responder, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'resp_loop'});
  psychoJS.experiment.addLoop(resp_loop); // add the loop to the experiment
  currentLoop = resp_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisResp_loop of resp_loop) {
    thisScheduler.add(importConditions(resp_loop));
    thisScheduler.add(Responder_waitingRoutineBegin);
    thisScheduler.add(Responder_waitingRoutineEachFrame);
    thisScheduler.add(Responder_waitingRoutineEnd);
    thisScheduler.add(Responder_view_offerRoutineBegin);
    thisScheduler.add(Responder_view_offerRoutineEachFrame);
    thisScheduler.add(Responder_view_offerRoutineEnd);
    thisScheduler.add(Responder_respondRoutineBegin);
    thisScheduler.add(Responder_respondRoutineEachFrame);
    thisScheduler.add(Responder_respondRoutineEnd);
    thisScheduler.add(Responder_view_outcomeRoutineBegin);
    thisScheduler.add(Responder_view_outcomeRoutineEachFrame);
    thisScheduler.add(Responder_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function resp_loopLoopEnd() {
  psychoJS.experiment.removeLoop(resp_loop);

  return Scheduler.Event.NEXT;
}

var investor_loop;
function investor_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  investor_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_investor, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'investor_loop'});
  psychoJS.experiment.addLoop(investor_loop); // add the loop to the experiment
  currentLoop = investor_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisInvestor_loop of investor_loop) {
    thisScheduler.add(importConditions(investor_loop));
    thisScheduler.add(Investor_investRoutineBegin);
    thisScheduler.add(Investor_investRoutineEachFrame);
    thisScheduler.add(Investor_investRoutineEnd);
    thisScheduler.add(Investor_confirm_amountRoutineBegin);
    thisScheduler.add(Investor_confirm_amountRoutineEachFrame);
    thisScheduler.add(Investor_confirm_amountRoutineEnd);
    thisScheduler.add(Investor_waitingRoutineBegin);
    thisScheduler.add(Investor_waitingRoutineEachFrame);
    thisScheduler.add(Investor_waitingRoutineEnd);
    thisScheduler.add(Investor_view_outcomeRoutineBegin);
    thisScheduler.add(Investor_view_outcomeRoutineEachFrame);
    thisScheduler.add(Investor_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function investor_loopLoopEnd() {
  psychoJS.experiment.removeLoop(investor_loop);

  return Scheduler.Event.NEXT;
}

var trustee_loop;
function trustee_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trustee_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_trustee, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'trustee_loop'});
  psychoJS.experiment.addLoop(trustee_loop); // add the loop to the experiment
  currentLoop = trustee_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrustee_loop of trustee_loop) {
    thisScheduler.add(importConditions(trustee_loop));
    thisScheduler.add(Trustee_waitingRoutineBegin);
    thisScheduler.add(Trustee_waitingRoutineEachFrame);
    thisScheduler.add(Trustee_waitingRoutineEnd);
    thisScheduler.add(Trustee_view_amountRoutineBegin);
    thisScheduler.add(Trustee_view_amountRoutineEachFrame);
    thisScheduler.add(Trustee_view_amountRoutineEnd);
    thisScheduler.add(Trustee_trustRoutineBegin);
    thisScheduler.add(Trustee_trustRoutineEachFrame);
    thisScheduler.add(Trustee_trustRoutineEnd);
    thisScheduler.add(Trustee_view_outcomeRoutineBegin);
    thisScheduler.add(Trustee_view_outcomeRoutineEachFrame);
    thisScheduler.add(Trustee_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function trustee_loopLoopEnd() {
  psychoJS.experiment.removeLoop(trustee_loop);

  return Scheduler.Event.NEXT;
}


var trials;
function trialsLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_none, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'trials'});
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial of trials) {
    thisScheduler.add(importConditions(trials));
    thisScheduler.add(no_roleRoutineBegin);
    thisScheduler.add(no_roleRoutineEachFrame);
    thisScheduler.add(no_roleRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}


function main_loopLoopEnd() {
  psychoJS.experiment.removeLoop(main_loop);
  console.log('main lop end')
  return Scheduler.Event.NEXT;
}

var initComponents;
var loop_pairing, loop_proposer, loop_responder, loop_investor, loop_trustee, loop_none;
function initRoutineBegin() {
  //------Prepare to start Routine 'init'-------
  t = 0;
  initClock.reset(); // clock
  frameN = -1;



  //console.log('Trial number')
  //console.log(trial_number)

  console.log('role1:', role_1)

  if (role_1 == 'r') {
    roleType = "Responder Role";
  } else if (role_1 == "p") {
    roleType = "Proposer Role";
  } else if (role_1 == 'i') {
    roleType = 'Investor Role';
  } else if (role_1 == 't') {
    roleType = 'Trustee Role';
  } else if (role_1 == 'n') {
    roleType = "No Role";
  } else if (role_1 == 's' || role_1 == '...') {
    roleType = ' ';
  }
  //roleType = 'Investor Role';
  if (roleType == ' ')
    routineTimer.add(0.01)
  else
    routineTimer.add(2.000000);

  console.log('experiment trial + pairing screen number:', trial_number)

  if (roleType == ' '){
    loop_pairing = 1;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
    loop_trustee = 0;
    loop_none = 0;
  } else if (roleType == "Proposer Role"){
    loop_pairing = 0;
    loop_proposer = 1;
    loop_responder = 0;
    loop_investor = 0;
    loop_trustee = 0;
    loop_none = 0;
  } else if (roleType == "Responder Role") {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 1;
    loop_investor = 0;
    loop_trustee = 0;
    loop_none = 0;
  } else if (roleType == "Investor Role"){
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 1;
    loop_trustee = 0;
    loop_none = 0;
  } else if (roleType == "Trustee Role") {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
    loop_trustee = 1;
    loop_none = 0;
  } else if (roleType == 'No Role') {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
    loop_trustee = 0;
    loop_none = 1;
  }
  //console.log('init trial:')
  //console.log(main_loop.getCurrentTrial())

  // update component parameters for each repeat
  role_type.setText(roleType);

  console.log('roleType:', roleType)
  console.log('loops', loop_trustee, loop_proposer, loop_none, loop_responder, loop_investor, loop_pairing)

  // keep track of which components have finished
  initComponents = [];
  initComponents.push(role_type);

  for (const thisComponent of initComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function initRoutineEachFrame() {
  //------Loop for each frame of Routine 'init'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = initClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *role_type* updates
  if (t >= 0.0 && role_type.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    role_type.tStart = t;  // (not accounting for frame time here)
    role_type.frameNStart = frameN;  // exact frame index
    role_type.setAutoDraw(true);
  }

  frameRemains = 0.0 + 2.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (role_type.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    role_type.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of initComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function initRoutineEnd() {
  //------Ending Routine 'init'-------
  for (const thisComponent of initComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var _Experiment_closing_keypress_allKeys;
var Experiment_closingComponents;
function Experiment_closingRoutineBegin(trials) {
  //------Prepare to start Routine 'Experiment_closing'-------
  t = 0;
  Experiment_closingClock.reset(); // clock
  frameN = -1;
  cooldown = 0;
  // update component parameters for each repeat
  Experiment_closing_keypress.keys = undefined;
  Experiment_closing_keypress.rt = undefined;
  _Experiment_closing_keypress_allKeys = [];
  // keep track of which components have finished
  Experiment_closingComponents = [];
  Experiment_closingComponents.push(Experiment_closing_text);
  Experiment_closingComponents.push(Experiment_closing_keypress);

  for (const thisComponent of Experiment_closingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

var closing_screen_bool;
function Experiment_closingRoutineEachFrame(trials) {
  //------Loop for each frame of Routine 'Experiment_closing'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Experiment_closingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  cooldown = cooldown + 1;
  // update/draw components on each frame

  // *Experiment_closing_text* updates
  if (t >= 0.0 && Experiment_closing_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_closing_text.tStart = t;  // (not accounting for frame time here)
    Experiment_closing_text.frameNStart = frameN;  // exact frame index

    Experiment_closing_text.setAutoDraw(true);
  }



  // *Experiment_closing_keypress* updates
  if (t >= 0.0 && Experiment_closing_keypress.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_closing_keypress.tStart = t;  // (not accounting for frame time here)
    Experiment_closing_keypress.frameNStart = frameN;  // exact frame index

    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.clearEvents(); });
  }

  closing_screen_bool = false;
  const prev_current_text_focus_element = current_text_focus_element;

  if (cooldown > 50) {
    process_keys_pages(Experiment_closing_keypress)
    Experiment_closing_keypress.start()
  }

  if (Experiment_closing_text.status === PsychoJS.Status.STARTED && Boolean(closing_screen_bool)) {
    Experiment_closing_text.setAutoDraw(false);
  }
  if (Experiment_closing_keypress.status === PsychoJS.Status.STARTED && Boolean(closing_screen_bool)) {
    Experiment_closing_keypress.status = PsychoJS.Status.FINISHED;
  }

  if (Experiment_closing_keypress.status === PsychoJS.Status.STARTED) {
    let theseKeys = Experiment_closing_keypress.getKeys({keyList: ['1', '0',  'left', 'right', 'space'], waitRelease: false, clear: true});
    _Experiment_closing_keypress_allKeys = _Experiment_closing_keypress_allKeys.concat(theseKeys);
    if (_Experiment_closing_keypress_allKeys.length > 0) {
      Experiment_closing_keypress.keys = _Experiment_closing_keypress_allKeys[_Experiment_closing_keypress_allKeys.length - 1].name;  // just the last key pressed
      Experiment_closing_keypress.rt = _Experiment_closing_keypress_allKeys[_Experiment_closing_keypress_allKeys.length - 1].rt;
    }
  }

  if (change) {
    Experiment_closing_text.setText(closing_text[current_text_focus_element])
    if (current_text_focus_element == consent_form_number_key)
      download_form('resources/sheet_lookup/13903_SONA_debriefing_form.pdf');
    change = false;
    Experiment_closing_keypress.keys = undefined;
    cooldown = 0;
    _Experiment_closing_keypress_allKeys = [];
    change = false; // new
  }

  //console.log('prev current text focus:')
  //console.log(prev_current_text_focus_element)
  //console.log(current_text_focus_element)

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return quitPsychoJS('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Experiment_closingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  } else {
    return Scheduler.Event.NEXT;
  }
}

function Experiment_closingRoutineEnd(trials) {
  //------Ending Routine 'Experiment_closing'-------
  for (const thisComponent of Experiment_closingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }

  psychoJS.experiment.addData('Experiment_closing_keypress.keys', Experiment_closing_keypress.keys);
  if (typeof Experiment_starting_keypress.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('Experiment_closing_keypress.rt', Experiment_closing_keypress.rt);
      }

  Experiment_closing_keypress.stop();
  // the Routine "Experiment_closing" was not non-slip safe, so reset the non-slip timer

  opening_screen_bool = false;
  closing_screen_bool = false;

  routineTimer.reset();

  return Scheduler.Event.NEXT;
}
function Subject_pairing_screenRoutineBegin() {
  computer = new Computer(computer_type_responder, computer_type_proposer); // new computer corresponding to new subjects
  console.log('test responder:', computer_type_responder)
  console.log('test proposer:', computer_type_proposer)
  //------Prepare to start Routine 'Subject_pairing_screen'-------
  t = 0;
  Subject_pairing_screenClock.reset(); // clock
  frameN = -1;
  expected_wait_frames = undefined;
  start_searching = false;
  // update component parameters for each repeat
  // keep track of which components have finished
  Subject_pairing_screen_text.setText('You are free to take a short' +
        ' break right now if you want (e.g., you can go to the bathroom). When you are ready to start playing with a new' +
        ' person, please press the space bar and the system will begin looking for a suitable one.')
  Subject_pairing_screenComponents = [];
  Subject_pairing_screenComponents.push(Subject_pairing_screen_text);
  for (const thisComponent of Subject_pairing_screenComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;


  return Scheduler.Event.NEXT;
}

const times = [];
let fps;

function refreshLoop() {
  window.requestAnimationFrame(() => {
    const now = performance.now();
    while (times.length > 0 && times[0] <= now - 1000) {
      times.shift();
    }
    times.push(now);
    fps = times.length;
    refreshLoop();
  });
}

refreshLoop();

var stop_searching;
var expected_wait;
var expected_wait_frames;
var steady_fps;
var start_searching;
function Subject_pairing_screenRoutineEachFrame(when_start=200) {
  //------Loop for each frame of Routine 'Subject_pairing_screen'-------
  let continueRoutine = true; // until we're told otherwise
  stop_searching = false;

  // get current time
  t = Subject_pairing_screenClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)

  // update/draw components on each frame

  // *Subject_pairing_screen_text* updates
  if (t >= 0.0 && Subject_pairing_screen_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Subject_pairing_screen_text.tStart = t;  // (not accounting for frame time here)
    Subject_pairing_screen_text.frameNStart = frameN;  // exact frame index
    Subject_pairing_screen_text.setAutoDraw(true);
  }


  /*if (frameN % 10 == 0){
    console.log('esc:');
    console.log('all:', psychoJS.eventManager.getKeys());
    console.log(psychoJS.eventManager.getKeys({keyList:['escope']}))
    console.log('---------')
  }*/

  if (psychoJS.eventManager.getKeys({keyList:['space']}).length > 0 ) {
    start_searching = true;
  }

  if (!start_searching) {
    frameN = 0; // i hope this doesn't cause problemos
  } else {

    let expected_wait_str = ''

    if (frameN % 150 == 0) {
      steady_fps = fps;
    }

    if (frameN == when_start) {
      expected_wait_frames = Math.floor(Math.random() * 20 + 5) * fps;
    } else if (frameN > when_start) {
      expected_wait_frames = expected_wait_frames - 1;
    }

    let expected_wait_seconds = Math.floor(expected_wait_frames / steady_fps);
    if (frameN >= when_start) {
      expected_wait_str = 'Expected wait: ' + expected_wait_seconds.toString() + ' seconds'
    }


    if (frameN % 15 == 0) {
      if ([1, 2, 3].includes(expected_wait_seconds)) { // NO: will make the numbers flash between red and white for the last 6 seconds (last frame = 0s)
        Subject_pairing_screen_text.setColor(new util.Color("red"));
      } else {
        Subject_pairing_screen_text.setColor(new util.Color("white"));
      }

      if (Math.floor(frameN * .02) % 4 == 0) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: \n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 1) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: .\n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 2) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: ..\n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 3) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: ...\n\n' + expected_wait_str)
      }
    }


    if (expected_wait_frames == 0) {
      stop_searching = true;
    }
  }

  if (Subject_pairing_screen_text.status === PsychoJS.Status.STARTED && Boolean(stop_searching)) {
    Subject_pairing_screen_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Subject_pairing_screenComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function download_form(filePath) {
    //download('resources/sheet_lookup/3_players_A.xlsx', 'Consent_Form.xlsx', '.xlsx')
    var a = document.createElement('A');
    a.href = filePath;
    a.download = filePath.substr(filePath.lastIndexOf('/') + 1);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function Subject_pairing_screenRoutineEnd() {
  //------Ending Routine 'Subject_pairing_screen'-------
  for (const thisComponent of Subject_pairing_screenComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  // the Routine "Subject_pairing_screen" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();

  return Scheduler.Event.NEXT;
}


var Proposer_proposeComponents;
function Proposer_proposeRoutineBegin() {
  //------Prepare to start Routine 'Proposer_propose'-------
  t = 0;
  Proposer_proposeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  kbd_offer.keys = undefined;
  kbd_offer.rt = undefined;
  // keep track of which components have finished
  Proposer_proposeComponents = [];
  Proposer_proposeComponents.push(Proposer_propose_text);
  Proposer_proposeComponents.push(kbd_offer);

  for (const thisComponent of Proposer_proposeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_proposeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_propose'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_proposeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_propose_text* updates
  if (t >= 0.0 && Proposer_propose_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_propose_text.tStart = t;  // (not accounting for frame time here)
    Proposer_propose_text.frameNStart = frameN;  // exact frame index
    Proposer_propose_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_propose_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_propose_text.setAutoDraw(false);
  }

  // *kbd_offer* updates
  if (t >= 0.0 && kbd_offer.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    kbd_offer.tStart = t;  // (not accounting for frame time here)
    kbd_offer.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { kbd_offer.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { kbd_offer.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { kbd_offer.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (kbd_offer.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    kbd_offer.status = PsychoJS.Status.FINISHED;
  }

  if (kbd_offer.status === PsychoJS.Status.STARTED) {
    let theseKeys = kbd_offer.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escope') { // changed from escope to disable
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      kbd_offer.keys = theseKeys[0].name;  // just the last key pressed
      kbd_offer.rt = theseKeys[0].rt;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_proposeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var subjectTake
var responderTake
function Proposer_proposeRoutineEnd() {
  //------Ending Routine 'Proposer_propose'-------
  for (const thisComponent of Proposer_proposeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('kbd_offer.keys', kbd_offer.keys);
  if (typeof kbd_offer.keys !== undefined) {  // we had a response
    psychoJS.experiment.addData('kbd_offer.rt', kbd_offer.rt);
  }

  kbd_offer.stop();

  if (kbd_offer.keys == null) {
    subjectTake = 0;
    responderTake = 0;
  } else {
    console.log(kbd_offer)
    var key = kbd_offer.keys;//.slice(-1)[0] // EDITTED!!!!!!
    console.log(kbd_offer);
    if (key == "1") {
      subjectTake = 9;
      responderTake = 1;
    } else if (key == '2') {
      subjectTake = 8;
      responderTake = 2;
    } else if (key == 'space') {
      subjectTake = 7;
      responderTake = 3;
    } else if (key == '9') {
      subjectTake = 6;
      responderTake = 4;
    } else if (key == '0') {
      subjectTake = 5;
      responderTake = 5;
    }
  }

  return Scheduler.Event.NEXT;
}


var Proposer_confirm_offerComponents;
function Proposer_confirm_offerRoutineBegin() {
  //------Prepare to start Routine 'Proposer_confirm_offer'-------
  t = 0;
  Proposer_confirm_offerClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (subjectTake == 0) {
    Proposer_confirm_offer_text.setText('You missed! \n \n You:      $0'  + '\n Player:   $0');
  } else {
    Proposer_confirm_offer_text.setText('You offer: \n \n You:      $' + subjectTake.toString() + '\n Player:   $' + responderTake.toString());
  }

  // keep track of which components have finished
  Proposer_confirm_offerComponents = [];
  Proposer_confirm_offerComponents.push(Proposer_confirm_offer_text);

  for (const thisComponent of Proposer_confirm_offerComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_confirm_offerRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_confirm_offer'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_confirm_offerClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_confirm_offer_text* updates
  if (t >= 0.0 && Proposer_confirm_offer_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_confirm_offer_text.tStart = t;  // (not accounting for frame time here)
    Proposer_confirm_offer_text.frameNStart = frameN;  // exact frame index
    Proposer_confirm_offer_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_confirm_offer_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_confirm_offer_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_confirm_offerComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_confirm_offerRoutineEnd() {
  //------Ending Routine 'Proposer_confirm_offer'-------
  for (const thisComponent of Proposer_confirm_offerComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var subjectPart;
var responderPart;

/*var computer = {
  respond_to_offer: function(offer) {
    var accept;
    if (offer <= 6) {
      accept = true;
    } else {
      accept = false;
    }

    if (accept) {
      subjectPart = subjectTake;
      responderPart = 10 - subjectTake;
    } else {
      subjectPart = 0;
      responderPart = 0;
    }

    this.subj_propose_history.push(offer)
    this.comp_response_history.push(accept)
  },

  propose_offer: function() {
    let offer = 6

    this.comp_propose_history.push(offer)
    return offer;
  },

  get_trustee_choice: function(trust_option_chosen_) {
    let random_response = Math.floor(Math.random() * 4);
    return [trust_option_chosen_.responses[random_response], random_response / 4];
  },

  update_subj_response_history: function (accept) {
    this.subj_response_history.push(accept)
  },
  subj_propose_history: [],
  comp_response_history: [],
  comp_propose_history: [],
  subj_response_history: []
 // }zzzzz
};*/


class Computer { // implement missing?
  constructor(responder_type, proposer_type, miss_computer_proposer_trial_number) {
    console.log('Getting new player')
    this.responder_type = responder_type;
    this.proposer_type = proposer_type;
    this.subj_propose_history = []
    this.comp_response_history = []
    this.comp_propose_history = []
    this.subj_response_history = []
    this.subj_response_history_dict = {};
    this.comp_response_history_dict = {};
    this.comp_last_offer_accept_response;
    this.miss_computer_proposer_trial_number = miss_computer_proposer_trial_number;
  }

  respond_to_offer(offer) {
    var accept;
    //if (this.responder_type == 'always_accept_max_generous'){
    //  accept = true;
    //} else
    if (this.responder_type == 'pure_tit_for_tat') {
      //offer = this.subj_response_history.slice(-1); // No this is computer responding the exact same way that the
      // subjects just did and that is silly. We dont want the computer rejecting offers of 5
      if (offer in this.subj_response_history_dict){
        accept = this.subj_response_history_dict[offer];
      } else {
        accept = this.get_response_from_distribution(offer);
      }
    } else if (this.responder_type == 'anti_tit_for_tat') {
      if (offer in this.subj_response_history_dict){
        accept = !this.subj_response_history_dict[offer];
      } else {
        accept = this.get_response_from_distribution(offer);
      }
    } else if (this.responder_type == 'based_on_proposer') {
      let offer_compare = this.propose_offer();
      this.comp_propose_history.pop();
      if (offer <= offer_compare)
        accept = true;
      else
        accept = false;
    } else {
      accept = this.get_response_from_distribution(offer);
    }
    console.log('past subj responses:', this.subj_response_history_dict);
    console.log('past subj responses[offer]:', this.subj_response_history_dict[offer]);

    this.subj_propose_history.push(offer)
    this.comp_response_history.push(accept)
    return accept;
  }

  get_response_from_distribution(offer) {
    let dist;
    if (this.responder_type == 'always_accept_max_generous'){
      dist = {5: .00, 6: .00, 7: .00, 8: .00, 9: .00};
    } else if (this.responder_type == 'subject_max_accept') {
      dist = {5: .00, 6: .00, 7: .00, 8: .00, 9: .24};
    } else if (this.responder_type == 'subject_max_reject'){
      dist = {5: .00, 6: .5, 7: .9375, 8: .96775, 9: .0}; // not the most rejecting... the third most, the others had 6: <= .25
    } else if (this.responder_type == 'human_distribution' || this.responder_type == 'pure_tit_for_tat'){
      dist = {5: .00, 6: .12, 7: .45, 8: .67, 9: .75};
    } else if (this.responder_type == 'more_random'){
      dist = {5: .00, 6: .278, 7: .478, 8: .586, 9: .632}; // p of (above) human distribution -> z score -> divide by 2 -> new p
    } else if (this.responder_type == 'irrational') {
      dist = {5: .2, 6: .6, 7: .4, 8: .3, 9: .2};
    } else if (this.responder_type == 'stern') {
      dist = {5: .00, 6: .3, 7: 1.0, 8: 1.0, 9: 1.0};
    } else {
      console.log('ERROR #1 - invalid rspdr')
      dist = {5: .00, 6: .12, 7: .45, 8: .67, 9: .75};
    }

    let ran_val = Math.random();
    let ran_compare = dist[offer];

    /*
    if (offer == 5) {
      ran_compare = .01;
    } else if (offer == 6) {
      ran_compare = .12;
    } else if (offer == 7) {
      ran_compare = .45;
    } else if (offer == 8) {
      ran_compare = .67;
    } else if (offer == 9) {
      ran_compare = .75;
    }*/

    if (ran_val > ran_compare)
      return true
    else
      return false

  }

  get_propose_from_distribution() {

    let dist;
    if (this.proposer_type == 'always_accept_max_generous') {
      dist = {5: 1.0, 6: 1.0, 7: 1.0, 8: 1.0, 9: 1.0};
    } else if (this.propser_type == 'real_subject_generous') {
      dist = {5: .625, 6: .943, 7: .99, 8: 1.0, 9: 1.0};
    } else if (this.proposer_type == 'real_subject_selfish') {
      dist = {5: .151, 6: .344, 7: .589, 8: .808, 9: 1.0};
      // the difference between a number and the previous one is the probability of proposing that amount
    } else if (this.proposer_type == 'human_distribution' || this.proposer_type == 'pure_tit_for_tat' || this.proposer_type == 'anti_tit_for_tat' || this.proposer_type == 'tit_for_tat_if_comp_accept_else_partial_mimic'){ // should do .includes
      dist = {5: .182, 6: .631, 7: .883, 8: .954, 9: 1.0};
    } else if (this.proposer_type == 'random_dude'){
      dist = {5: .2, 6: .4, 7: .6, 8: .8, 9: 1.0};
    } else {
      console.log('ERROR #0 - invalid PropsrType');
      dist = {5: .182, 6: .631, 7: .883, 8: .954, 9: 1.0};
    }

    let ran_val = Math.random();
    for (const i of Array(5).keys()){
      //console.log()
      //console.log('ran val:', ran_val)
      //console.log('dist i:', dist[i+5])
      if (ran_val < dist[i+5]){
        return i+5
      }
    }
    return 9

  }

  update_response_dictionary(resp_dict) {
    console.log('updating response history dict:', resp_dict)
    for (const i of Array(4).keys()){
      if (!resp_dict[i+5] && typeof resp_dict[i+5] !== 'undefined') { // !undefined = True
        resp_dict[i+6] = false;
      }
    }
    for (const i of Array(4).keys()){
      if (resp_dict[9-i]) {
        resp_dict[8-i] = true;
      }
    }
    console.log('updated:', resp_dict)

  }

  propose_offer() {
    console.log('proposer type:', this.proposer_type)
    console.log('responder type:', this.responder_type)

    let offer;
    let proposed_trial_number = this.comp_propose_history.length;
    if (proposed_trial_number == this.miss_computer_proposer_trial_number && typeof this.miss_computer_proposer_trial_number !== 'undefined'){
      offer = 0;
      this.comp_propose_history.push(offer);
      return offer;
    }

    if (['always_accept_max_generous', 'human_distribution', 'random_dude', 'real_subject_generous', 'real_subject_selfish'].includes(this.proposer_type)){
      offer = this.get_propose_from_distribution()
    } else if (this.proposer_type == 'pure_tit_for_tat') {
      if (this.subj_propose_history.slice(-1) < 5)
        offer = this.get_propose_from_distribution();
      else
        offer = this.subj_propose_history.slice(-1);
    } else if (this.proposer_type == 'anti_tit_for_tat') {
      if (this.subj_propose_history.slice(-1) < 5)
        offer = this.get_propose_from_distribution();
      else
        offer = 9 - (this.subj_propose_history.slice(-1) - 5);
    } else if (this.proposer_type == 'anti_tit_for_tat_partial') {
      let prev_subj_proposed = this.subj_propose_history.slice(-1);
          console.log('subj propose history:', this.subj_propose_history)

      if (!prev_subj_proposed) { // this first if catches instances where the subject just missed
        if (this.comp_propose_history.slice(-1)){
          offer = this.comp_propose_history.slice(-1);
        } else {
          offer = this.get_propose_from_distribution()
        }
      } else {
        if (this.comp_response_history.slice(-1)) {
          offer = 14 - prev_subj_proposed;
        } else { // set the computer's proposed offer to one less than what was received unless the pc prev proposed is 2
          // or more more generous, then just propose $1 more selfishly relative to before
          // in practice this may never hit if the ... !is incorporated as subjects wouldn't
          // e.g., reject $7 if they just proposed $8
          let prev_comp_proposed = this.comp_propose_history.slice(-1);
          if (prev_comp_proposed < 14 - prev_subj_proposed) {
            offer = prev_comp_proposed + 1;
          } else if (prev_comp_proposed > 14 - prev_subj_proposed) {
            offer = prev_comp_proposed - 1;
          } else {
            offer = prev_comp_proposed
          }
        }
      }
    } else if (this.proposer_type == 'anti_tit_for_tat_partial_sensible') {
      this.proposer_type = 'anti_tit_for_tat_partial';
      offer = this.propose_offer();
      this.proposer_type = 'anti_tit_for_tat_partial_sensible';
      if (this.subj_propose_history.slice(-1) == 7){
        console.log('prev subject proposed = 7')
        offer = 7 -1 + Math.floor(Math.random() + .5)*2; // If it was 7 it is now set to
      }

    } else if (this.proposer_type == 'tit_for_tat_if_comp_accept_else_partial_mimic') {
      let prev_subj_proposed = this.subj_propose_history.slice(-1);
      console.log('subj propose history:', this.subj_propose_history)

      if (!prev_subj_proposed) { // this first if catches instances where the subject just missed
        if (this.comp_propose_history.slice(-1)){
          offer = this.comp_propose_history.slice(-1);
        } else {
          offer = this.get_propose_from_distribution()
        }
      } else {
        if (this.comp_response_history.slice(-1)) {
          offer = prev_subj_proposed;
        } else { // set the computer's proposed offer to one less than what was received unless the pc prev proposed is 2
          // or more more generous, then just propose $1 more selfishly relative to before
          // in practice this may never hit if the ... !is incorporated as subjects wouldn't
          // e.g., reject $7 if they just proposed $8
          let prev_comp_proposed = this.comp_propose_history.slice(-1);
          if (prev_comp_proposed < prev_subj_proposed) {
            offer = prev_comp_proposed + 1;
          } else if (prev_comp_proposed > prev_subj_proposed) {
            offer = prev_comp_proposed - 1;
          } else {
            offer = prev_comp_proposed
          }
        }
      }

    } else if (this.proposer_type == 'strategic') {
      let broken = false;
      console.log('subj response history:', this.subj_response_history_dict)
      for (const i of Array(4).keys()){
        if (this.subj_response_history_dict[9-i] || !(9-i in this.subj_response_history_dict)) { // looks for the most selfish thing that the subject will accept
          offer = 9-i
          broken = true;
          break
        }
      }
      if (!broken) {
        offer = 5;
      }
    }
    if (!(offer > 4 && offer < 10)) {
      console.log('WARNING #2')
      offer = this.get_propose_from_distribution()
    }
    console.log('history:', this.subj_propose_history)
    this.comp_propose_history.push(offer);
    return offer;
  }

  update_subj_response_history(offer, accept) {
    this.subj_response_history.push(accept);
    this.subj_response_history_dict[offer] = accept;
    this.update_response_dictionary(this.subj_response_history_dict)

  }

  get_trustee_choice(trust_option_chosen_) {
    let random_response = Math.floor(Math.random() * 4);
    return [trust_option_chosen_.responses[random_response], random_response / 4];
  }

}

var computer;// = new Computer('always_accept_max_generous');

var Proposer_waitingComponents;
function Proposer_waitingRoutineBegin() {
  //------Prepare to start Routine 'Proposer_waiting'-------
  t = 0;
  Proposer_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (subjectTake > 0){
    Proposer_waiting_text.setText('Waiting for the Responder to respond');
  } else {
    Proposer_waiting_text.setText('You missed!');
  }

  let accept = computer.respond_to_offer(subjectTake);

  if (accept) {
    subjectPart = subjectTake;
    responderPart = 10 - subjectTake;
  } else {
    subjectPart = 0;
    responderPart = 0;
  }

  // keep track of which components have finished
  Proposer_waitingComponents = [];
  Proposer_waitingComponents.push(Proposer_waiting_text);

  for (const thisComponent of Proposer_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *text* updates
  if (t >= 0.0 && Proposer_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_waiting_text.tStart = t;  // (not accounting for frame time here)
    Proposer_waiting_text.frameNStart = frameN;  // exact frame index
    Proposer_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_waitingRoutineEnd() {
  //------Ending Routine 'Proposer_waiting'-------
  for (const thisComponent of Proposer_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Proposer_view_outcomeComponents;
function Proposer_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Proposer_view_outcome'-------
  t = 0;
  Proposer_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.50000);
  // update component parameters for each repeat
  if (subjectTake == 0) {
     Proposer_view_outcome_text.setColor(new util.Color("red"));
     Proposer_view_outcome_text.setText('You missed!!\n' + 'You get:      $0' + '\nPlayer gets:   $0');

  } else {
    if (subjectPart > 0) {
      // Proposer_view_outcome_text.setColor(new util.Color(resp_color));
      Proposer_view_outcome_text.setColor(new util.Color("green"));
      Proposer_view_outcome_text.setText('Offer acepted!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + responderPart.toString());
    } else {
      Proposer_view_outcome_text.setColor(new util.Color("red"));
      Proposer_view_outcome_text.setText('Offer rejected!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + responderPart.toString());
    }
  }

  // Proposer_view_outcome_text.setText(((((((resp_answer_proposed_formatted + '\n \n') + 'You get:      $') + str(subjectPart)) + '\nPlayer gets:   $') + str(responderPart)) + 'if subjectTake > 0 else You missed! Please keep waiting for the next trial...'));
  // keep track of which components have finished
  Proposer_view_outcomeComponents = [];
  Proposer_view_outcomeComponents.push(Proposer_view_outcome_text);

  for (const thisComponent of Proposer_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_view_outcome_text* updates
  if (t >= 0.0 && Proposer_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Proposer_view_outcome_text.frameNStart = frameN;  // exact frame index
    Proposer_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_view_outcomeRoutineEnd() {
  //------Ending Routine 'Proposer_view_outcome'-------
  for (const thisComponent of Proposer_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  console.log('FUCK THIS')

  return Scheduler.Event.NEXT;
}

var Responder_waitingComponents;
var proposerTake;
function Responder_waitingRoutineBegin() {
  //------Prepare to start Routine 'Responder_waiting'-------
  t = 0;
  Responder_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Responder_waitingComponents = [];
  Responder_waitingComponents.push(Responder_waiting_text);

  proposerTake = computer.propose_offer()
  for (const thisComponent of Responder_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_waiting_text* updates
  if (t >= 0.0 && Responder_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_waiting_text.tStart = t;  // (not accounting for frame time here)
    Responder_waiting_text.frameNStart = frameN;  // exact frame index
    Responder_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_waitingRoutineEnd() {
  //------Ending Routine 'Responder_waiting'-------
  for (const thisComponent of Responder_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Responder_view_offerComponents;
function Responder_view_offerRoutineBegin() {
  //------Prepare to start Routine 'Responder_view_offer'-------
  t = 0;
  Responder_view_offerClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (proposerTake == 0){
    // we could have subjects' partners miss... but then they may see their partner as incompetent...
    // what if subjects that miss like other people that miss? YES, more similarity testing
    Responder_view_offer_text.setText('The other player missed!\n\n' +
                                      'Player:   $' + proposerTake.toString() + '\n You:      $' + (10-proposerTake).toString());
    console.log('THE OTHER PLAYER MISSED!!!!')
  } else {
    Responder_view_offer_text.setText('Player:   $' + proposerTake.toString() + '\n You:      $' + (10-proposerTake).toString());
  }
  // keep track of which components have finished
  Responder_view_offerComponents = [];
  Responder_view_offerComponents.push(Responder_view_offer_text);

  for (const thisComponent of Responder_view_offerComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_view_offerRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_view_offer'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_view_offerClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_view_offer_text* updates
  if (t >= 0.0 && Responder_view_offer_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_view_offer_text.tStart = t;  // (not accounting for frame time here)
    Responder_view_offer_text.frameNStart = frameN;  // exact frame index
    Responder_view_offer_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_view_offer_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_view_offer_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_view_offerComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_view_offerRoutineEnd() {
  //------Ending Routine 'Responder_view_offer'-------
  for (const thisComponent of Responder_view_offerComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Responder_respondComponents;
function Responder_respondRoutineBegin() {
  //------Prepare to start Routine 'Responder_respond'-------
  t = 0;
  Responder_respondClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  missed = true;
  offer_rating.keys = undefined;
  offer_rating.rt = undefined;
  // keep track of which components have finished
  Responder_respondComponents = [];
  Responder_respondComponents.push(Responder_respond_text);
  Responder_respondComponents.push(offer_rating);

  for (const thisComponent of Responder_respondComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  var miss_or_Responder_respond_text = 'strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n' + ' accept                                                          reject\n\n' + '      1                2            space          9              0'
  Responder_respond_text.setText(miss_or_Responder_respond_text);

  return Scheduler.Event.NEXT;


}

var missed;
function Responder_respondRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_respond'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_respondClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_respond_text* updates
  if (t >= 0.0 && Responder_respond_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_respond_text.tStart = t;  // (not accounting for frame time here)
    Responder_respond_text.frameNStart = frameN;  // exact frame index
    Responder_respond_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_respond_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_respond_text.setAutoDraw(false);
  }

 // if (Responder_respond_text.status === PsychoJS.Status.STARTED){ // only update if being drawn
  //  Responder_respond_text.setText(miss_or_Responder_respond_text);
  //}

  // *offer_rating* updates
  if (t >= 0.0 && offer_rating.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    offer_rating.tStart = t;  // (not accounting for frame time here)
    offer_rating.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { offer_rating.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { offer_rating.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { offer_rating.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (offer_rating.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    offer_rating.status = PsychoJS.Status.FINISHED;
  }

  if (offer_rating.status === PsychoJS.Status.STARTED) {
    let theseKeys = offer_rating.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escope') {
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      offer_rating.keys = theseKeys[0].name;  // just the last key pressed
      offer_rating.rt = theseKeys[0].rt;
      missed = false;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_respondComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var proposerPart;
function Responder_respondRoutineEnd() {
  //------Ending Routine 'Responder_respond'-------
  for (const thisComponent of Responder_respondComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('offer_rating.keys', offer_rating.keys);
  if (typeof offer_rating.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('offer_rating.rt', offer_rating.rt);
      }

 // EDITTED!!!!!!
  if (offer_rating.keys == null) {
      proposerPart = 0;
      subjectPart = 0;
  } else {
    console.log(offer_rating)
    var key = offer_rating.keys;//.slice(-1)[0] TESTING THIS NO SLICE OUT
    if (key == "1"){
      proposerPart = proposerTake;
      subjectPart = 10 - proposerTake;
    } else if (key == '2'){
      proposerPart = proposerTake;
      subjectPart = 10 - proposerTake;
    } else if (key == 'space'){
      proposerPart = 0;
      subjectPart = 0;
    } else if (key == '9'){
      proposerPart = 0;
      subjectPart = 0;
    } else if (key == '0'){
      proposerPart = 0;
      subjectPart = 0;
    }
    computer.update_subj_response_history(proposerTake, Boolean(proposerPart)); //Boolean(proposerPart) = true if > 0, false if = 0
  }

  offer_rating.stop();
  return Scheduler.Event.NEXT;
}

var Responder_view_outcomeComponents;
function Responder_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Responder_view_outcome'-------
  t = 0;
  Responder_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.50000);
  // update component parameters for each repeat
  // Responder_view_outcome_text.setColor(new util.Color(Responder_view_outcome_text_color));
  // Responder_view_outcome_text.setText(((((((resp_answer + '\n \n') + 'Player gets:   $') + str(proposerPart)) + '\nYou get:      $') + str(subjectPart)) + 'if proposerTake > 0 else Please keep waiting for the next trial to begin...'));
  // keep track of which components have finished
  if (missed) {
    Responder_view_outcome_text.setColor(new util.Color("red"));
    Responder_view_outcome_text.setText('Offer missed!\n' + 'You get:      $0' + '\nPlayer gets:   $0');
  }else if (subjectPart > 0) {
    // Proposer_view_outcome_text.setColor(new util.Color(resp_color));
    Responder_view_outcome_text.setColor(new util.Color("green"));
    Responder_view_outcome_text.setText('Offer acepted!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + proposerPart.toString());
  } else {
    Responder_view_outcome_text.setColor(new util.Color("red"));
    Responder_view_outcome_text.setText('Offer rejected!\n' + 'You get:      $0' + '\nPlayer gets:   $0');
  }


  Responder_view_outcomeComponents = [];
  Responder_view_outcomeComponents.push(Responder_view_outcome_text);

  for (const thisComponent of Responder_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_view_outcome_text* updates
  if (t >= 0.0 && Responder_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Responder_view_outcome_text.frameNStart = frameN;  // exact frame index
    Responder_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_view_outcomeRoutineEnd() {
  //------Ending Routine 'Responder_view_outcome'-------
  for (const thisComponent of Responder_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}


function Investor_investRoutineBegin() {
  //------Prepare to start Routine 'Investor_invest'-------
  t = 0;
  Investor_investClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.000000);
  // update component parameters for each repeat
  Investor_key_input.keys = undefined;
  Investor_key_input.rt = undefined;
  // keep track of which components have finished
  Investor_investComponents = [];
  Investor_investComponents.push(Investor_invest_text);
  Investor_investComponents.push(Investor_key_input);

  for (const thisComponent of Investor_investComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_investRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_invest'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_investClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_invest_text* updates
  if (t >= 0.0 && Investor_invest_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_invest_text.tStart = t;  // (not accounting for frame time here)
    Investor_invest_text.frameNStart = frameN;  // exact frame index
    Investor_invest_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_invest_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_invest_text.setAutoDraw(false);
  }

  // *Investor_key_input* updates
  if (t >= 0.0 && Investor_key_input.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_key_input.tStart = t;  // (not accounting for frame time here)
    Investor_key_input.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Investor_key_input.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Investor_key_input.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Investor_key_input.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_key_input.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_key_input.status = PsychoJS.Status.FINISHED;
  }

  if (Investor_key_input.status === PsychoJS.Status.STARTED) {
    let theseKeys = Investor_key_input.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escope') {
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      Investor_key_input.keys = theseKeys[0].name;  // just the last key pressed
      Investor_key_input.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_investComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var trust_option_chosen;
var trust_response_missed;
function Investor_investRoutineEnd() {
  //------Ending Routine 'Investor_invest'-------
  for (const thisComponent of Investor_investComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Investor_key_input.keys', Investor_key_input.keys);
  if (typeof Investor_key_input.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Investor_key_input.rt', Investor_key_input.rt);
      routineTimer.reset();
      }
  console.log(Investor_key_input)
  console.log('A')
  if (Investor_key_input.keys == null) {
    trust_response_missed = true;
    trust_option_chosen = trust_options.option1;
  } else {
    trust_response_missed = false;
    console.log(Investor_key_input)
    console.log('test')
    var key = Investor_key_input.keys; // EDITTED!!!!!!
    if (key == "1") {
      trust_option_chosen = trust_options.option1
    } else if (key == '2') {
      trust_option_chosen = trust_options.option2
    } else if (key == 'space') {
      trust_option_chosen = trust_options.option3
    } else if (key == '9') {
      trust_option_chosen = trust_options.option4
    } else if (key == '0') {
      trust_option_chosen = trust_options.option5
    }
  }
  console.log('meme')
  console.log(trust_option_chosen)
  Investor_key_input.stop();
  return Scheduler.Event.NEXT;
}

function Investor_confirm_amountRoutineBegin() {
  //------Prepare to start Routine 'Investor_confirm_amount'-------
  t = 0;
  Investor_confirm_amountClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.000000);
  // update component parameters for each repeat

  console.log('confirm:')
  console.log(trust_option_chosen)
  console.log(trust_option_chosen.amount)
  const max_return = trust_option_chosen.amount*3;
  const amount_kept = 20 - trust_option_chosen.amount;

  if (trust_response_missed) {
    Investor_confirm_amount_text.setText('You missed! \n \n Trusting:      $0' +
                                       '\nYou kept:       $20' +
                                       '\nMax return:     $0');
  } else {
    Investor_confirm_amount_text.setText('You invested:    $' + trust_option_chosen.amount.toString() +
                                       '\nYou kept:        $' + amount_kept.toString() +
                                       '\nMax return (3x): $' + max_return.toString());
  }


  // keep track of which components have finished
  Investor_confirm_amountComponents = [];
  Investor_confirm_amountComponents.push(Investor_confirm_amount_text);

  for (const thisComponent of Investor_confirm_amountComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_confirm_amountRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_confirm_amount'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_confirm_amountClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_confirm_amount_text* updates
  if (t >= 0.0 && Investor_confirm_amount_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_confirm_amount_text.tStart = t;  // (not accounting for frame time here)
    Investor_confirm_amount_text.frameNStart = frameN;  // exact frame index
    Investor_confirm_amount_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_confirm_amount_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_confirm_amount_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_confirm_amountComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_confirm_amountRoutineEnd() {
  //------Ending Routine 'Investor_confirm_amount'-------
  for (const thisComponent of Investor_confirm_amountComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var trustReturn, trustProportion;
function Investor_waitingRoutineBegin() {
  //------Prepare to start Routine 'Investor_waiting'-------
  t = 0;
  Investor_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Investor_waitingComponents = [];
  Investor_waitingComponents.push(Investor_waiting_text);

  const vals = computer.get_trustee_choice(trust_option_chosen);
  trustReturn = vals[0];
  trustProportion = vals[1];

  for (const thisComponent of Investor_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_waiting_text* updates
  if (t >= 0.0 && Investor_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_waiting_text.tStart = t;  // (not accounting for frame time here)
    Investor_waiting_text.frameNStart = frameN;  // exact frame index
    Investor_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_waitingRoutineEnd() {
  //------Ending Routine 'Investor_waiting'-------
  for (const thisComponent of Investor_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

function Investor_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Investor_view_outcome'-------
  t = 0;
  Investor_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.00000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Investor_view_outcomeComponents = [];
  Investor_view_outcomeComponents.push(Investor_view_outcome_text);

  for (const thisComponent of Investor_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  if (trust_response_missed) {
    Investor_view_outcome_text.setText('You missed!' +
                                    '\n\nOutcome you:    $20' +
                                      '\nOutcome player:   $0')
  } else {
    let outcome_investor = 20 - trust_option_chosen.amount + trustReturn;
    let outcome_trustee = trust_option_chosen.amount * 3 - trustReturn;



    Investor_view_outcome_text.setText('You invested:      $' + trust_option_chosen.amount.toString() +
                                   '\n\nPlayer returned:   $' + trustReturn.toString() +
                                   '\n\nOutcome you:       $' + outcome_investor.toString() +
                                     '\nOutcome player:    $' + outcome_trustee.toString())
  }

  return Scheduler.Event.NEXT;
}

function Investor_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_view_outcome_text* updates
  if (t >= 0.0 && Investor_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Investor_view_outcome_text.frameNStart = frameN;  // exact frame index
    Investor_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 6.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_view_outcomeRoutineEnd() {
  //------Ending Routine 'Investor_view_outcome'-------
  for (const thisComponent of Investor_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

function Trustee_waitingRoutineBegin() {
  //------Prepare to start Routine 'Trustee_waiting'-------
  t = 0;
  Trustee_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Trustee_waitingComponents = [];
  Trustee_waitingComponents.push(Trustee_waiting_text);

  for (const thisComponent of Trustee_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Trustee_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Trustee_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Trustee_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Trustee_waiting_text* updates
  if (t >= 0.0 && Trustee_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Trustee_waiting_text.tStart = t;  // (not accounting for frame time here)
    Trustee_waiting_text.frameNStart = frameN;  // exact frame index
    Trustee_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Trustee_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Trustee_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Trustee_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Trustee_waitingRoutineEnd() {
  //------Ending Routine 'Trustee_waiting'-------
  for (const thisComponent of Trustee_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

function Trustee_view_amountRoutineBegin() {
  //------Prepare to start Routine 'Trustee_view_amount'-------
  t = 0;
  Trustee_view_amountClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Trustee_view_amountComponents = [];
  Trustee_view_amountComponents.push(Trustee_view_amount_text);

  for (const thisComponent of Trustee_view_amountComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Trustee_view_amountRoutineEachFrame() {
  //------Loop for each frame of Routine 'Trustee_view_amount'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Trustee_view_amountClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Trustee_view_amount_text* updates
  if (t >= 0.0 && Trustee_view_amount_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Trustee_view_amount_text.tStart = t;  // (not accounting for frame time here)
    Trustee_view_amount_text.frameNStart = frameN;  // exact frame index
    Trustee_view_amount_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Trustee_view_amount_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Trustee_view_amount_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Trustee_view_amountComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Trustee_view_amountRoutineEnd() {
  //------Ending Routine 'Trustee_view_amount'-------
  for (const thisComponent of Trustee_view_amountComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

function Trustee_trustRoutineBegin() {
  //------Prepare to start Routine 'Trustee_trust'-------
  t = 0;
  Trustee_trustClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  trustee_key_input.keys = undefined;
  trustee_key_input.rt = undefined;
  // keep track of which components have finished
  Trustee_trustComponents = [];
  Trustee_trustComponents.push(trustee_key_input);
  Trustee_trustComponents.push(Trustee_trust_text);

  for (const thisComponent of Trustee_trustComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Trustee_trustRoutineEachFrame() {
  //------Loop for each frame of Routine 'Trustee_trust'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Trustee_trustClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *trustee_key_input* updates
  if (t >= 0.0 && trustee_key_input.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    trustee_key_input.tStart = t;  // (not accounting for frame time here)
    trustee_key_input.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { trustee_key_input.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { trustee_key_input.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { trustee_key_input.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (trustee_key_input.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    trustee_key_input.status = PsychoJS.Status.FINISHED;
  }

  if (trustee_key_input.status === PsychoJS.Status.STARTED) {
    let theseKeys = trustee_key_input.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escope') {
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      trustee_key_input.keys = theseKeys[0].name;  // just the last key pressed
      trustee_key_input.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }


  // *Trustee_trust_text* updates
  if (t >= 0.0 && Trustee_trust_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Trustee_trust_text.tStart = t;  // (not accounting for frame time here)
    Trustee_trust_text.frameNStart = frameN;  // exact frame index
    Trustee_trust_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Trustee_trust_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Trustee_trust_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Trustee_trustComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Trustee_trustRoutineEnd() {
  //------Ending Routine 'Trustee_trust'-------
  for (const thisComponent of Trustee_trustComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('trustee_key_input.keys', trustee_key_input.keys);
  if (typeof trustee_key_input.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('trustee_key_input.rt', trustee_key_input.rt);
      routineTimer.reset();
      }

  trustee_key_input.stop();
  return Scheduler.Event.NEXT;
}

function Trustee_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Trustee_view_outcome'-------
  t = 0;
  Trustee_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.500000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Trustee_view_outcomeComponents = [];
  Trustee_view_outcomeComponents.push(Trustee_view_outcome_text);

  for (const thisComponent of Trustee_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Trustee_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Trustee_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Trustee_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Trustee_view_outcome_text* updates
  if (t >= 0.0 && Trustee_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Trustee_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Trustee_view_outcome_text.frameNStart = frameN;  // exact frame index
    Trustee_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Trustee_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Trustee_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Trustee_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Trustee_view_outcomeRoutineEnd() {
  //------Ending Routine 'Trustee_view_outcome'-------
  for (const thisComponent of Trustee_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var no_roleComponents;
function no_roleRoutineBegin() {
  //------Prepare to start Routine 'no_role'-------
  t = 0;
  no_roleClock.reset(); // clock
  frameN = -1;
  routineTimer.add(10.500000);
  // update component parameters for each repeat
  // keep track of which components have finished
  no_roleComponents = [];
  no_roleComponents.push(text_4);

  for (const thisComponent of no_roleComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function no_roleRoutineEachFrame() {
  //------Loop for each frame of Routine 'no_role'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = no_roleClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *text_4* updates
  if (t >= 0.0 && text_4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    text_4.tStart = t;  // (not accounting for frame time here)
    text_4.frameNStart = frameN;  // exact frame index
    text_4.setAutoDraw(true);
  }

  frameRemains = 0.0 + 10.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (text_4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    text_4.setAutoDraw(false);
  }

  const t_left = Math.round(routineTimer.getTime())


  var time_left_color;
  if (t_left > 3) {
    time_left_color = 'white';
  } else {
    time_left_color = 'red';
  }

  if (text_4.status === PsychoJS.Status.STARTED){ // only update if being drawn
    text_4.setColor(new util.Color(time_left_color));
    text_4.setText('Next trial starting in: ' + t_left.toString());
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return psychoJS.quit('The [escope] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of no_roleComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function no_roleRoutineEnd() {
  //------Ending Routine 'no_role'-------
  for (const thisComponent of no_roleComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}





function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});

  return Scheduler.Event.QUIT;
}


var slider_loop;
var currentLoop;
function slider_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  slider_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'questions_slider_final.csv',
    seed: undefined, name: 'slider_loop'
  });
  psychoJS.experiment.addLoop(slider_loop); // add the loop to the experiment
  currentLoop = slider_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisSlider_loop of slider_loop) {
    const snapshot = slider_loop.getSnapshot();
    thisScheduler.add(importConditions_slider(snapshot));
    thisScheduler.add(slider_testRoutineBegin(snapshot));
    thisScheduler.add(slider_testRoutineEachFrame(snapshot));
    thisScheduler.add(slider_testRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  }

//    for (const thisMain_loop of main_loop) {
 //   console.log('this:', thisMain_loop)
  //  thisScheduler.add(importConditions(main_loop));
 //   thisScheduler.add(initRoutineBegin);
 //   thisScheduler.add(initRoutineEachFrame);
 //   thisScheduler.add(initRoutineEnd);

  return Scheduler.Event.NEXT;
}


function slider_loopLoopEnd() {
  psychoJS.experiment.removeLoop(slider_loop);

  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var slider_testComponents;
var _slider_keypress_allKeys;

function slider_testRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'slider_test'-------

    t = 0;
    slider_testClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    slider_text.setText(desc);
    move_it_around.reset()
    slider_keypress.keys = undefined;
    slider_keypress.rt = undefined;
    _slider_keypress_allKeys = [];
    // keep track of which components have finished
    slider_testComponents = [];
    slider_testComponents.push(slider_text);
    slider_testComponents.push(move_it_around);
    slider_testComponents.push(slider_keypress);

    for (const thisComponent of slider_testComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;

    return Scheduler.Event.NEXT;
  };
}


var first_slider_routine = true;

var continueRoutine;
function slider_testRoutineEachFrame(trials) {
  return function () {

    //------Loop for each frame of Routine 'slider_test'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = slider_testClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame

    // *slider_text* updates
    if (t >= 0.0 && slider_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider_text.tStart = t;  // (not accounting for frame time here)
      slider_text.frameNStart = frameN;  // exact frame index

      slider_text.setAutoDraw(true);
    }


//    move_it_around.draw()



    if (frameN == 1)
      move_it_around.setAutoDraw(false);

    if (!first_slider_routine) {
      if (frameN == 2) {
        let labels_cool = options.split('^');
        console.log('labels:')
        console.log(labels_cool)
        console.log()

        // this is so annoying
        move_it_around = new visual.Slider({
          win: psychoJS.window, name: 'move_it_around',
          size: [1.0, 0.1], pos: [0, (-0.1)], units: 'height',
          labels: labels_cool, ticks: Array.from(Array(labels_cool.length).keys()),
          granularity: 1, style: [visual.Slider.Style.RATING],
          color: new util.Color('LightGray'),
          bold: true, italic: false, // fontFamily: 'HelveticaBold',
          flip: false
        });

        move_it_around.setAutoDraw(true);
      }
    }

    // *move_it_around* updates
    if (t >= 0.0 && move_it_around.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      move_it_around.tStart = t;  // (not accounting for frame time here)
      move_it_around.frameNStart = frameN;  // exact frame index

      move_it_around.setAutoDraw(true);
    }

     // *slider_keypress* updates
    if (t >= 0.0 && slider_keypress.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider_keypress.tStart = t;  // (not accounting for frame time here)
      slider_keypress.frameNStart = frameN;  // exact frame index

      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { slider_keypress.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { slider_keypress.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { slider_keypress.clearEvents(); });
    }

    if (slider_keypress.status === PsychoJS.Status.STARTED) {
      let theseKeys = slider_keypress.getKeys({keyList: ['y', 'n', 'left', 'right', 'space'], waitRelease: false});
      _slider_keypress_allKeys = _slider_keypress_allKeys.concat(theseKeys);
      if (_slider_keypress_allKeys.length > 0) {
        slider_keypress.keys = _slider_keypress_allKeys[_slider_keypress_allKeys.length - 1].name;  // just the last key pressed
        slider_keypress.rt = _slider_keypress_allKeys[_slider_keypress_allKeys.length - 1].rt;
      }
    }

    if (slider_keypress.keys != null && slider_keypress.keys == 'space') {
      continueRoutine = false;
    }


    //console.log(continueRoutine)
    //console.log(slider_keypress.keys)
    //console.log('-')
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
      return quitPsychoJS('The [escope] key was pressed. Goodbye!', false);
    }

    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }

    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of slider_testComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }

    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function slider_testRoutineEnd(trials) {
  return function () {
    if (Experiment_closing_keypress.status === PsychoJS.Status.STARTED) {
      slider_keypress.status = PsychoJS.Status.FINISHED;
    }


    first_slider_routine = false;
    move_it_around.setAutoDraw(false);
    //------Ending Routine 'slider_test'-------
    for (const thisComponent of slider_testComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('move_it_around.response', move_it_around.getRating());
    psychoJS.experiment.addData('move_it_around.rt', move_it_around.getRT());
    psychoJS.experiment.addData('current_question_text', desc);
    psychoJS.experiment.addData('current_question_options', options);

    // the Routine "slider_test" was not non-slip safe, so reset the non-slip timer
    psychoJS.experiment.addData('slider_keypress.keys', slider_keypress.keys);
    if (typeof slider_keypress.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('slider_keypress.rt', slider_keypress.rt);
        }

    slider_keypress.stop();
    routineTimer.reset();

    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration({thisScheduler, isTrials=true}) {
  // ------Prepare for next entry------
  return function () {
    // ------Check if user ended loop early------
    if (currentLoop.finished) {
      // Check for and save orphaned data
      if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
        psychoJS.experiment.nextEntry();
      }
      thisScheduler.stop();
    } else if (isTrials) {
      psychoJS.experiment.nextEntry();
    }
  return Scheduler.Event.NEXT;
  };
}


function importConditions_slider(loop) {
  //const trialIndex = loop.getTrialIndex();
  return function () {
    //loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}



function importConditions(loop) {
  const trialIndex = loop.getTrialIndex();
  return function () {
    loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


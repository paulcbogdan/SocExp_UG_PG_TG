/*************************
 * Rc_Pavlovia_Test Test *
 *************************/

import { PsychoJS } from 'https://pavlovia.org/lib/core.js';
import * as core from 'https://pavlovia.org/lib/core.js';
import { TrialHandler } from 'https://pavlovia.org/lib/data.js';
import { Scheduler } from 'https://pavlovia.org/lib/util.js';
import * as util from 'https://pavlovia.org/lib/util.js';
import * as visual from 'https://pavlovia.org/lib/visual.js';
import { Sound } from 'https://pavlovia.org/lib/sound.js';

// init psychoJS:
var psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: false,
  color: new util.Color([0, 0, 0]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'Study 4';  // from the Builder filename that created this script
let expInfo = {'participant': ''}; //


//let expInfo = {}
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

var random_key = Math.floor(Math.random() * 8)

console.log('random key:', random_key)

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);


// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);



flowScheduler.add(experiment_startingRoutineBegin);
flowScheduler.add(experiment_startingRoutineEachFrame);
flowScheduler.add(experiment_startingRoutineEnd);

const main_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(main_loopLoopBegin, main_loopLoopScheduler);
flowScheduler.add(main_loopLoopScheduler);
flowScheduler.add(main_loopLoopEnd);

flowScheduler.add(Experiment_closingRoutineBegin);
flowScheduler.add(Experiment_closingRoutineEachFrame);
flowScheduler.add(Experiment_closingRoutineEnd);
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
// dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({expName, expInfo});

var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '3.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0/Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0/60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://www.google.com/search?q=enter+redirect+link+here&rlz=1C1GCEU_en&sxsrf=ALiCzsb_1TlPTJbrHSWnaPJSFmQX6uPOLQ%3A1666829661574&ei=Xc1ZY4zPIpSoptQPsJi7kAM&ved=0ahUKEwjM8YOvkP_6AhUUlIkEHTDMDjIQ4dUDCBA&uact=5&oq=enter+redirect+link+here&gs_lcp=Cgdnd3Mtd2l6EAMyBQghEKABOgQIABBHOgQIIxAnOgUIABCRAjoRCC4QgAQQsQMQgwEQxwEQ0QM6CwgAEIAEELEDEIMBOggIABCABBCxAzoECAAQQzoQCC4QsQMQgwEQxwEQ0QMQQzoKCAAQsQMQgwEQQzoHCAAQsQMQQzoHCC4Q1AIQQzoNCAAQsQMQgwEQyQMQQzoKCC4QsQMQ1AIQQzoRCC4QgAQQsQMQgwEQxwEQrwE6BQgAEIAEOgsILhCSAxDHARCvAToLCC4QgAQQxwEQrwE6CAguEIAEELEDOgsILhCABBCxAxDUAjoNCC4QgAQQxwEQ0QMQCjoFCC4QgAQ6BQgAEIYDOgcIIRCgARAKOgUIIRCrAkoECEEYAEoECEYYAFDyBljCHGCiH2gAcAJ4AIABuwGIAZ8VkgEENi4xOJgBAKABAcgBCMABAQ&sclient=gws-wiz')

  return Scheduler.Event.NEXT;
}

var experiment_startingClock, Experiment_starting_text, Experiment_starting_keypress;

var initClock;
var role_type;
var Proposer_proposeClock;
var Proposer_propose_text;

var kbd_offer, offer_rating;

var Experiment_closingClock, Experiment_closing_text, Experiment_closing_keypress;

var Proposer_confirm_offerClock;
var Proposer_confirm_offer_text;
var Proposer_waitingClock;
var Proposer_waiting_text;
var Proposer_view_outcomeClock;
var Proposer_view_outcome_text;
var Responder_waitingClock;
var Responder_waiting_text;
var Responder_view_offerClock;
var Responder_view_offer_text;
var Responder_respondClock;
var Responder_respond_text;
var Responder_view_outcomeClock;
var Responder_view_outcome_text;

var globalClock;
var routineTimer;
var roleType = "Responder Role";

var Investor_reminderClock, Investor_reminder_text
var Investor_investClock, Investor_invest_text, Investor_key_input;
var Investor_confirm_amountClock, Investor_confirm_amount_text;
var Investor_waitingClock, Investor_waiting_text;
var Investor_view_outcomeClock, Investor_view_outcome_text;

var Trustee_waitingClock, Trustee_waiting_text;
var Trustee_view_amountClock, Trustee_view_amount_text;
var Trustee_trustClock, Trustee_trust_text, trustee_key_input;
var Trustee_view_outcomeClock, Trustee_view_outcome_text;

var no_roleClock;
var text_4;

var Investor_reminderComponents, Investor_investComponents, Investor_confirm_amountComponents, Investor_waitingComponents, Investor_view_outcomeComponents;
var Trustee_waitingComponents, Trustee_view_amountComponents, Trustee_trustComponents, Trustee_view_outcomeComponents;

var Subject_pairing_screenClock, Subject_pairing_screen_text, Subject_pairing_screenComponents;


var computer;

var trust_options = {
  option1: {amount: 0,
    responses: [0, 0, 0, 0, 0],
    response1: 0,
    response2: 0,
    response3: 0,
    response4: 0,
    response5: 0},
  option2: {amount: 5,
    responses: [0, 5, 8, 10, 15],
    response1: 0,
    response2: 5,
    response3: 8,
    response4: 10,
    response5: 15},
  option3: {amount: 10,
    responses: [0, 10, 15, 20, 30],
    response1: 0,
    response2: 10,
    response3: 15,
    response4: 20,
    response5: 30},
  option4: {amount: 15,
    responses: [0, 15, 22, 30, 45],
    response1: 0,
    response2: 15,
    response3: 22,
    response4: 30,
    response5: 45},
  option5: {amount: 20,
    responses: [0, 20, 30, 40, 60],
    response1: 0,
    response2: 20,
    response3: 30,
    response4: 40,
    response5: 60}
}
var invest_starting_amount = 20;

var option1_keep_str = (invest_starting_amount - trust_options.option1.amount).toString(); // if I was better at js, I
var option2_keep_str = (invest_starting_amount - trust_options.option2.amount).toString(); // would iterate here
var option3_keep_str = (invest_starting_amount - trust_options.option3.amount).toString();
var option4_keep_str = (invest_starting_amount - trust_options.option4.amount).toString();
var option5_keep_str = (invest_starting_amount - trust_options.option5.amount).toString();


var invest_text = '    How much to invest? ($keep : $invest)\nNone                                                                      All\n$' +
    option1_keep_str + ':$' + trust_options.option1.amount.toString() +
    '   ||   $' + option2_keep_str + ':$' + trust_options.option2.amount.toString() +
    '   ||   $' + option3_keep_str + ':$' + trust_options.option3.amount.toString() +
    '   ||   $' + option4_keep_str + ':$' + trust_options.option4.amount.toString() +
    '   ||   $' + option5_keep_str + ':$' + trust_options.option5.amount.toString() +'\n\n  1                 2              space              9                0   \n';

var propose_text = '$9 : $1   ||   $8 : $2   ||   $7 : $3   ||   $6 : $4   ||   $5 : $5\n\n  1                 2             space             9                 0  \n';
var respond_text = 'strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n' + 'accept                                                          reject\n\n' +
    '      1                2            space          9              0';


// implement a 10-30 second break??

var num_players;
var num_rounds;
if (random_key > 3) {
  num_players = 10;
  num_rounds = 14;
} else {
  num_players = 5;
  num_rounds = 28;
}

var opening_text = [
      ' Welcome to the experiment. We are glad that you selected our study, and here you will be playing a social' +
    ' decision-making task with other live participants. You will be making decisions that impact you and' +
    ' the people you play with. However, before we can begin the experiment, we will go through the consenting process.\n\n' +
    ' Please press the [right] arrow key, and a consent form will begin to download onto your computer. ' +
    ' Please accept any pop-ups asking for permission to download the consent form PDF File.' +
    ' If you are having any technical difficulties during the experiment, please email: __________.',

    'A consent form should be downloading now. Please read it.' + ' If you would like to consent to participate, please press the [space] bar. \n\n ' +
    'If ever feel uncomfortable during the experiment,' +
' you can withdraw from the experiment by closing your web browser or pressing ' +
    'the [escape] key and emailing _____________, stating that you want to withdraw.' +
' You will receive an excused absence.',

      '\n\nGreat! In this study, you will be playing a live game and interacting' +
' with other participants (including many from other universities)! ' +
      'Specifically, you will be playing two-player games, where your overall rewards depend on both' +
' your own behavior and the behavior of the people you play with. The reward we have planned for you is to leave the experiment early!' +
' Specifically, we have a boring task planned for the end of the experiment.' +
' The more \"money\" you earn during the two-player games, the less of the boring task you will have to do.' +
      ' At best, you will be able to earn full credit while exiting 15 minutes early.\n\n' +
'Press the [right] arrow key to advance to the next screen. At any time, you can press the [left] arrow key to' +
' return to an earlier screen.',

    'The experiment is organized into 3-7 minute rounds and involves two types of games.' +
'\n\nEach round begins by pairing you with a random player.' +
' Then, you will play the \"Pot Splitting Game\" 12 to 30 times with that player. After that, you will play the' +
' \"Investment Game\" once with that same player. In total, you will play with ' + num_players.toString() + ' other players.\n\n' +
' We will first show you a helpful diagram showing this overall scheme and go over the instructions for the first game.' +
' To download the diagram and the instructions (PDF file), please press the ' +
' [right] arrow key which will also move you to the next screen. Please accept any pop-ups regarding the download.',

    ' The Pot Splitting Game instructions should be downloading now. Please read them.\n\n' +
' After you have done this, we will move onto a practice trial. Please press the [right] arrow key when you are done reading.',

    'For this first practice trial, you will be placed in the proposer role, where you are proposing how to split a $10 pot.\n\n' +
' When you see the offer screens, please press the key for proposing a $6:$4 split, where you take $6,' +
' and the other player receives $4. You MUST press the $6:$4 key to advance in the experiment.' +
' If you are confused, you can always press the [left] arrow key to move to an earlier tutorial screen.',

    propose_text,

  'Good job! We have one more practice trial where you will be again placed in the proposer role. However, this time, please press the key corresponding' +
' to proposing an $8:$2 split, where you take $8 and the other player would receive $2.\n\n Okay? Please press the [right] arrow key to try.',

    propose_text,

    ' Superb! Keep in mind that in the actual experiment you will need to make these choices within 3 seconds.' +
' If you make an unintended choice, you can press another key. The last key you press will be your choice.' +
' \n\nNow, keep in mind, there are more screens than just these that you will see in the Proposer role,' +
' such as a screen where you get a confirmation about what offer you proposed and another screen where you find out whether your' +
' offer was accepted or rejected. Please see the instructions PDF for full details. \n\nNow, let\'s try demoing the' +
' responder role. For the next screen that pops up when you press [right], please try responding STRONGLY ACCEPT.',

    respond_text,

    'Well done! Responding with Strongly Accept has the same effects on the payouts as responding with just Accept,' +
' and Strongly Reject has the same outcomes as Reject. However, please try to use Strongly Accept and Strongly Reject,' +
' when you feel very strongly about your response so that us researchers can better understand what is going on in your' +
' mind.\n\nNow, we have one more practice trial, please move to the next screen with [right] and respond to the next screen with REJECT.',

    respond_text,

    'Good job! We are done with the Pot Splitting Game demo. Again, in the actual experiment, you need to make these' +
' choices within 3 seconds, and there will be more screens shown than just the' +
' one you saw, such as the screen informing you of what offer you just received! If you miss a choice in the Proposer' +
' or in the Responder role both you and the other player will get zero money! \n\n We will now start going over the' +
' Investment Game procedure. When you press the [right] arrow key and move to the next slide, an instructions PDF for' +
' that game will begin to download.',

    'Please read the instructions for the Investment Game.\n\n' +
' After you have completed 12-30 rounds of the Pot Splitting Game, you will play the Investment Game once with the same player.' +
' Right when the experiment began, you were randomly assigned to always play in the INVESTOR ROLE for the Investment game. ' +
' In other words, you will always be playing in the investor role.' +
' Let\'s try a practice trial where, please press the [right] arrow key.',

    'For this investor role practice trial, please try keeping $15 and investing $5 (out of your initial $20).' +
' This choice will appear as \"$15:$5\", meaning that you kept $15 and invested $5.' +
' Press the [right] arrow to see the screen.',

    invest_text,

    'Good, you won\'t be playing the Investment Game as many times and you are dealing with a larger amount of money,' +
' so we implemented a reminder before that screen within the rounds. Think about how much you would like to invest' +
' during that reminder. After that, you will have 6 seconds to make your choice.' +
' As mentioned in the PowerPoint, you will not see the outcome of the investment' +
' game until the end of the experiment, but the Trustee\'s response will be saved for you to see at the end, and it will' +
' impact the amount of time you will spend on the boring task.\n' +
' Now, we will try one more practice trial. When you press the [right] arrow, you will see the last' +
' tutorial screen. On it, try investing $15 and keeping $5.',

    invest_text,

    ' You are ready to go. This is now the last slide of the instructions. Last reminder: You will not receive actual' +
' money for playing this game. Instead, the more money you earn, the faster you will be able to leave and the more of' +
' the boring task you will be able to skip. Please press the [right] arrow one more time and you will be taken to a screen' +
' that allows the system to start searching to another participant for you to play with.\n\nPlease do not tab out of the' +
' browser, as the experiment will continue running regardless.'];



var opening_key_required_to_advance = ['right', 'space', 'right', 'right', 'right', 'right', 9, 'right', 2,
  'right', 1, 'right', 9, 'right', 'right', 'right', 2, 'right', 9, 'right', 'right', 'space'];


var current_text_focus_element = 0;
var pot_splitting_instructions_download_element = 4;
var investment_game_instructions_download_element = 14;
var consent_form_number_key = 1;

var closing_text = ['The experiment is now done.\n\n While we mentioned in the introduction, that you would be playing ' +
'with other human players, this is not true. All of your games were played using a computer. ' +
'You also do not need to complete a boring task.\n\n' +
' Please press the [right] arrow key to move onto the next debriefing slide. Doing this will download a PDF' +
' describing more details related to the experiment. The next slide also provides further description of the task that' +
' you just performed.',

' The game that you played, which we called the \"Pot Splitting Game\" for simplicity is more commonly' +
' referred to as the \"Ultimatum Game\". Wikipedia has nice content on it if' +
' you would like to read more. Our goal was to understand how your behavior in the Responder role is related to your behavior' +
' in the proposer role.\n\n' +
' The game is meant to simulate \"social interactions\". We used these games to study how people evaluate others\' behavior' +
' and how these evaluations are related to how you act yourself.',

    'Thank you for participating in our study. Please press the [right] arrow key to end the study and receive your' +
' credit.'];

var closing_key_required_to_advance = ['right', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right']



function experimentInit() {

  // Initialize components for Routine "experiment_starting"
  experiment_startingClock = new util.Clock();
  Experiment_starting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Experiment_starting_text',
    text: opening_text[0], //
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });
  Experiment_starting_keypress = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});

  Experiment_closingClock = new util.Clock();
  Experiment_closing_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Experiment_closing_text',
    text: closing_text[0],
    font: 'Arial',
    units: undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  Experiment_closing_keypress = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "init"
  initClock = new util.Clock();
  role_type = new visual.TextStim({
    win: psychoJS.window,
    name: 'role_type',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('blue'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Proposer_propose"
  Proposer_proposeClock = new util.Clock();
  Proposer_propose_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_propose_text',
    text: propose_text,
    font: 'Arial',
    units : 'norm',
    pos: [0, 0], height: 0.065,  wrapWidth: 10, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  Investor_reminderClock = new util.Clock();
  Investor_reminder_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_reminder_text',
    text: 'test_test_test49',
    font: 'Arial',
    units : 'norm',
    pos: [0, 0], height: 0.065, wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  kbd_offer = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Proposer_confirm_offer"
  Proposer_confirm_offerClock = new util.Clock();
  Proposer_confirm_offer_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_confirm_offer_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Proposer_waiting"
  Proposer_waitingClock = new util.Clock();
  Proposer_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_waiting_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Proposer_view_outcome"
  Proposer_view_outcomeClock = new util.Clock();
  Proposer_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Proposer_view_outcome_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Responder_waiting"
  Responder_waitingClock = new util.Clock();
  Responder_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_waiting_text',
    text: 'Waiting for the Proposer to propose',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Responder_view_offer"
  Responder_view_offerClock = new util.Clock();
  Responder_view_offer_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_view_offer_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  // Initialize components for Routine "Responder_respond"
  Responder_respondClock = new util.Clock();
  Responder_respond_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_respond_text',
    text: 'default text',
    font: 'Arial',
    units : 'norm',
    pos: [0, 0], height: 0.065,  wrapWidth: 10, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

  offer_rating = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Responder_view_outcome"
  Responder_view_outcomeClock = new util.Clock();
  Responder_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Responder_view_outcome_text',
    text: 'default text',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0
  });

   // Initialize components for Routine "Investor_invest"
  Investor_investClock = new util.Clock();
  Investor_invest_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_invest_text',
    text: invest_text,
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  Investor_key_input = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});

  // Initialize components for Routine "Investor_confirm_amount"
  Investor_confirm_amountClock = new util.Clock();
  Investor_confirm_amount_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_confirm_amount_text',
    text: ' ',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Investor_waiting"
  Investor_waitingClock = new util.Clock();
  Investor_waiting_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_waiting_text',
    text: 'Waiting to hear back from the trustee',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Initialize components for Routine "Investor_view_outcome"
  Investor_view_outcomeClock = new util.Clock();
  Investor_view_outcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Investor_view_outcome_text',
    text: 'You will learn the outcome(how much you received back) at the end of the experiment',
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.065,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

    // Initialize components for Routine "Subject_pairing_screen"
  Subject_pairing_screenClock = new util.Clock();
  Subject_pairing_screen_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Subject_pairing_screen_text',
    text: 'You are free to take a short' +
        ' break right now if you want (e.g., you can go to the bathroom or browse your phone). Please try not to use' +
        ' your phone during the games as this will be distracting and this impairs the research process.\n\n' +
        ' When you are ready to start playing with a new' +
        ' person, please press the [space] bar and the system will begin looking for a suitable co-player. Remember,' +
        ' you will start this new round by playing the Pot Splitting Game for 12-30 trials.',
    // We are searching to find you a new subject. Please wait.
    font: 'Arial',
    units : undefined,
    pos: [0, 0], height: 0.045,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0
  });

  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine

  return Scheduler.Event.NEXT;
}

var t;
var frameN;
var _Experiment_starting_keypress_allKeys;
var experiment_startingComponents;
function experiment_startingRoutineBegin() {
  //------Prepare to start Routine 'experiment_starting'-------
  t = 0;
  experiment_startingClock.reset(); // clock
  frameN = -1;
  cooldown = 0
  // update component parameters for each repeat
  // keep track of which components have finished
  Experiment_starting_keypress.keys = undefined;
  Experiment_starting_keypress.rt = undefined;
  _Experiment_starting_keypress_allKeys = [];

  experiment_startingComponents = [];
  experiment_startingComponents.push(Experiment_starting_text);
  experiment_startingComponents.push(Experiment_starting_keypress);

  for (const thisComponent of experiment_startingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

var frameRemains;
var continueRoutine;
var opening_screen_bool;
var change;

var closing_screen_bool;

function process_keys_pages(keypress_manager) {

  if (typeof keypress_manager.keys != 'undefined' && typeof keypress_manager.keys != null) {
    let key = keypress_manager.keys;//.slice(-1)[0];
    //console.log('key slice:')
    //console.log(key)

    let key_required_to_advance;
    if (keypress_manager == Experiment_starting_keypress) {
      key_required_to_advance = opening_key_required_to_advance;
      console.log('COMPARUSON WORKSSSSSSSS');
    } else if (keypress_manager == Experiment_closing_keypress) {
      key_required_to_advance = closing_key_required_to_advance;
      console.log('CLOSE IT DOWN');
    }
    console.log('needed:')
    console.log(key_required_to_advance[current_text_focus_element])
    if (key == key_required_to_advance[current_text_focus_element]) {
      if (current_text_focus_element >= closing_text.length-1) {
        closing_screen_bool = true;
      }
      if (current_text_focus_element >= opening_text.length-1) {
        opening_screen_bool = true; // will break if you want two Experiment_starting routines...
      } else {
        console.log('fail')
        current_text_focus_element = current_text_focus_element + 1;
        change = true;
      }

    } else if (key == 'left') {
      if (current_text_focus_element > 0) {
        current_text_focus_element = current_text_focus_element - 1;
        change = true;
      }
    } //else {
      //snd.play();
    //}

    //if (key == key_required_to_advance[current_text_focus_element] || key == 'left') {
    keypress_manager.keys = undefined;
    key = undefined;
    keypress_manager.clearEvents();
    Experiment_starting_keypress.keys = undefined;
    _Experiment_starting_keypress_allKeys = [];
    cooldown = 0;
    console.log('screen bool:', opening_screen_bool)
    console.log('current focus:', current_text_focus_element)
    console.log(key_required_to_advance.length)
    //}
  }
}

var cooldown = 0;
function experiment_startingRoutineEachFrame() {
  //------Loop for each frame of Routine 'experiment_starting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = experiment_startingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  cooldown = cooldown + 1;
  // update/draw components on each frame

  // *Experiment_starting_text* updates
  if (t >= 0.0 && Experiment_starting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_starting_text.tStart = t;  // (not accounting for frame time here)
    Experiment_starting_text.frameNStart = frameN;  // exact frame index
    Experiment_starting_text.setAutoDraw(true);
  }

  opening_screen_bool = false;
  if (Experiment_starting_text.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
    Experiment_starting_text.setAutoDraw(false);
  }

  //console.log('final screen text end:')
  //console.log(Experiment_starting_keypress.keys)
  //console.log(opening_screen_bool)


  if (t >= 0.0 && Experiment_starting_keypress.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Experiment_starting_keypress.tStart = t;  // (not accounting for frame time here)
      Experiment_starting_keypress.frameNStart = frameN;  // exact frame index

      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Experiment_starting_keypress.clearEvents(); });
  }
  opening_screen_bool = false;
  const prev_current_text_focus_element = current_text_focus_element;

  if (cooldown > 15) {
    process_keys_pages(Experiment_starting_keypress)
    Experiment_starting_keypress.start()
  }

  if (Experiment_starting_text.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
    Experiment_starting_text.setAutoDraw(false);
  }
  if (Experiment_starting_keypress.status === PsychoJS.Status.STARTED && Boolean(opening_screen_bool)) {
      Experiment_starting_keypress.status = PsychoJS.Status.FINISHED;
  }

  if (Experiment_starting_keypress.status === PsychoJS.Status.STARTED) {
    let theseKeys = Experiment_starting_keypress.getKeys({keyList: ['1', '0', '9' , '2', 'left', 'right', 'space'], waitRelease: false, clear: true});
    _Experiment_starting_keypress_allKeys = _Experiment_starting_keypress_allKeys.concat(theseKeys);
    if (_Experiment_starting_keypress_allKeys.length > 0) {
      Experiment_starting_keypress.keys = _Experiment_starting_keypress_allKeys[_Experiment_starting_keypress_allKeys.length - 1].name;  // just the last key pressed
      Experiment_starting_keypress.rt = _Experiment_starting_keypress_allKeys[_Experiment_starting_keypress_allKeys.length - 1].rt;
    }
  }

  if (change) {
    Experiment_starting_text.setText(opening_text[current_text_focus_element])

    if (current_text_focus_element == consent_form_number_key){
        download_form( 'resources/consent_form.pdf');
    }

    if (pot_splitting_instructions_download_element == current_text_focus_element) {
      download_form('resources/Pot_splitting_game_instructions.pdf')
    }

    if (investment_game_instructions_download_element == current_text_focus_element) {
      download_form('resources/Investing_game_INVESTOR_instructions.pdf')
    }

    change = false;
  }

  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  if (opening_screen_bool)
    continueRoutine = false;

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of experiment_startingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function experiment_startingRoutineEnd() {
  //------Ending Routine 'experiment_starting'-------
  for (const thisComponent of experiment_startingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('random_key_condition_order', random_key);
  psychoJS.experiment.addData('Experiment_starting_keypress.keys', Experiment_starting_keypress.keys);
  if (typeof Experiment_starting_keypress.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('Experiment_starting_keypress.rt', Experiment_starting_keypress.rt);
      }
  current_text_focus_element = 0; // reset it for the closing
  Experiment_starting_keypress.stop();
  // the Routine "Experiment_starting" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();

  opening_screen_bool = false;
  closing_screen_bool = false;

  return Scheduler.Event.NEXT;
}

var main_loop;
var currentLoop;
function main_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  main_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    //trialList: 'sheet_lookup/post_FD/online_lookup_abridged.xlsx',
    trialList: 'sheet_lookup/online_lookup_final' + random_key.toString() + '.xlsx', // + random_key.toString() +
    //trialList: 'sheet_lookup/' + 'online_lookup.xlsx',
    seed: undefined, name: 'main_loop'});
  psychoJS.experiment.addLoop(main_loop); // add the loop to the experiment
  currentLoop = main_loop;  // we're now the current loop


  for (const thisMain_loop of main_loop) {
    thisScheduler.add(importConditions(main_loop));
    thisScheduler.add(initRoutineBegin);
    thisScheduler.add(initRoutineEachFrame);
    thisScheduler.add(initRoutineEnd);
    const pairing_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(pairing_loopLoopBegin, pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopScheduler);
    thisScheduler.add(pairing_loopLoopEnd);
    const prop_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(prop_loopLoopBegin, prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopScheduler);
    thisScheduler.add(prop_loopLoopEnd);
    const resp_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(resp_loopLoopBegin, resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopScheduler);
    thisScheduler.add(resp_loopLoopEnd);
    const investor_loopLoopScheduler = new Scheduler(psychoJS);
    thisScheduler.add(investor_loopLoopBegin, investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopScheduler);
    thisScheduler.add(investor_loopLoopEnd);

    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }


  console.log('loop first done')
  return Scheduler.Event.NEXT;
}

var pairing_loop;
function pairing_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  pairing_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_pairing, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'pairing_loop'});
  psychoJS.experiment.addLoop(pairing_loop); // add the loop to the experiment
  currentLoop = pairing_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisPairing_loop of pairing_loop) {
    thisScheduler.add(importConditions(pairing_loop));
    thisScheduler.add(Subject_pairing_screenRoutineBegin);
    thisScheduler.add(Subject_pairing_screenRoutineEachFrame);
    thisScheduler.add(Subject_pairing_screenRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function pairing_loopLoopEnd() {
  psychoJS.experiment.removeLoop(pairing_loop);

  return Scheduler.Event.NEXT;
}

var prop_loop;
function prop_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  prop_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_proposer, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'prop_loop'});
  psychoJS.experiment.addLoop(prop_loop); // add the loop to the experiment
  currentLoop = prop_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisProp_loop of prop_loop) {
    thisScheduler.add(importConditions(prop_loop));
    thisScheduler.add(Proposer_proposeRoutineBegin);
    thisScheduler.add(Proposer_proposeRoutineEachFrame);
    thisScheduler.add(Proposer_proposeRoutineEnd);
    thisScheduler.add(Proposer_confirm_offerRoutineBegin);
    thisScheduler.add(Proposer_confirm_offerRoutineEachFrame);
    thisScheduler.add(Proposer_confirm_offerRoutineEnd);
    thisScheduler.add(Proposer_waitingRoutineBegin);
    thisScheduler.add(Proposer_waitingRoutineEachFrame);
    thisScheduler.add(Proposer_waitingRoutineEnd);
    thisScheduler.add(Proposer_view_outcomeRoutineBegin);
    thisScheduler.add(Proposer_view_outcomeRoutineEachFrame);
    thisScheduler.add(Proposer_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }
  console.log('PROP LOOP DONE')
  return Scheduler.Event.NEXT;
}


function prop_loopLoopEnd() {
  psychoJS.experiment.removeLoop(prop_loop);

  return Scheduler.Event.NEXT;
}

var resp_loop;
function resp_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  resp_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_responder, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'resp_loop'});
  psychoJS.experiment.addLoop(resp_loop); // add the loop to the experiment
  currentLoop = resp_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisResp_loop of resp_loop) {
    thisScheduler.add(importConditions(resp_loop));
    thisScheduler.add(Responder_waitingRoutineBegin);
    thisScheduler.add(Responder_waitingRoutineEachFrame);
    thisScheduler.add(Responder_waitingRoutineEnd);
    thisScheduler.add(Responder_view_offerRoutineBegin);
    thisScheduler.add(Responder_view_offerRoutineEachFrame);
    thisScheduler.add(Responder_view_offerRoutineEnd);
    thisScheduler.add(Responder_respondRoutineBegin);
    thisScheduler.add(Responder_respondRoutineEachFrame);
    thisScheduler.add(Responder_respondRoutineEnd);
    thisScheduler.add(Responder_view_outcomeRoutineBegin);
    thisScheduler.add(Responder_view_outcomeRoutineEachFrame);
    thisScheduler.add(Responder_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function resp_loopLoopEnd() {
  psychoJS.experiment.removeLoop(resp_loop);

  return Scheduler.Event.NEXT;
}

var investor_loop;
function investor_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  investor_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_investor, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'investor_loop'});
  psychoJS.experiment.addLoop(investor_loop); // add the loop to the experiment
  currentLoop = investor_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisInvestor_loop of investor_loop) {
    thisScheduler.add(importConditions(investor_loop));

    thisScheduler.add(Investor_reminderRoutineBegin);
    thisScheduler.add(Investor_reminderRoutineEachFrame);
    thisScheduler.add(Investor_reminderRoutineEnd);

    thisScheduler.add(Investor_investRoutineBegin);
    thisScheduler.add(Investor_investRoutineEachFrame);
    thisScheduler.add(Investor_investRoutineEnd);
    thisScheduler.add(Investor_confirm_amountRoutineBegin);
    thisScheduler.add(Investor_confirm_amountRoutineEachFrame);
    thisScheduler.add(Investor_confirm_amountRoutineEnd);
    thisScheduler.add(Investor_waitingRoutineBegin);
    thisScheduler.add(Investor_waitingRoutineEachFrame);
    thisScheduler.add(Investor_waitingRoutineEnd);
    thisScheduler.add(Investor_view_outcomeRoutineBegin);
    thisScheduler.add(Investor_view_outcomeRoutineEachFrame);
    thisScheduler.add(Investor_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function investor_loopLoopEnd() {
  psychoJS.experiment.removeLoop(investor_loop);

  return Scheduler.Event.NEXT;
}

var trustee_loop;
function trustee_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trustee_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_trustee, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'trustee_loop'});
  psychoJS.experiment.addLoop(trustee_loop); // add the loop to the experiment
  currentLoop = trustee_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrustee_loop of trustee_loop) {
    thisScheduler.add(importConditions(trustee_loop));
    thisScheduler.add(Trustee_waitingRoutineBegin);
    thisScheduler.add(Trustee_waitingRoutineEachFrame);
    thisScheduler.add(Trustee_waitingRoutineEnd);
    thisScheduler.add(Trustee_view_amountRoutineBegin);
    thisScheduler.add(Trustee_view_amountRoutineEachFrame);
    thisScheduler.add(Trustee_view_amountRoutineEnd);
    thisScheduler.add(Trustee_trustRoutineBegin);
    thisScheduler.add(Trustee_trustRoutineEachFrame);
    thisScheduler.add(Trustee_trustRoutineEnd);
    thisScheduler.add(Trustee_view_outcomeRoutineBegin);
    thisScheduler.add(Trustee_view_outcomeRoutineEachFrame);
    thisScheduler.add(Trustee_view_outcomeRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}

function trustee_loopLoopEnd() {
  psychoJS.experiment.removeLoop(trustee_loop);

  return Scheduler.Event.NEXT;
}


var trials;
function trialsLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: loop_none, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'trials'});
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial of trials) {
    thisScheduler.add(importConditions(trials));
    thisScheduler.add(no_roleRoutineBegin);
    thisScheduler.add(no_roleRoutineEachFrame);
    thisScheduler.add(no_roleRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}


function main_loopLoopEnd() {
  psychoJS.experiment.removeLoop(main_loop);
  console.log('main lop end')
  return Scheduler.Event.NEXT;
}

var initComponents;
var loop_pairing, loop_proposer, loop_responder, loop_investor, loop_trustee, loop_none;
function initRoutineBegin() {
  //------Prepare to start Routine 'init'-------
  t = 0;
  initClock.reset(); // clock
  frameN = -1;



  //console.log('Trial number')
  //console.log(trial_number)

  console.log('role1:', role_1)

  if (role_1 == 'r') {
    roleType = "Responder Role";
  } else if (role_1 == "p") {
    roleType = "Proposer Role";
  } else if (role_1 == 'i') {
    roleType = 'Investor Role';
  } else if (role_1 == 's') {
    roleType = ' ';
  }
  //roleType = 'Investor Role';
  if (roleType == ' ')
    routineTimer.add(0.01)
  else
    routineTimer.add(2.000000);

  console.log('experiment trial + pairing screen number:', trial_number)

  if (roleType == ' '){
    loop_pairing = 1;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
  } else if (roleType == "Proposer Role"){
    loop_pairing = 0;
    loop_proposer = 1;
    loop_responder = 0;
    loop_investor = 0;
  } else if (roleType == "Responder Role") {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 1;
    loop_investor = 0;
  } else if (roleType == "Investor Role"){
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 1;
  } else if (roleType == "Trustee Role") {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
  } else if (roleType == 'No Role') {
    loop_pairing = 0;
    loop_proposer = 0;
    loop_responder = 0;
    loop_investor = 0;
  }

  // update component parameters for each repeat
  role_type.setText(roleType);

  console.log('roleType:', roleType)
  console.log('loops', loop_trustee, loop_proposer, loop_none, loop_responder, loop_investor, loop_pairing)

  // keep track of which components have finished
  initComponents = [];
  initComponents.push(role_type);

  for (const thisComponent of initComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function initRoutineEachFrame() {
  //------Loop for each frame of Routine 'init'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = initClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *role_type* updates
  if (t >= 0.0 && role_type.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    role_type.tStart = t;  // (not accounting for frame time here)
    role_type.frameNStart = frameN;  // exact frame index
    role_type.setAutoDraw(true);
  }

  frameRemains = 0.0 + 2.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (role_type.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    role_type.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of initComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function initRoutineEnd() {
  //------Ending Routine 'init'-------
  for (const thisComponent of initComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var _Experiment_closing_keypress_allKeys;
var Experiment_closingComponents;
function Experiment_closingRoutineBegin(trials) {
  //------Prepare to start Routine 'Experiment_closing'-------
  t = 0;
  Experiment_closingClock.reset(); // clock
  frameN = -1;
  cooldown = 0;
  // update component parameters for each repeat
  Experiment_closing_keypress.keys = undefined;
  Experiment_closing_keypress.rt = undefined;
  _Experiment_closing_keypress_allKeys = [];
  // keep track of which components have finished
  Experiment_closingComponents = [];
  Experiment_closingComponents.push(Experiment_closing_text);
  Experiment_closingComponents.push(Experiment_closing_keypress);

  for (const thisComponent of Experiment_closingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

var closing_screen_bool;
function Experiment_closingRoutineEachFrame(trials) {
  //------Loop for each frame of Routine 'Experiment_closing'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Experiment_closingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  cooldown = cooldown + 1;
  // update/draw components on each frame

  // *Experiment_closing_text* updates
  if (t >= 0.0 && Experiment_closing_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_closing_text.tStart = t;  // (not accounting for frame time here)
    Experiment_closing_text.frameNStart = frameN;  // exact frame index

    Experiment_closing_text.setAutoDraw(true);
  }



  // *Experiment_closing_keypress* updates
  if (t >= 0.0 && Experiment_closing_keypress.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Experiment_closing_keypress.tStart = t;  // (not accounting for frame time here)
    Experiment_closing_keypress.frameNStart = frameN;  // exact frame index

    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Experiment_closing_keypress.clearEvents(); });
  }

  closing_screen_bool = false;
  const prev_current_text_focus_element = current_text_focus_element;

  if (cooldown > 50) {
    process_keys_pages(Experiment_closing_keypress)
    Experiment_closing_keypress.start()
  }

  if (Experiment_closing_text.status === PsychoJS.Status.STARTED && Boolean(closing_screen_bool)) {
    Experiment_closing_text.setAutoDraw(false);
  }
  if (Experiment_closing_keypress.status === PsychoJS.Status.STARTED && Boolean(closing_screen_bool)) {
    Experiment_closing_keypress.status = PsychoJS.Status.FINISHED;
  }

  if (Experiment_closing_keypress.status === PsychoJS.Status.STARTED) {
    let theseKeys = Experiment_closing_keypress.getKeys({keyList: ['1', '0',  'left', 'right', 'space'], waitRelease: false, clear: true});
    _Experiment_closing_keypress_allKeys = _Experiment_closing_keypress_allKeys.concat(theseKeys);
    if (_Experiment_closing_keypress_allKeys.length > 0) {
      Experiment_closing_keypress.keys = _Experiment_closing_keypress_allKeys[_Experiment_closing_keypress_allKeys.length - 1].name;  // just the last key pressed
      Experiment_closing_keypress.rt = _Experiment_closing_keypress_allKeys[_Experiment_closing_keypress_allKeys.length - 1].rt;
    }
  }

  if (change) {
    Experiment_closing_text.setText(closing_text[current_text_focus_element])
    if (current_text_focus_element == consent_form_number_key)
      download_form('resources/debriefing_form.pdf');
    change = false;
    Experiment_closing_keypress.keys = undefined;
    cooldown = 0;
    _Experiment_closing_keypress_allKeys = [];
    change = false; // new
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escope']}).length > 0) {
    return quitPsychoJS('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Experiment_closingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  } else {
    return Scheduler.Event.NEXT;
  }
}

function Experiment_closingRoutineEnd(trials) {
  //------Ending Routine 'Experiment_closing'-------
  for (const thisComponent of Experiment_closingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }

  psychoJS.experiment.addData('Experiment_closing_keypress.keys', Experiment_closing_keypress.keys);
  if (typeof Experiment_starting_keypress.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('Experiment_closing_keypress.rt', Experiment_closing_keypress.rt);
      }

  Experiment_closing_keypress.stop();
  // the Routine "Experiment_closing" was not non-slip safe, so reset the non-slip timer

  opening_screen_bool = false;
  closing_screen_bool = false;

  routineTimer.reset();

  return Scheduler.Event.NEXT;
}

// moves from being just after subject_pairing_screen
const times = [];
let fps;

function refreshLoop() {
  window.requestAnimationFrame(() => {
    const now = performance.now();
    while (times.length > 0 && times[0] <= now - 1000) {
      times.shift();
    }
    times.push(now);
    fps = times.length;
    refreshLoop();
  });
}

refreshLoop();


var player_number = 0;
function Subject_pairing_screenRoutineBegin() {
  player_number = player_number + 1;
  computer = new Computer(computer_type_responder, computer_type_proposer); // new computer corresponding to new subjects
  console.log('test responder:', computer_type_responder)
  console.log('test proposer:', computer_type_proposer)
  //------Prepare to start Routine 'Subject_pairing_screen'-------
  t = 0;
  Subject_pairing_screenClock.reset(); // clock
  frameN = -1;
  expected_wait_frames = undefined;
  start_searching = false;
  psychoJS.eventManager.clearKeys();
  // update component parameters for each repeat
  // keep track of which components have finished
  Subject_pairing_screen_text.setText('You are free to take a short' +
        ' break right now if you want (e.g., you can go to the bathroom or browse your phone). Please try not to use' +
        ' your phone during the games as this will be distracting and this impairs the research process.\n\n' +
        ' When you are ready to start playing with a new' +
        ' person, please press the [space] bar and the system will begin looking for a suitable co-player. \n\nYou are currently' +
        ' on co-player number ' + player_number.toString() + '. In total you will play with ' + num_players.toString() + ' other players.')
  Subject_pairing_screenComponents = [];
  Subject_pairing_screenComponents.push(Subject_pairing_screen_text);
  for (const thisComponent of Subject_pairing_screenComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;


  return Scheduler.Event.NEXT;
}

var stop_searching;
var expected_wait;
var expected_wait_frames;
var steady_fps;
var start_searching;
function Subject_pairing_screenRoutineEachFrame(when_start=200) {
  //------Loop for each frame of Routine 'Subject_pairing_screen'-------
  let continueRoutine = true; // until we're told otherwise
  stop_searching = false;

  // get current time
  t = Subject_pairing_screenClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)

  // update/draw components on each frame

  // *Subject_pairing_screen_text* updates
  if (t >= 0.0 && Subject_pairing_screen_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Subject_pairing_screen_text.tStart = t;  // (not accounting for frame time here)
    Subject_pairing_screen_text.frameNStart = frameN;  // exact frame index
    Subject_pairing_screen_text.setAutoDraw(true);
  }


  /*if (frameN % 10 == 0){
    console.log('esc:');
    console.log('all:', psychoJS.eventManager.getKeys());
    console.log(psychoJS.eventManager.getKeys({keyList:['escape']}))
    console.log('---------')
  }*/

  if (psychoJS.eventManager.getKeys({keyList:['space']}).length > 0 ) {
    start_searching = true;
  }

  if (!start_searching) {
    frameN = 0; // i hope this doesn't cause problemos
  } else {

    let expected_wait_str = ''

    if (frameN % 150 == 0) {
      steady_fps = fps;
    }

    if (frameN == when_start) {
      expected_wait_frames = Math.floor(Math.random() * 20 + 5) * fps;
    } else if (frameN > when_start) {
      expected_wait_frames = expected_wait_frames - 1;
    }

    let expected_wait_seconds = Math.floor(expected_wait_frames / steady_fps);
    if (frameN >= when_start) {
      expected_wait_str = 'Expected wait: ' + expected_wait_seconds.toString() + ' seconds'
    }


    if (frameN % 15 == 0) {
      if ([1, 2, 3].includes(expected_wait_seconds)) { // NO: will make the numbers flash between red and white for the last 6 seconds (last frame = 0s)
        Subject_pairing_screen_text.setColor(new util.Color("red"));
      } else {
        Subject_pairing_screen_text.setColor(new util.Color("white"));
      }

      if (Math.floor(frameN * .02) % 4 == 0) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: \n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 1) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: .\n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 2) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: ..\n\n' + expected_wait_str)
      } else if (Math.floor(frameN * .02) % 4 == 3) {
        Subject_pairing_screen_text.setText('Searching/waiting for next co-player: ...\n\n' + expected_wait_str)
      }
    }


    if (expected_wait_frames == 0) {
      stop_searching = true;
    }
  }

  if (Subject_pairing_screen_text.status === PsychoJS.Status.STARTED && Boolean(stop_searching)) {
    Subject_pairing_screen_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Subject_pairing_screenComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Subject_pairing_screenRoutineEnd() {
  //------Ending Routine 'Subject_pairing_screen'-------
  for (const thisComponent of Subject_pairing_screenComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  // the Routine "Subject_pairing_screen" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();

  return Scheduler.Event.NEXT;
}

function Investor_reminderRoutineBegin() {
  console.log('test responder:', computer_type_responder)
  console.log('test proposer:', computer_type_proposer)
  //------Prepare to start Routine 'Subject_pairing_screen'-------
  t = 0;
  Investor_reminderClock.reset(); // clock
  frameN = -1;
  expected_wait_frames = undefined;
  start_searching = false;
  // update component parameters for each repeat
  // keep track of which components have finished
  Investor_reminder_text.setText('')
  Investor_reminderComponents = [];
  Investor_reminderComponents.push(Investor_reminder_text);
  for (const thisComponent of Investor_reminderComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;


  return Scheduler.Event.NEXT;
}

var stop_searching;
var expected_wait;
var expected_wait_frames;
var steady_fps;
var start_searching;
var first_reminder = true;
let prev_expected_wait_seconds = -1;
function Investor_reminderRoutineEachFrame(when_start=200) {
  //------Loop for each frame of Routine 'Subject_pairing_screen'-------
  let continueRoutine = true; // until we're told otherwise
  stop_searching = false;

  // get current time
  t = Investor_reminderClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)

  // update/draw components on each frame

  // *Investor_reminder_text* updates
  if (t >= 0.0 && Investor_reminder_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_reminder_text.tStart = t;  // (not accounting for frame time here)
    Investor_reminder_text.frameNStart = frameN;  // exact frame index
    Investor_reminder_text.setAutoDraw(true);
  }


  /*if (frameN % 10 == 0){
    console.log('esc:');
    console.log('all:', psychoJS.eventManager.getKeys());
    console.log(psychoJS.eventManager.getKeys({keyList:['escape']}))
    console.log('---------')
  }*/

  if (psychoJS.eventManager.getKeys({keyList:['space']}).length > 0 ) {
    start_searching = true;
  }

    let expected_wait_str = ''

  if (frameN % 200 == 0) {
    steady_fps = fps;
  }

  if (frameN == when_start) {
    if (first_reminder)
      expected_wait_frames = 30 * steady_fps;
    else
      expected_wait_frames = 20 * steady_fps;
  } else if (frameN > when_start) {
    expected_wait_frames = expected_wait_frames - 1;
  }

  let expected_wait_seconds = Math.floor(expected_wait_frames / steady_fps);
  if (!isNaN(expected_wait_seconds)) {
      expected_wait_str = 'Investor trial beginning in: ' + expected_wait_seconds.toString() + ' seconds';
  } else {
    expected_wait_str = '';
  }


  if (expected_wait_seconds != prev_expected_wait_seconds) {
    if (first_reminder) {
      Investor_reminder_text.setText('Reminder: In the next trial you will be playing a different game than the previous' +
          ' one. You will now be playing the Investment Game. You are given $20 and must decide how much of it to invest.' +
          ' Investing involves giving money to the other player, with whom you just played the Pot Splitting Game. The' +
          ' amount of money given to the other player is immediately tripled. They can then choose how much of the money' +
          ' to return to you.\n\nAt best, they will return three times the amount you gave them. At worst, they will keep all' +
          ' of the money that you gave them.\n\nYour task is to decide how much of the money to invest. Please wait for the' +
          ' trial to begin. \n\n' + expected_wait_str)
    } else {
      Investor_reminder_text.setText('Reminder: In the next trial you will be playing the Investment Game. You are given' +
          ' $20 and your task is to decide how much of this money to invest (i.e., how much to give to the other player).' +
          ' Money given to them is tripled, and they will then choose how much money to return to you. The more money that' +
          ' you invest, the more than can be returned, but this also increases the risk if they choose to return little money' +
          ' back to you. \n\n' + expected_wait_str)
    }
  }


  prev_expected_wait_seconds = expected_wait_seconds;
  if (expected_wait_frames == 0) {
    stop_searching = true;
  }

  if (Investor_reminder_text.status === PsychoJS.Status.STARTED && Boolean(stop_searching)) {
    Investor_reminder_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_reminderComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_reminderRoutineEnd() {
  //------Ending Routine 'Subject_pairing_screen'-------
  for (const thisComponent of Investor_reminderComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  first_reminder = false;
  // the Routine "Subject_pairing_screen" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();

  return Scheduler.Event.NEXT;
}


function download_form(filePath) {
    //download('resources/sheet_lookup/3_players_A.xlsx', 'Consent_Form.xlsx', '.xlsx')
    var a = document.createElement('A');
    a.href = filePath;
    a.download = filePath.substr(filePath.lastIndexOf('/') + 1);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

var Proposer_proposeComponents;
function Proposer_proposeRoutineBegin() {
  //------Prepare to start Routine 'Proposer_propose'-------
  t = 0;
  Proposer_proposeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  kbd_offer.keys = undefined;
  kbd_offer.rt = undefined;
  // keep track of which components have finished
  Proposer_proposeComponents = [];
  Proposer_proposeComponents.push(Proposer_propose_text);
  Proposer_proposeComponents.push(kbd_offer);

  for (const thisComponent of Proposer_proposeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_proposeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_propose'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_proposeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_propose_text* updates
  if (t >= 0.0 && Proposer_propose_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_propose_text.tStart = t;  // (not accounting for frame time here)
    Proposer_propose_text.frameNStart = frameN;  // exact frame index
    Proposer_propose_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_propose_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_propose_text.setAutoDraw(false);
  }

  // *kbd_offer* updates
  if (t >= 0.0 && kbd_offer.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    kbd_offer.tStart = t;  // (not accounting for frame time here)
    kbd_offer.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { kbd_offer.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { kbd_offer.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { kbd_offer.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (kbd_offer.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    kbd_offer.status = PsychoJS.Status.FINISHED;
  }

  if (kbd_offer.status === PsychoJS.Status.STARTED) {
    let theseKeys = kbd_offer.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') { // changed from escape to disable
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      kbd_offer.keys = theseKeys[0].name;  // just the last key pressed
      kbd_offer.rt = theseKeys[0].rt;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_proposeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var subjectTake
var responderTake
function Proposer_proposeRoutineEnd() {
  //------Ending Routine 'Proposer_propose'-------
  for (const thisComponent of Proposer_proposeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('kbd_offer.keys', kbd_offer.keys);
  if (typeof kbd_offer.keys !== undefined) {  // we had a response
    psychoJS.experiment.addData('kbd_offer.rt', kbd_offer.rt);
  }

  kbd_offer.stop();

  if (kbd_offer.keys == null) {
    subjectTake = 0;
    responderTake = 0;
  } else {
    console.log(kbd_offer)
    var key = kbd_offer.keys;//.slice(-1)[0] // EDITTED!!!!!!
    console.log(kbd_offer);
    if (key == "1") {
      subjectTake = 9;
      responderTake = 1;
    } else if (key == '2') {
      subjectTake = 8;
      responderTake = 2;
    } else if (key == 'space') {
      subjectTake = 7;
      responderTake = 3;
    } else if (key == '9') {
      subjectTake = 6;
      responderTake = 4;
    } else if (key == '0') {
      subjectTake = 5;
      responderTake = 5;
    }
  }

  return Scheduler.Event.NEXT;
}


var Proposer_confirm_offerComponents;
function Proposer_confirm_offerRoutineBegin() {
  //------Prepare to start Routine 'Proposer_confirm_offer'-------
  t = 0;
  Proposer_confirm_offerClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (subjectTake == 0) {
    Proposer_confirm_offer_text.setText('You missed! \n \n You:      $0'  + '\n Player:   $0');
  } else {
    Proposer_confirm_offer_text.setText('You offer: \n \n You:      $' + subjectTake.toString() + '\n Player:   $' + responderTake.toString());
  }

  // keep track of which components have finished
  Proposer_confirm_offerComponents = [];
  Proposer_confirm_offerComponents.push(Proposer_confirm_offer_text);

  for (const thisComponent of Proposer_confirm_offerComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_confirm_offerRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_confirm_offer'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_confirm_offerClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_confirm_offer_text* updates
  if (t >= 0.0 && Proposer_confirm_offer_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_confirm_offer_text.tStart = t;  // (not accounting for frame time here)
    Proposer_confirm_offer_text.frameNStart = frameN;  // exact frame index
    Proposer_confirm_offer_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_confirm_offer_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_confirm_offer_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_confirm_offerComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_confirm_offerRoutineEnd() {
  //------Ending Routine 'Proposer_confirm_offer'-------
  for (const thisComponent of Proposer_confirm_offerComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var subjectPart;
var responderPart;


class Computer { // implement missing?
  constructor(responder_type, proposer_type, miss_computer_proposer_trial_number) {
    console.log('Getting new player')
    this.responder_type = responder_type;
    this.proposer_type = proposer_type;
    this.subj_propose_history = []
    this.comp_response_history = []
    this.comp_propose_history = []
    this.subj_response_history = []
    this.subj_response_history_dict = {};
    this.comp_response_history_dict = {};
    this.comp_last_offer_accept_response;
    this.miss_computer_proposer_trial_number = miss_computer_proposer_trial_number;
  }

  respond_to_offer(offer) {
    var accept;
    if (this.responder_type == 'pure_tit_for_tat') {
      if (offer in this.subj_response_history_dict){
        accept = this.subj_response_history_dict[offer];
      } else {
        accept = this.get_response_from_distribution(offer);
      }
    } else if (this.responder_type == 'anti_tit_for_tat') {
      if (offer in this.subj_response_history_dict){
        accept = !this.subj_response_history_dict[offer];
      } else {
        accept = this.get_response_from_distribution(offer);
      }
    } else if (this.responder_type == 'based_on_proposer') {
      let offer_compare = this.propose_offer();
      this.comp_propose_history.pop();
      if (offer <= offer_compare)
        accept = true;
      else
        accept = false;
    } else {
      accept = this.get_response_from_distribution(offer);
    }
    console.log('past subj responses:', this.subj_response_history_dict);
    console.log('past subj responses[offer]:', this.subj_response_history_dict[offer]);

    this.subj_propose_history.push(offer)
    this.comp_response_history.push(accept)
    return accept;
  }

  get_response_from_distribution(offer) {
    let dist;
    if (this.responder_type == 'subject_max_accept') {
      dist = {5: .00, 6: .00, 7: .00, 8: .00, 9: .24};
    } else if (this.responder_type == 'subject_max_reject'){
      dist = {5: .00, 6: .5, 7: .9375, 8: .96775, 9: .0}; // not the most rejecting... the third most, the others had 6: <= .25
    } else if (this.responder_type == 'human_distribution' ||
        this.responder_type == 'pure_tit_for_tat' ||
        this.responder_type == 'anti_tit_for_tat'){
      // The tit-for-tat responder_types are mostly handled elsewhere
      // This dist only applies to the first trial
      dist = {5: .00, 6: .12, 7: .45, 8: .67, 9: .75};
    } else {
      console.log('ERROR #1 - invalid responder')
      dist = {5: .00, 6: .12, 7: .45, 8: .67, 9: .75};
    }

    let ran_val = Math.random();
    let ran_compare = dist[offer];


    if (ran_val > ran_compare)
      return true
    else
      return false

  }

  get_propose_from_distribution() {

    let dist;
    if (this.propser_type == 'real_subject_generous') {
      dist = {5: .625, 6: .943, 7: .99, 8: 1.0, 9: 1.0};
    } else if (this.proposer_type == 'real_subject_selfish') {
      dist = {5: .151, 6: .344, 7: .589, 8: .808, 9: 1.0};
    } else if (this.proposer_type == 'human_distribution' ||
        this.proposer_type == 'pure_tit_for_tat' ||
        this.proposer_type == 'anti_tit_for_tat' ||
        this.proposer_type == 'tit_for_tat_if_comp_accept_else_partial_mimic'){
      // These proposer_types are mostly handled elsewhere
      // The dist here is only used if its the first trial
      dist = {5: .182, 6: .631, 7: .883, 8: .954, 9: 1.0};
    } else {
      console.log('ERROR #0 - invalid PropsrType');
      dist = {5: .182, 6: .631, 7: .883, 8: .954, 9: 1.0};
    }

    let ran_val = Math.random();
    for (const i of Array(5).keys()){
      if (ran_val < dist[i+5]){
        return i+5
      }
    }
    return 9

  }

  update_response_dictionary(resp_dict) {
    console.log('updating response history dict:', resp_dict)
    for (const i of Array(4).keys()){
      if (!resp_dict[i+5] && typeof resp_dict[i+5] !== 'undefined') { // !undefined = True
        resp_dict[i+6] = false;
      }
    }
    for (const i of Array(4).keys()){
      if (resp_dict[9-i]) {
        resp_dict[8-i] = true;
      }
    }
    console.log('updated:', resp_dict)

  }

  propose_offer() {
    let offer;
    let proposed_trial_number = this.comp_propose_history.length;
    if (proposed_trial_number == this.miss_computer_proposer_trial_number && typeof this.miss_computer_proposer_trial_number !== 'undefined'){
      offer = 0;
      this.comp_propose_history.push(offer);
      return offer;
    }

    if (['human_distribution', 'real_subject_generous', 'real_subject_selfish'].includes(this.proposer_type)){
      offer = this.get_propose_from_distribution()
    } else if (this.proposer_type == 'anti_tit_for_tat') {
      if (this.subj_propose_history.slice(-1) < 5)
        offer = this.get_propose_from_distribution();
      else
        offer = 9 - (this.subj_propose_history.slice(-1) - 5);
    } else if (this.proposer_type == 'anti_tit_for_tat_partial') {
      let prev_subj_proposed = this.subj_propose_history.slice(-1);
      if (!prev_subj_proposed) { // this first if catches instances where the subject just missed
        if (this.comp_propose_history.slice(-1)){
          offer = this.comp_propose_history.slice(-1);
        } else {
          offer = this.get_propose_from_distribution()
        }
      } else {
        if (this.comp_response_history.slice(-1)) {
          offer = 14 - prev_subj_proposed;
        } else { // set the computer's proposed offer to one less than what was received unless the pc prev proposed is 2
          // or more more generous, then just propose $1 more selfishly relative to before
          // in practice this may never hit if the ... !is incorporated as subjects wouldn't
          // e.g., reject $7 if they just proposed $8
          let prev_comp_proposed = this.comp_propose_history.slice(-1);
          if (prev_comp_proposed < 14 - prev_subj_proposed) {
            offer = prev_comp_proposed + 1;
          } else if (prev_comp_proposed > 14 - prev_subj_proposed) {
            offer = prev_comp_proposed - 1;
          } else {
            offer = prev_comp_proposed
          }
        }
      }
    } else if (this.proposer_type == 'anti_tit_for_tat_partial_sensible') {
      this.proposer_type = 'anti_tit_for_tat_partial';
      offer = this.propose_offer();
      this.proposer_type = 'anti_tit_for_tat_partial_sensible';
      if (this.subj_propose_history.slice(-1) == 7){
        console.log('prev subject proposed = 7')
        offer = 7 - 1 + Math.floor(Math.random() + .5)*2; // If it was 7 it now moves either up 1 or down 1
      }

    } else if (this.proposer_type == 'tit_for_tat_if_comp_accept_else_partial_mimic') {
      let prev_subj_proposed = this.subj_propose_history.slice(-1);
      console.log('subj propose history:', this.subj_propose_history)

      if (!prev_subj_proposed) { // this first if catches instances where the subject just missed
        if (this.comp_propose_history.slice(-1)){
          offer = this.comp_propose_history.slice(-1);
        } else {
          offer = this.get_propose_from_distribution()
        }
      } else {
        if (this.comp_response_history.slice(-1)) {
          offer = prev_subj_proposed;
        } else { // set the computer's proposed offer to one less than what was received unless the pc prev proposed is 2
          // or more more generous, then just propose $1 more selfishly relative to before
          // in practice this may never hit if the ... !is incorporated as subjects wouldn't
          // e.g., reject $7 if they just proposed $8
          let prev_comp_proposed = this.comp_propose_history.slice(-1);
          if (prev_comp_proposed < prev_subj_proposed) {
            offer = prev_comp_proposed + 1;
          } else if (prev_comp_proposed > prev_subj_proposed) {
            offer = prev_comp_proposed - 1;
          } else {
            offer = prev_comp_proposed
          }
        }
      }

    }
    if (!(offer > 4 && offer < 10)) {
      console.log('WARNING #2')
      offer = this.get_propose_from_distribution()
    }
    this.comp_propose_history.push(offer);
    return offer;
  }

  update_subj_response_history(offer, accept) {
    this.subj_response_history.push(accept);
    this.subj_response_history_dict[offer] = accept;
    this.update_response_dictionary(this.subj_response_history_dict)

  }

  get_trustee_choice(trust_option_chosen_) {
    let random_response = Math.floor(Math.random() * 4);
    return [trust_option_chosen_.responses[random_response], random_response / 4];
  }

}

var computer;// = new Computer('always_accept_max_generous');

var Proposer_waitingComponents;
function Proposer_waitingRoutineBegin() {
  //------Prepare to start Routine 'Proposer_waiting'-------
  t = 0;
  Proposer_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (subjectTake > 0){
    Proposer_waiting_text.setText('Waiting for the Responder to respond');
  } else {
    Proposer_waiting_text.setText('You missed!');
  }

  let accept = computer.respond_to_offer(subjectTake);

  if (accept) {
    subjectPart = subjectTake;
    responderPart = 10 - subjectTake;
  } else {
    subjectPart = 0;
    responderPart = 0;
  }

  // keep track of which components have finished
  Proposer_waitingComponents = [];
  Proposer_waitingComponents.push(Proposer_waiting_text);

  for (const thisComponent of Proposer_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *text* updates
  if (t >= 0.0 && Proposer_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_waiting_text.tStart = t;  // (not accounting for frame time here)
    Proposer_waiting_text.frameNStart = frameN;  // exact frame index
    Proposer_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_waitingRoutineEnd() {
  //------Ending Routine 'Proposer_waiting'-------
  for (const thisComponent of Proposer_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Proposer_view_outcomeComponents;
function Proposer_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Proposer_view_outcome'-------
  t = 0;
  Proposer_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.50000);
  // update component parameters for each repeat
  if (subjectTake == 0) {
     Proposer_view_outcome_text.setColor(new util.Color("red"));
     Proposer_view_outcome_text.setText('You missed!!\n' + 'You get:      $0' + '\nPlayer gets:   $0');

  } else {
    if (subjectPart > 0) {
      // Proposer_view_outcome_text.setColor(new util.Color(resp_color));
      Proposer_view_outcome_text.setColor(new util.Color("green"));
      Proposer_view_outcome_text.setText('Offer acepted!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + responderPart.toString());
    } else {
      Proposer_view_outcome_text.setColor(new util.Color("red"));
      Proposer_view_outcome_text.setText('Offer rejected!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + responderPart.toString());
    }
  }


  Proposer_view_outcomeComponents = [];
  Proposer_view_outcomeComponents.push(Proposer_view_outcome_text);

  for (const thisComponent of Proposer_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Proposer_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Proposer_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Proposer_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Proposer_view_outcome_text* updates
  if (t >= 0.0 && Proposer_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Proposer_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Proposer_view_outcome_text.frameNStart = frameN;  // exact frame index
    Proposer_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Proposer_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Proposer_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Proposer_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Proposer_view_outcomeRoutineEnd() {
  //------Ending Routine 'Proposer_view_outcome'-------
  for (const thisComponent of Proposer_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }

  return Scheduler.Event.NEXT;
}

var Responder_waitingComponents;
var proposerTake;
function Responder_waitingRoutineBegin() {
  //------Prepare to start Routine 'Responder_waiting'-------
  t = 0;
  Responder_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Responder_waitingComponents = [];
  Responder_waitingComponents.push(Responder_waiting_text);

  proposerTake = computer.propose_offer()
  for (const thisComponent of Responder_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_waiting_text* updates
  if (t >= 0.0 && Responder_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_waiting_text.tStart = t;  // (not accounting for frame time here)
    Responder_waiting_text.frameNStart = frameN;  // exact frame index
    Responder_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_waitingRoutineEnd() {
  //------Ending Routine 'Responder_waiting'-------
  for (const thisComponent of Responder_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Responder_view_offerComponents;
function Responder_view_offerRoutineBegin() {
  //------Prepare to start Routine 'Responder_view_offer'-------
  t = 0;
  Responder_view_offerClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  if (proposerTake == 0){
    // we could have subjects' partners miss... but then they may see their partner as incompetent...
    // what if subjects that miss like other people that miss? YES, more similarity testing
    Responder_view_offer_text.setText('The other player missed!\n\n' +
                                      'Player:   $' + proposerTake.toString() + '\n You:      $' + (10-proposerTake).toString());
    console.log('THE OTHER PLAYER MISSED!!!!')
  } else {
    Responder_view_offer_text.setText('Player:   $' + proposerTake.toString() + '\n You:      $' + (10-proposerTake).toString());
  }
  // keep track of which components have finished
  Responder_view_offerComponents = [];
  Responder_view_offerComponents.push(Responder_view_offer_text);

  for (const thisComponent of Responder_view_offerComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_view_offerRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_view_offer'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_view_offerClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_view_offer_text* updates
  if (t >= 0.0 && Responder_view_offer_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_view_offer_text.tStart = t;  // (not accounting for frame time here)
    Responder_view_offer_text.frameNStart = frameN;  // exact frame index
    Responder_view_offer_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_view_offer_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_view_offer_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_view_offerComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_view_offerRoutineEnd() {
  //------Ending Routine 'Responder_view_offer'-------
  for (const thisComponent of Responder_view_offerComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var Responder_respondComponents;
function Responder_respondRoutineBegin() {
  //------Prepare to start Routine 'Responder_respond'-------
  t = 0;
  Responder_respondClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  missed = true;
  offer_rating.keys = undefined;
  offer_rating.rt = undefined;
  // keep track of which components have finished
  Responder_respondComponents = [];
  Responder_respondComponents.push(Responder_respond_text);
  Responder_respondComponents.push(offer_rating);

  for (const thisComponent of Responder_respondComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  var miss_or_Responder_respond_text = 'strongly   ||   accept   ||   pass   ||  reject  ||  strongly\n' +
      ' accept                                                          reject\n\n' +
      '      1                2            space          9              0'
  Responder_respond_text.setText(miss_or_Responder_respond_text);

  return Scheduler.Event.NEXT;


}

var missed;
function Responder_respondRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_respond'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_respondClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_respond_text* updates
  if (t >= 0.0 && Responder_respond_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_respond_text.tStart = t;  // (not accounting for frame time here)
    Responder_respond_text.frameNStart = frameN;  // exact frame index
    Responder_respond_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_respond_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_respond_text.setAutoDraw(false);
  }

 // if (Responder_respond_text.status === PsychoJS.Status.STARTED){ // only update if being drawn
  //  Responder_respond_text.setText(miss_or_Responder_respond_text);
  //}

  // *offer_rating* updates
  if (t >= 0.0 && offer_rating.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    offer_rating.tStart = t;  // (not accounting for frame time here)
    offer_rating.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { offer_rating.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { offer_rating.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { offer_rating.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (offer_rating.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    offer_rating.status = PsychoJS.Status.FINISHED;
  }

  if (offer_rating.status === PsychoJS.Status.STARTED) {
    let theseKeys = offer_rating.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      offer_rating.keys = theseKeys[0].name;  // just the last key pressed
      offer_rating.rt = theseKeys[0].rt;
      missed = false;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_respondComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var proposerPart;
function Responder_respondRoutineEnd() {
  //------Ending Routine 'Responder_respond'-------
  for (const thisComponent of Responder_respondComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('offer_rating.keys', offer_rating.keys);
  if (typeof offer_rating.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('offer_rating.rt', offer_rating.rt);
      }

  if (offer_rating.keys == null) {
      proposerPart = 0;
      subjectPart = 0;
  } else {
    console.log(offer_rating)
    var key = offer_rating.keys;
    if (key == "1"){
      proposerPart = proposerTake;
      subjectPart = 10 - proposerTake;
    } else if (key == '2'){
      proposerPart = proposerTake;
      subjectPart = 10 - proposerTake;
    } else if (key == 'space'){
      proposerPart = 0;
      subjectPart = 0;
    } else if (key == '9'){
      proposerPart = 0;
      subjectPart = 0;
    } else if (key == '0'){
      proposerPart = 0;
      subjectPart = 0;
    }
    computer.update_subj_response_history(proposerTake, Boolean(proposerPart));
  }

  offer_rating.stop();
  return Scheduler.Event.NEXT;
}

var Responder_view_outcomeComponents;
function Responder_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Responder_view_outcome'-------
  t = 0;
  Responder_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.50000);

  if (missed) {
    Responder_view_outcome_text.setColor(new util.Color("red"));
    Responder_view_outcome_text.setText('Offer missed!\n' + 'You get:      $0' + '\nPlayer gets:   $0');
  }else if (subjectPart > 0) {
    // Proposer_view_outcome_text.setColor(new util.Color(resp_color));
    Responder_view_outcome_text.setColor(new util.Color("green"));
    Responder_view_outcome_text.setText('Offer acepted!\n' + 'You get:      $' + subjectPart.toString() + '\nPlayer gets:   $' + proposerPart.toString());
  } else {
    Responder_view_outcome_text.setColor(new util.Color("red"));
    Responder_view_outcome_text.setText('Offer rejected!\n' + 'You get:      $0' + '\nPlayer gets:   $0');
  }


  Responder_view_outcomeComponents = [];
  Responder_view_outcomeComponents.push(Responder_view_outcome_text);

  for (const thisComponent of Responder_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}


function Responder_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Responder_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Responder_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Responder_view_outcome_text* updates
  if (t >= 0.0 && Responder_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Responder_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Responder_view_outcome_text.frameNStart = frameN;  // exact frame index
    Responder_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Responder_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Responder_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Responder_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Responder_view_outcomeRoutineEnd() {
  //------Ending Routine 'Responder_view_outcome'-------
  for (const thisComponent of Responder_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}


function Investor_investRoutineBegin() {
  //------Prepare to start Routine 'Investor_invest'-------
  t = 0;
  Investor_investClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.000000);
  // update component parameters for each repeat
  Investor_key_input.keys = undefined;
  Investor_key_input.rt = undefined;
  // keep track of which components have finished
  Investor_investComponents = [];
  Investor_investComponents.push(Investor_invest_text);
  Investor_investComponents.push(Investor_key_input);

  for (const thisComponent of Investor_investComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_investRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_invest'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_investClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_invest_text* updates
  if (t >= 0.0 && Investor_invest_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_invest_text.tStart = t;  // (not accounting for frame time here)
    Investor_invest_text.frameNStart = frameN;  // exact frame index
    Investor_invest_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_invest_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_invest_text.setAutoDraw(false);
  }

  // *Investor_key_input* updates
  if (t >= 0.0 && Investor_key_input.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_key_input.tStart = t;  // (not accounting for frame time here)
    Investor_key_input.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Investor_key_input.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Investor_key_input.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Investor_key_input.clearEvents(); });
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_key_input.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_key_input.status = PsychoJS.Status.FINISHED;
  }

  if (Investor_key_input.status === PsychoJS.Status.STARTED) {
    let theseKeys = Investor_key_input.getKeys({keyList: ['1', '2', 'space', '9', '0'], waitRelease: false});

    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }

    if (theseKeys.length > 0) {  // at least one key was pressed
      Investor_key_input.keys = theseKeys[0].name;  // just the last key pressed
      Investor_key_input.rt = theseKeys[0].rt;
      // a response ends the routine
      //continueRoutine = false;
    }
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_investComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

var trust_option_chosen;
var trust_response_missed;
function Investor_investRoutineEnd() {
  //------Ending Routine 'Investor_invest'-------
  for (const thisComponent of Investor_investComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Investor_key_input.keys', Investor_key_input.keys);
  if (typeof Investor_key_input.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Investor_key_input.rt', Investor_key_input.rt);
      routineTimer.reset();
      }
  console.log(Investor_key_input)
  console.log('A')
  if (Investor_key_input.keys == null) {
    trust_response_missed = true;
    trust_option_chosen = trust_options.option1;
  } else {
    trust_response_missed = false;
    console.log(Investor_key_input)
    console.log('test')
    var key = Investor_key_input.keys; // EDITTED!!!!!!
    if (key == "1") {
      trust_option_chosen = trust_options.option1
    } else if (key == '2') {
      trust_option_chosen = trust_options.option2
    } else if (key == 'space') {
      trust_option_chosen = trust_options.option3
    } else if (key == '9') {
      trust_option_chosen = trust_options.option4
    } else if (key == '0') {
      trust_option_chosen = trust_options.option5
    }
  }
  console.log('meme')
  console.log(trust_option_chosen)
  Investor_key_input.stop();
  return Scheduler.Event.NEXT;
}

function Investor_confirm_amountRoutineBegin() {
  //------Prepare to start Routine 'Investor_confirm_amount'-------
  t = 0;
  Investor_confirm_amountClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.000000);
  // update component parameters for each repeat

  console.log('confirm:')
  console.log(trust_option_chosen)
  console.log(trust_option_chosen.amount)
  const max_return = trust_option_chosen.amount*3;
  const amount_kept = 20 - trust_option_chosen.amount;

  if (trust_response_missed) {
    Investor_confirm_amount_text.setText('You missed! \n \n Trusting:      $0' +
                                       '\nYou kept:       $20' +
                                       '\nMax return:     $0');
  } else {
    Investor_confirm_amount_text.setText('You invested:    $' + trust_option_chosen.amount.toString() +
                                       '\nYou kept:        $' + amount_kept.toString() +
                                       '\nMax return (3x): $' + max_return.toString());
  }


  // keep track of which components have finished
  Investor_confirm_amountComponents = [];
  Investor_confirm_amountComponents.push(Investor_confirm_amount_text);

  for (const thisComponent of Investor_confirm_amountComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_confirm_amountRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_confirm_amount'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_confirm_amountClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_confirm_amount_text* updates
  if (t >= 0.0 && Investor_confirm_amount_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_confirm_amount_text.tStart = t;  // (not accounting for frame time here)
    Investor_confirm_amount_text.frameNStart = frameN;  // exact frame index
    Investor_confirm_amount_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_confirm_amount_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_confirm_amount_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_confirm_amountComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_confirm_amountRoutineEnd() {
  //------Ending Routine 'Investor_confirm_amount'-------
  for (const thisComponent of Investor_confirm_amountComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var trustReturn, trustProportion;
function Investor_waitingRoutineBegin() {
  //------Prepare to start Routine 'Investor_waiting'-------
  t = 0;
  Investor_waitingClock.reset(); // clock
  frameN = -1;
  routineTimer.add(3.000000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Investor_waitingComponents = [];
  Investor_waitingComponents.push(Investor_waiting_text);

  const vals = computer.get_trustee_choice(trust_option_chosen);
  trustReturn = vals[0];
  trustProportion = vals[1];

  for (const thisComponent of Investor_waitingComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  return Scheduler.Event.NEXT;
}

function Investor_waitingRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_waiting'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_waitingClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_waiting_text* updates
  if (t >= 0.0 && Investor_waiting_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_waiting_text.tStart = t;  // (not accounting for frame time here)
    Investor_waiting_text.frameNStart = frameN;  // exact frame index
    Investor_waiting_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_waiting_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_waiting_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_waitingComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_waitingRoutineEnd() {
  //------Ending Routine 'Investor_waiting'-------
  for (const thisComponent of Investor_waitingComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

function Investor_view_outcomeRoutineBegin() {
  //------Prepare to start Routine 'Investor_view_outcome'-------
  t = 0;
  Investor_view_outcomeClock.reset(); // clock
  frameN = -1;
  routineTimer.add(6.00000);
  // update component parameters for each repeat
  // keep track of which components have finished
  Investor_view_outcomeComponents = [];
  Investor_view_outcomeComponents.push(Investor_view_outcome_text);

  for (const thisComponent of Investor_view_outcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;

  if (false){
    if (trust_response_missed) {
      Investor_view_outcome_text.setText('You missed!' +
                                      '\n\nOutcome you:    $20' +
                                        '\nOutcome player:   $0')
    } else {
      let outcome_investor = 20 - trust_option_chosen.amount + trustReturn;
      let outcome_trustee = trust_option_chosen.amount * 3 - trustReturn;

      Investor_view_outcome_text.setText('You invested:      $' + trust_option_chosen.amount.toString() +
                                     '\n\nPlayer returned:   $' + trustReturn.toString() +
                                     '\n\nOutcome you:       $' + outcome_investor.toString() +
                                       '\nOutcome player:    $' + outcome_trustee.toString())
    }

  }

  return Scheduler.Event.NEXT;
}

function Investor_view_outcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Investor_view_outcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Investor_view_outcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame

  // *Investor_view_outcome_text* updates
  if (t >= 0.0 && Investor_view_outcome_text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Investor_view_outcome_text.tStart = t;  // (not accounting for frame time here)
    Investor_view_outcome_text.frameNStart = frameN;  // exact frame index
    Investor_view_outcome_text.setAutoDraw(true);
  }

  frameRemains = 0.0 + 6.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (Investor_view_outcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    Investor_view_outcome_text.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [escape] key was pressed. Goodbye!', false);
  }

  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }

  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Investor_view_outcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }

  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}

function Investor_view_outcomeRoutineEnd() {
  //------Ending Routine 'Investor_view_outcome'-------
  for (const thisComponent of Investor_view_outcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}





function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});

  return Scheduler.Event.QUIT;
}




function endLoopIteration({thisScheduler, isTrials=true}) {
  // ------Prepare for next entry------
  return function () {
    // ------Check if user ended loop early------
    if (currentLoop.finished) {
      // Check for and save orphaned data
      if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
        psychoJS.experiment.nextEntry();
      }
      thisScheduler.stop();
    } else if (isTrials) {
      psychoJS.experiment.nextEntry();
    }
  return Scheduler.Event.NEXT;
  };
}




function importConditions(loop) {
  const trialIndex = loop.getTrialIndex();
  return function () {
    loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}

